// The file contents for the current environment will overwrite these during build.
// The build system defaults to the dev environment which uses `environment.ts`, but if you do
// `ng build --env=prod` then `environment.prod.ts` will be used instead.
// The list of which env maps to which file can be found in `.angular-cli.json`.
//   serverUrl: 'http://166.50.223.191:4300', csrf not working with urls that start with http or https
// https://github.com/angular/angular/issues/18859
//serverUrl: 'http://166.50.223.191:9090',

export const environment = {
  production: false,
  serverUrl: '/esp',

  
  moduleAuthUrl:  '/esp/auth',  
  dniConfigNetTypeUrl:  '/esp/configNetType',  
};

export const localApis = {
	angularLogin: '/auth/login'

}

export const urls = {
  moduleAuthUserUrl:      environment.moduleAuthUrl.concat('/user'),  
  
  dniConfigNetTypeList:   environment.dniConfigNetTypeUrl.concat('/list'),
  dniConfigNetTypeEdit:   environment.dniConfigNetTypeUrl.concat('/doEdit'),
  dniConfigNetTypeDelete: environment.dniConfigNetTypeUrl.concat('/doDelete'),
  dniConfigNetTypeCreate: environment.dniConfigNetTypeUrl.concat('/doCreate'),
 
};


// DO NOT CHANGE Constant
export enum Source {
     NEW_UI = 'newUI',
};

export enum App {
     PRE_SALES_ORDER = 'preSalesOrderTool',
     DOC_REPOSITORY = 'docRepository',
     DNI = 'DNI',
};

// make changes here
export const configuration = {
	app:  App.DNI,
	source: Source.NEW_UI,
}


