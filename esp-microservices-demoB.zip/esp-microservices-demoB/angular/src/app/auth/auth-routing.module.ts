import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ModuleWithProviders } from '@angular/core';

import { AuthComponent } from './auth.component';
import { LoginComponent } from './login/login.component';

import { AuthAppRouteNotFoundComponent } from './auth-app-route-not-found/auth-app-route-not-found.component'; //FIXME temp for testing
// TBD if export this to root app, then just one copy and always checked, problem is that it's easy to loose track of the import
import { AuthGuardService } from '../auth/services/auth-guard.service'; 



export const authRoutes = [
 
  {
    path: "", // Path is defined in parent
    component : AuthComponent, // blocks /auth/login path
    children : [
        {   
            path: "",
            redirectTo: 'login',
            pathMatch: 'full',
        },
        {
            path: 'login',
            component: LoginComponent,
         },
	]},
     {
        path: '**',
        component: AuthAppRouteNotFoundComponent 
     },
];

  
//export const authRouting: ModuleWithProviders = RouterModule.forChild(authRoutes);   
 @NgModule({
    //imports: [RouterModule.forChild(authRoutes)],
    exports: [ 
    	RouterModule
    ]
})
export class AuthRoutingModule { }


    
