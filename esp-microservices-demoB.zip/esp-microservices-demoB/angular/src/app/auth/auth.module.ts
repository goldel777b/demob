
//https://angular.io/guide/module-types
//import { CommonModule } from '@angular/common';
import { NgModule, ModuleWithProviders } from '@angular/core';
import { HttpClientXsrfModule } from '@angular/common/http';
import { RouterModule,  } from '@angular/router';
// TBD ReactiveFormsModule -- FIXME - some reactive forms in Login and perhaps others
import { FormsModule, NgForm } from '@angular/forms'; //ReactiveFormsModule
import { HTTP_INTERCEPTORS } from '@angular/common/http';

//import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';


//import { AppBootstrapModule } from '../app-bootstrap/app-bootstrap.module';

import { AuthRoutingModule  } from './auth-routing.module';

//import { CookieService } from 'ngx-cookie-service';

import { AuthComponent } from './auth.component';
import { LoginComponent } from './login/login.component';


import { AuthService } from './services/auth.service';
import { AuthGuardService } from './services/auth-guard.service';
import { AuthRoleGuardService } from './services/auth-role-guard.service';

import { AuthAppRouteNotFoundComponent } from './auth-app-route-not-found/auth-app-route-not-found.component';

import { AuthHttpInterceptorService } from './services/auth-http-interceptor.service';
import { LoggingInterceptorService } from './services/logging-interceptor.service';

//import { ModalComponent } from '../shared/core/directives/modal.component';
//import { SharedModule } from '../shared/shared.module';

@NgModule({
  declarations: [
    AuthComponent,
    LoginComponent,
    AuthAppRouteNotFoundComponent,
    //ModalComponent
    //FooterComponent
  ],
  imports: [
    RouterModule,
    FormsModule,
    HttpClientXsrfModule.withOptions({
            cookieName: 'XSRF-TOKEN',
            headerName: 'X-XSRF-TOKEN' 
    }),
    //SharedModule
    //ModalComponent,
    //authRouting,
    //AuthRoutingModule 
  ],
  // don't add providers here, let it be singleton at the root
   providers: [],
  exports: [ RouterModule ],
})
export class AuthModule {

 // keep services singleton access at this level
 // https://angular.io/guide/module-types
    static forRoot(): ModuleWithProviders {
    return {
       ngModule: AuthModule,
       // forces a singleton across the whole application
       providers: [
         AuthService,
         AuthGuardService,
         AuthRoleGuardService,
         { provide: HTTP_INTERCEPTORS, useClass: AuthHttpInterceptorService, multi: true},
         
         // loggin interceptor is breaking custom http XXX TBD
         //{ provide:  HTTP_INTERCEPTORS, useClass: LoggingInterceptorService, multi: true}
      ],
    }
  }

}

/*platformBrowserDynamic().bootstrapModule(AppModule);*/
