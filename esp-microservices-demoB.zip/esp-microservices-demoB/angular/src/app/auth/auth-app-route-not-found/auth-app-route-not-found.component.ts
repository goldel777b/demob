import { Component, OnInit } from '@angular/core';
import { Location, LocationStrategy } from '@angular/common';

@Component({
  selector: 'app-auth-app-route-not-found',
  templateUrl: './auth-app-route-not-found.component.html',
  styleUrls: ['./auth-app-route-not-found.component.css']
})
export class AuthAppRouteNotFoundComponent implements OnInit {

  constructor(private locationStrategy: LocationStrategy) { }

  ngOnInit() {
    console.log("AUTH AuthAppRouteNotFoundComponent", this.locationStrategy.path());
  }

}
