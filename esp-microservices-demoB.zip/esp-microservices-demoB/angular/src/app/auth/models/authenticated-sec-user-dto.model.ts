
import { SecUserDTO } from './sec-user-dto.model';
import { AuthenticatedUserDTO } from './authenticated-user-dto.model';

export class AuthenticatedSecUserDTO {
     constructor(
        public authenticatedUser : AuthenticatedUserDTO,
        public secUser:  SecUserDTO) {}
}
