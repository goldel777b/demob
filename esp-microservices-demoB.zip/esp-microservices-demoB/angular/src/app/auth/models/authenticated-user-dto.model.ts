

//public password: string, //null password is not returned from spring
 export class AuthenticatedUserDTO {
	  public username: string = null;
	  public accountNonExpired: boolean = false;
	  public accountNonLocked: boolean = false;
	  public authorities: Map<string, string>[] = null; //Array<any> = null; //Map<string, string>[],
	  public credentialsNonExpired: boolean = false;
	  public enabled: boolean = false;
	  private authoritiesSet: Set<string>;
 
      public isAuthenticated() :boolean {
	     //console.log("AuthenticatedUserDTO::initialize", this.username, this.accountNonExpired, this.accountNonLocked, this.credentialsNonExpired,
	     //										 this.enabled, this.authorities);
	     return this.username != null &&
                 this.accountNonExpired &&
                 this.accountNonLocked &&
                 this.credentialsNonExpired &&
                 this.enabled &&
                 this.authorities != null;  

     }
}
