import { Injectable } from '@angular/core';
import { Router, CanActivate, ActivatedRoute,  ActivatedRouteSnapshot, Params, RouterStateSnapshot } from '@angular/router';

import { AuthService } from './auth.service';

import { localApis } from '../../../environments/environment';

@Injectable()
export class AuthGuardService implements CanActivate { 
  private angularLogin = localApis.angularLogin;
  
  constructor(private authService: AuthService, private router:Router, private activatedRoute: ActivatedRoute) {}

  canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): boolean { 
    console.log("AuthGuardService::called", this.authService.isAuthenticated(), route.url, state.url, this.angularLogin,  route.queryParamMap);

    
    if (!this.authService.isAuthenticated())  {
      let isAngularLoginUrl = state.url.indexOf( this.angularLogin) == 0;
      let previousRestAngularLogin = isAngularLoginUrl ? "/" : state.url;
      
      
      console.log("state.url from guard", state.url.indexOf( this.angularLogin), route.url, state.url, 
      		this.angularLogin, previousRestAngularLogin, 
            "route.queryParamMap::", route.queryParamMap,"route.paramMap ", route.paramMap,
            "activatedRoute.queryParamMap::", this.activatedRoute.queryParamMap,"route.paramMap ", 
            this.activatedRoute.paramMap
            );
      
      this.authService.savePreviousRestApiIfNotSet(previousRestAngularLogin); //, route.queryParamMap);

      // let them have access to the login page
      if (isAngularLoginUrl) {
           return true;
      }
      
      console.log("AuthGuardService::navigating to login");
      this.router.navigate([this.angularLogin]);//, { queryParams: route.queryParamMap });
      return false;
      //return true;
    } 
    return true;
  }
}
