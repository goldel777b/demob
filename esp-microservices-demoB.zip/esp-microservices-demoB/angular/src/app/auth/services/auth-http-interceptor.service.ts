import { Injectable } from '@angular/core';
import { 
  HttpRequest, 
  HttpHandler,
  HttpInterceptor, 
  HttpSentEvent, 
  HttpErrorResponse, 
  HttpProgressEvent, 
  HttpResponse,
  HttpUserEvent,
  HttpEvent,
  HttpHeaders,
  HttpXsrfTokenExtractor,
  HttpHeaderResponse } from '@angular/common/http';
//import { CookieService } from 'ngx-cookie-service'; 

import { Observable } from 'rxjs/Observable';
import { Router } from '@angular/router'; 

import 'rxjs/add/operator/map';
import 'rxjs/add/operator/do';

import { SecUserDTO } from '../models/sec-user-dto.model';
import { AuthService } from './auth.service';

 // probably need a better setup TBD  - may need to make all these
// services global..
//import { LoginService } from './login.service';

//The Angular team has made this job easier for you (of course) by taking
//   care of the client side. It applies a default CookieXSRFStrategy to all requests


//import { BaseRequestOptions, Headers } from '@angular/http';
//TBD XXX not working      
//TBD params: req.params.append('auth' token); TBD don't really want param but in post?

@Injectable()
export class AuthHttpInterceptorService implements HttpInterceptor {
  
    constructor(private authService: AuthService, 
				private router: Router, 
				private tokenExtractor: HttpXsrfTokenExtractor) {}
   
    
    intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
       //Observable<HttpSentEvent | HttpHeaderResponse | HttpProgressEvent | HttpResponse<any> | HttpUserEvent<any>> {
          console.log("CustomHttpInterceptorService::intercept enter", req);

	      const secUser = this.authService.getInterceptorSecUser();
	      //const authorization = 'Basic ' + btoa(secUser.username + ':' + secUser.password);
	      
	      // TBD there should always be a sec user on the incoming side
	      // this.checkCredentials(req);      
	      //https://spring.io/guides/tutorials/spring-security-and-angular-js/#_the_login_page_angular_js_and_spring_security_part_ii
	      
	     // var token = this.tokenExtractor.getToken() as string;
	     
	      //token = token == null ? "" : token;
	      
	       const headers = new HttpHeaders( { 'Content-Type': 'application/json' ,
	             authorization : 'Basic ' + btoa(secUser.username + ':' + secUser.password),
	             'Cache-Control': 'no-cache, no-store, max-age=0, must-revalidate',
	             'Pragma': 'no-cache',
	             'Expires': '0', // 'Sat, 01 Jan 2000 00:00:00 GMT'
	             'If-Modified-Since': '0',
				 "Access-Control-Allow-Credentials" : "true",
				 "Access-Control-Allow-Origin" : "*",
	             'X-Requested-With': 'XMLHttpRequest', // this should suppress the user/password popup
	             //'X-XSRF-TOKEN': token
	       });
             // 'X-XSRF-TOKEN': token
             //	'withCredentials' : 'true',        
          
 
	      console.log("secUser::", secUser);
		 
	      
	      // must copy each, so they do not concatenate on multiple calls
	      var nextReq = req.clone({  headers: headers }); 
	      
	      nextReq = this.updateCsrfTokenIfNeeded(nextReq);
	      
	      console.log("CustomHttpInterceptorService::intercept exit");
	      return next.handle(nextReq).do((event: HttpEvent<any>) => {
	               console.log("interceptor event", event);
			      if (event instanceof HttpResponse) {
			          console.log("interceptor response", event.headers);
			           
			           var headers = event.headers;
                        //var setCookieHeader = headers.get('Set-Cookie');
            
                        console.log("response headers", headers);
                        //console.log("setCookieHeader", setCookieHeader);
			          
			          
			      }
			    }, (err: any) => {
			      if (err instanceof HttpErrorResponse) {
					console.log("Interceptor response error", err);
			        if (err.status === 401) {
			          // redirect to the login route
			          // or show a modal
			          console.log("redirect to logoin on 401 error", err);
			          //this.router.navigateByUrl('/auth');
			        }
			      }
			    });;
  } 
  
  private updateCsrfTokenIfNeeded(req: HttpRequest<any>) : HttpRequest<any> {
     let requestMethod: string = req.method;
     
     requestMethod = requestMethod.toLowerCase();

     if (requestMethod && (requestMethod === 'post' || requestMethod === 'delete' || requestMethod === 'put' )) {
         const headerName = 'X-XSRF-TOKEN';
         let token = this.tokenExtractor.getToken() as string;
         
         if (token !== null && !req.headers.has(headerName)) {
                  
	      
	        console.log("interceptor::adding token", token);
            
             req = req.clone({ headers: req.headers.set(headerName, token) });
         }
      }
      return req;
  
  }
 
 
 /*interceptExample(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    const lcUrl = req.url.toLowerCase();
    // Skip both non-mutating requests and absolute URLs.
    // Non-mutating requests don't require a token, and absolute URLs require special handling
    // anyway as the cookie set
    // on our origin is not the same as the token expected by another origin.
    if (req.method === 'GET' || req.method === 'HEAD' || lcUrl.startsWith('http://') ||
        lcUrl.startsWith('https://')) {
      return next.handle(req);
    }
    const token = this.tokenService.getToken();

    // Be careful not to overwrite an existing header of the same name.
    if (token !== null && !req.headers.has(this.headerName)) {
      req = req.clone({headers: req.headers.set(this.headerName, token)});
    }
    return next.handle(req);
  }*/
      

  
   
//   private handleRequest(req: HttpRequest<any>, next: HttpHandler) {
//      console.log("CustomHttpInterceptor::handleRequest");
//      this.checkCredentials(req);
//            
//      // must copy each, so they do not concatenate on multiple calls
//      const nextReq = req.clone({
//        headers: req.headers.set('Cache-Control', 'no-cache')
//          .append('Pragma', 'no-cache')
//          .append('Expires', '0')
//          //.append('Expires', 'Sat, 01 Jan 2000 00:00:00 GMT')
//          .append('If-Modified-Since', '0')
//          .append('Cache-Control', 'no-cache, no-store, max-age=0, must-revalidate')
//      });
//      console.log("CustomHttpInterceptorService::intercept");
//      return next.handle(nextReq);
//  }
  
/*private checkCredentials(req: HttpRequest<any>) {
     
      console.log("CustomHttpInterceptor::checkCredentials", req);
    
      const smUser = req.headers.get("SM_USER");
     
      
      if (!smUser) {
          this.router.navigate(['/auth']);
      }/
      // route to login if not there
  }
  */
//  
//  interceptOrig(req: HttpRequest<any>, next: HttpHandler):
//    Observable<HttpSentEvent | HttpHeaderResponse | HttpProgressEvent | HttpResponse<any> | HttpUserEvent<any>> {
//    
//    
//    // must copy each, so they do not concatenate on multiple calls
//    const nextReq = req.clone({
//      headers: req.headers.set('Cache-Control', 'no-cache')
//        .append('Pragma', 'no-cache')
//        .append('Expires', '0')
//        //.append('Expires', 'Sat, 01 Jan 2000 00:00:00 GMT')
//        .append('If-Modified-Since', '0')
//        .append('Cache-Control', 'no-cache, no-store, max-age=0, must-revalidate')
//    });
//    console.log("CustomHttpInterceptorService::intercept");
//    return next.handle(nextReq);
//  }
}
  
////https://stackoverflow.com/questions/37755782/prevent-ie11-caching-get-call-in-angular-2
//  // TBD not working - was for Http and not HttpClient
//export class CustomRequestOptions extends BaseRequestOptions {
//    headers = new Headers({
//        'Cache-Control': 'no-cache',
//        'Pragma': 'no-cache',
//        'Expires': 'Sat, 01 Jan 2000 00:00:00 GMT'
//     });
//}