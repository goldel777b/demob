import { Injectable } from '@angular/core';

import { Router } from '@angular/router';
import { URLSearchParams, Http, Headers, RequestOptions, Response } from '@angular/http'; // deprecated
//import { Cookie } from 'angular2-cookie/Cookie';

import { Observable } from 'rxjs/Observable';

import 'rxjs/add/operator/map';
import 'rxjs/add/operator/toPromise';
import "rxjs/add/observable/interval";export class 
  
  
Login {
  constructor(
    public id: number,
    public name: string) { }
} 


@Injectable()
export class LoginService {
  
   constructor(private _router: Router, private _http: Http){}

   obtainAccessToken(loginData) {
      let params = new URLSearchParams();
      
      params.append('username',loginData.username);
      params.append('password',loginData.password);    
      params.append('grant_type','password');
      params.append('client_id','fooClientIdPassword'); // TBD needs to be uniqu?
     
      let headers = new Headers({'Content-type': 'application/x-www-form-urlencoded; charset=utf-8', 'Authorization': 'Basic '+btoa("fooClientIdPassword:secret")});
      let options = new RequestOptions({ headers: headers });
       
      this._http.post('http://localhost:8081/spring-security-oauth-server/oauth/token', params.toString(), options)
        .map(res => res.json())
        .subscribe(
          data => this.saveToken(data),
          err => alert('Invalid Credentials')); 
    }
  
     // TBD what if the client isn't using cookies
    saveToken(token) {
      var expireDate = new Date().getTime() + (1000 * token.expires_in);
      
      console.log("LoginService::saveToken::", token);
      // XXX Cookie.set("access_token", token.access_token, expireDate);
      // could store locally..
      
      localStorage.setItem('token', token.access_token);
      localStorage.setItem('expireDate', expireDate.toString());
      this._router.navigate(['/']);
    }
  
      // TBD put in interceptor
    getResource(resourceUrl) : Observable<Login>{
      const token = localStorage.getTtem("token");
      //const expireDate = localStorage.getItem("expireDate"); // tbd how save is this?
      var headers = new Headers({'Content-type': 'application/x-www-form-urlencoded; charset=utf-8', 'Authorization': 'Bearer '+token});
      //var headers = new Headers({'Content-type': 'application/x-www-form-urlencoded; charset=utf-8', 'Authorization': 'Bearer '+Cookie.get('access_token')});
      var options = new RequestOptions({ headers: headers });
      
      console.log("Old login called why???");
      return this._http.get(resourceUrl, options)
                     .map((res:Response) => res.json());
                     //.catch((error:any) => Observable.throw(error.json().error || 'Server error'));

    }
      
    checkCredentials() {  // need to check more often than at start of app. TBD
      const token = localStorage.getTtem("token");
      //const expireDate = localStorage.getItem("expireDate"); // tbd how save is this?
     
     // if (!Cookie.check('access_token')){
      if (! token) {
          this._router.navigate(['/login']);
      }
    } 

    logout() {
      //Cookie.delete('access_token');
      // how safe is local storage TBD XXX
      
      localStorage.removeItem("token");
      localStorage.removeItem("expireDate");
      
      this._router.navigate(['/login']);
    }
}
