import { Injectable } from '@angular/core';

import { 
  HttpRequest, 
  HttpHandler,
  HttpInterceptor, 
  HttpSentEvent, 
  HttpProgressEvent, 
  HttpResponse,
  HttpUserEvent,
  HttpHeaderResponse } from '@angular/common/http';

import { Observable } from 'rxjs/Observable';

@Injectable()
export class LoggingInterceptorService implements HttpInterceptor {

  intercept(req: HttpRequest<any>, next: HttpHandler):
    Observable<HttpSentEvent | HttpHeaderResponse | HttpProgressEvent | HttpResponse<any> | HttpUserEvent<any>> {
    
    console.log("LogginInterceptorService::intercept", req);
    return next.handle(req);
  }

}

