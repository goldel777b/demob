import { Injectable } from '@angular/core';

import {
  Router,
  CanActivate,
  ActivatedRouteSnapshot
} from '@angular/router';

import { AuthService } from './auth.service';

//import decode from 'jwt-decode';
import { localApis } from '../../../environments/environment';

@Injectable()
export class AuthRoleGuardService implements CanActivate {
  private angularLogin = localApis.angularLogin;

  constructor(public authService: AuthService, public router: Router) {}

  canActivate(route: ActivatedRouteSnapshot): boolean {

    console.log("AuthRoleGuardService::canActivate");
    // this will be passed from the route config
    // on the data property
    const expectedRole = route.data.expectedRole;

    //https://medium.com/@ryanchenkie_40935/angular-authentication-using-route-guards-bf7a4ca13ae3
    //const token = localStorage.getItem('token');
    // decode the token to get its payload
    //const tokenPayload = decode(token);
    //if (
    //  !this.auth.isAuthenticated() ||
    //  tokenPayload.role !== expectedRole
    //) { 

    console.log("RoleGuardService", expectedRole, this.authService.hasAuthority(expectedRole) );

    if (!this.authService.hasAuthority(expectedRole)) {
      // if current route does not equal this route, then route it
      console.log("does not have authority", expectedRole, this.router.url);
      // already routed
      if (this.router.url === this.angularLogin) {
      		return true;
      }
      this.router.navigate( [ this.angularLogin ] );
      return false;
    }
    
    return true;
  }
}
