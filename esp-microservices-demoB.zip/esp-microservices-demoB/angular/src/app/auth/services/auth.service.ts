import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpXsrfTokenExtractor, HttpResponse} from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
//import { Observer } from 'rxjs/Observer';
import { Router, ParamMap, NavigationExtras } from '@angular/router';
//import { CookieService } from 'ngx-cookie-service'; 

 // "//observable/Observable";
//import { IntervalObservable } from "rxjs/observable/IntervalObservable";
import { IntervalObservable } from "rxjs/observable/IntervalObservable";
import {TimerObservable} from "rxjs/observable/TimerObservable";

import { Subscription } from 'rxjs/Subscription';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';

import { urls } from '../../../environments/environment';


import 'rxjs/add/operator/map';
import 'rxjs/add/operator/toPromise';
import "rxjs/add/observable/interval";
import "rxjs/add/observable/of";



import { SecUserDTO } from '../models/sec-user-dto.model';
import { AuthenticatedUserDTO } from '../models/authenticated-user-dto.model';
import { AuthenticatedSecUserDTO } from '../models/authenticated-sec-user-dto.model';

// for lodash
//npm install --save lodash
//npm install --save @types/lodash
import * as _ from "lodash";

// for jwt https://medium.com/@ryanchenkie_40935/angular-authentication-using-route-guards-bf7a4ca13ae3
// npm install --save @auth0/angular-au

//https://www.lucidchart.com/techblog/2016/11/08/angular-2-and-observables-data-sharing-in-a-multi-view-application/

// Only Components and Directives have lifecycle hooks

// this is the question - who shares an Angular server - just the logged in user or? TBD XXX
@Injectable()
export class AuthService  { // service does not have certain lifestages implements OnInit { //}, OnDestroy {
  
  private authenticatedSubject = new BehaviorSubject<boolean>(undefined);
  private authoritiesSubject = new BehaviorSubject<Set<string>>(undefined);
  // NOT needed? TBD only interceptor needs to see this - password is not return from spring
  //private authenticatedSecUserSubject = new BehaviorSubject<AuthenticatedSecUserDTO>(undefined);

  private authenticatedObservable = this.authenticatedSubject.asObservable();
  private authoritiesObservable = this.authoritiesSubject.asObservable();
  //private authenticatedSecUserObservable = this.authenticatedSecUserSubject.asObservable();
 
  // tbd store in local storage? this is the one that has the password
  // it always has the latest login request information
  private interceptorSecUser: SecUserDTO;

  private authenticated = false;
  private authenticatedSecUser = new AuthenticatedSecUserDTO(null, null);
  private authoritiesSet = new Set<string>();

  private refreshing  = false;
  private pendingRefresh = false;
  private intervalRefreshUserSubscription : Subscription;
  
  
  private HOME_URL = '/';
  
  private previousRestApi = this.HOME_URL;
  //private previousParams: ParamMap;

  constructor(private httpClient: HttpClient, 
				private tokenExtractor: HttpXsrfTokenExtractor, 
				private router:Router) {
        this.startIntervalRefreshUser();
  }
				
  login(secUser: SecUserDTO) : Observable<any> {
        var isNewUserRequest = ! this.interceptorSecUser  || this.interceptorSecUser.username !== secUser.username;
	
		if ( ! isNewUserRequest && this.isAuthenticated()) {
			console.log("user is already authenicated");
			return Observable.of( this.isAuthenticated() );
		}
 
        this.interceptorSecUser = secUser; // http interceptor service depends on this
		       
        console.log("authService::login", secUser, urls.moduleAuthUserUrl, this.authenticated);
	
       // tbd - need the login to run after an in progress run, don't want one request for one user to get in front of another
        return this.refreshUser();     
    }

  // authenticateUser checks to see if there is an interceptorSecUser before making http called
  // this just keeps running just in case there is something to authenticate
  startIntervalRefreshUser() {
      console.log("AuthService:delayedRefreshUser");
    
      if (this.intervalRefreshUserSubscription != null) {
        console.log("delayedRefreshSubscription::in progress already");
        return;
      }
      // property fils for interval amounts TBD
      // this is a service so never unsubscribe from interval observer
      this.intervalRefreshUserSubscription = Observable.interval(10 * 60 * 1000).subscribe(  x  => {
          console.log("AuthService::timer refresh", x);
          const refreshSubscription = this.refreshUser().subscribe( isAuthenticated  => {
              console.log("AuthService::timer results refreshUser", 
                this.intervalRefreshUserSubscription ,isAuthenticated);
              refreshSubscription.unsubscribe();
          });
      });

  }

 // TBD for user and list so far create service to periodically re-run requests to server?
  private refreshUser() : Observable<any> {
     console.log("AuthService::refreshUser called");
     // unless timer interval is set very low, this should only happen if new login request comes in during refreshUser
     if (this.refreshing === true) {
      console.log("AuthService::refreshUser is progress already");  
      this.pendingRefresh = true; 
      return;
     }
     // this is not 100 fool proof TBD look for some sort of lock mechanism TBD FIXME
     this.refreshing = true;
     this.pendingRefresh = false;
 

     return  this._authenticateUser().map( isAuthenticated => {

        console.log("AuthService::userSubscription", isAuthenticated);

        this.refreshing = false;
        if (this.pendingRefresh) {
            this.refreshUser();
        }
        return isAuthenticated;
    });

  }
    

    //  call refreshUser rather than _athenticateUser to handle parallel requests
    private _authenticateUser() : Observable<any> {
         // the interceptor uses the interceptorSecUser to do authentication
         if (this.interceptorSecUser === null) {
            console.log("authenicateUser::no user");
            return Observable.of(false);
         }
         return this.httpClient.get<AuthenticatedUserDTO>(urls.moduleAuthUserUrl).map(
        
         (json : AuthenticatedUserDTO) : boolean => {

			//only works for models w/o dates and functions
			var jsonObject = JSON.parse(JSON.stringify(json));
			let authenticatedUser = new AuthenticatedUserDTO();
			
			// convert to object using lodash 
			_.merge( authenticatedUser, jsonObject );
			
			console.log("jsonObject", authenticatedUser);
		    //console.log("login res authenticatedUserponse", authenticatedUser.authorities[0]['authority']);		    
            // make sure that the most recent login user is checked vs what is returned from the server
            var isNewUser = authenticatedUser['username'] !== this.interceptorSecUser.username;
			let authenticatedUserIsAuthenticated = authenticatedUser.isAuthenticated();

            // TBD fix me maybe use etag to see if changed
			if( isNewUser || this.authenticated !== authenticatedUserIsAuthenticated) {
                this.authenticated = authenticatedUserIsAuthenticated;
                this.authenticatedSubject.next( this.authenticated );
            }

            
            let authenticatedUserAuthoritiesSet = this.getAuthoritiesSet(authenticatedUser.authorities);
 
			authenticatedUserAuthoritiesSet = this.getAuthoritiesSet(authenticatedUser.authorities);
			
            // see if authorites has been updated, always true when there is a new user
            if ( isNewUser ||
                 _.xor( Array.from(this.authoritiesSet),  Array.from(authenticatedUserAuthoritiesSet) ).length !== 0 ) {
                this.authoritiesSet = authenticatedUserAuthoritiesSet;
                this.authoritiesSubject.next( authenticatedUserAuthoritiesSet );
            }
            

            if ( this.authenticated) {
                this.authenticatedSecUser = new AuthenticatedSecUserDTO(authenticatedUser, this.interceptorSecUser);
                
                       
                console.log("Authservice::navigating", this.previousRestApi, this.isAuthenticated(), this.authenticated);
                
                this.router.navigate([this.previousRestApi] );//{ queryParams: this.previousParams }); 
                // reset to default
                this.previousRestApi = this.HOME_URL;
                   // tbd fixme { queryParams: JSON.stringify(this.previousParams) });
            } else {
                this.logout();
            }
            return this.authenticated;
        });
    
    }

 
   private getAuthoritiesSet(authorities: Map<string, string>[]) : Set<string> {
        let newSet = new Set<string>();
        //let authorityMap:Map<string, string>;
        
        for (var i = 0; i < authorities.length; i++) {
        	 newSet.add( authorities[i]['authority']);   
        }
        
        console.log("getAuthoritiesSet", newSet);
        return newSet;
    }
    
   logout() {
        //TBD FIXME needs testing and spring side logoff
      /*this.httpClient.post('/auth/logout', this.secUser).finally(() => {
          this.authenticatedSecUser = null;
          this.authenticated = false;
          this.authoritiesSet = new Set<string>();
      }).subscribe();*/
           this.authenticatedSecUser = null;
          this.authenticated = false;
          this.authoritiesSet = new Set<string>();
    }
    
   savePreviousRestApiIfNotSet( previousRestApi: string) : void {
   //savePreviousRestApiIfNotSet( previousRestApi: string, previousParams?: ParamMap) : void {
        // only reset if pointing to specific url, not default
        if ( this.previousRestApi === this.HOME_URL) {
        	this.previousRestApi = previousRestApi;
        }
        console.log("previousRestApi::", this.previousRestApi , previousRestApi);
        //this.previousParams = previousParams;
    }
    

    public isAuthenticated() : boolean {
      console.log("isAuthenticated called", this.authenticated);
      return this.authenticated;
    }
    
    // for interceptor only
    public getInterceptorSecUser() : SecUserDTO {
       return this.interceptorSecUser;
    }

    public hasAuthority(authority: string) : boolean {
        console.log("AuthService::hasAuthority", authority, this.isAuthenticated());
        
        if (!this.authenticated) {
          return false;
        }
        
       console.log("AuthService::hasAuthority", authority, this.isAuthenticated(), this.authoritiesSet.has(authority));
	   return this.authoritiesSet.has(authority);
    }

    getAuthenticatedObservable() : Observable<boolean> {         
       return this.authenticatedObservable;
    }

    getAuthoritiesObservable() : Observable<Set<string>> {         
       return this.authoritiesObservable;
    }

    // only for intercept/guards
   /* subscribeAuthenticatedSecUser() : Observable<AuthenticatedSecUserDTO> {
       return this.authenticatedSecUserObservable;
    }*/


 }
