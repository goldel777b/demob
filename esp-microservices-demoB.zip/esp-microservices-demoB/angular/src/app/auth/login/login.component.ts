import { Component, OnInit } from '@angular/core';

import { FormGroup } from '@angular/forms';

import { ActivatedRoute, Router, Params } from '@angular/router';

import { Subscription } from 'rxjs/Subscription';

import { AuthService } from '../services/auth.service';
//import { ModalService } from '../../shared/core/services/modal.service';


import { SecUserDTO } from '../models/sec-user-dto.model';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit { //, OnDestroy {

  app = 'Login';
  
  secUser = new SecUserDTO('', '');
 
  
  constructor(private authService: AuthService,
              //private modalService: ModalService,
              private route: ActivatedRoute) {}

  ngOnInit() {
     //this.app = this.route.snapshot.queryParams['App'];
    
     console.log('LoginComponent::ngOnInit', this.app, this.route.snapshot.params); 
     
  
   }
  
//    need logout compoenent logout() {
//       
//     }
//  
     onSubmit() {
       console.log("LoginComponent::onSubmit", this.secUser);
       
        this.authService.login(this.secUser).subscribe( (response) => {
	        console.log("authService.login::called", response) 
	    });
		
         /* () => { console.log("authService.login::called") }
          //(error) => console.log("authService.login::error", error)
        );*/
     }
/*
    private bodyText = 'My error';


    openModal(id: string){
      this.modalService.open(id);
    }

    closeModal(id: string){
        this.modalService.close(id);
    }
    */
//   ngOnDestroy() {
//      console.log('ngOnDestroy called');
//      if (this.paramsSubscription != null) {
//        this.paramsSubscription.unsubscribe();
//      }
//   }

}


