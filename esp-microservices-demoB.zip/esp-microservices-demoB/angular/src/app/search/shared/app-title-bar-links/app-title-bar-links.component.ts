import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute, Params } from '@angular/router';
import { Subscription } from 'rxjs/Subscription';

@Component({
  selector: 'app-title-bar-links',
  templateUrl: './app-title-bar-links.component.html',
  styleUrls: ['./app-title-bar-links.component.css']
})
export class AppTitleBarLinksComponent implements OnInit {
  // tbd fixme - expect to come from the request, 
  // tbd fixme set to true for easy testing
  print: boolean = true;
  close: boolean = true;
  logout: boolean = true;
  
  private paramsSubscription: Subscription;
 
  constructor(private activatedRoute: ActivatedRoute) { }

	 ngOnInit() { 
	 
	    this.print   =  true; //this.activatedRoute.snapshot.queryParams["print"] != null;
	    this.close   =  true; //this.activatedRoute.snapshot.queryParams["close"] != null;
	    this.logout  =  true;//this.activatedRoute.snapshot.queryParams["logout"] != null;

	    // https://blog.angular-university.io/angular-2-router-nested-routes-and-nested-auxiliary-routes-build-a-menu-navigation-system/
	    // issue - no params on top menu TBD FIXME
	    console.log("AppTitleBarLinkComponent::ngOnInit enter", this.activatedRoute.snapshot.queryParams, this.print, this.close, this.logout);

	   
	    // subscribe to router event
	    this.paramsSubscription = this.activatedRoute.params.subscribe((params: Params) => {
		       this.print = true;// params['print'];
		       this.close = true;//params['close'];
		       this.logout = true;//params['logout'];
		       
			   console.log("AppTitleBarLinkComponent::ngOnInit paramsSubscription",
			    this.activatedRoute.snapshot.queryParams, params, this.print, this.close, this.logout);
	      });   
	     
	 }
 
     ngOnDestroy() {
         if (this.paramsSubscription != null) {
	     	this.paramsSubscription.unsubscribe();
	     }
	 } 

}
