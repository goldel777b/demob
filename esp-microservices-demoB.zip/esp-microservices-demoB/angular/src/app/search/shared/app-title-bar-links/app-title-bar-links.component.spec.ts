import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AppTitleBarLinksComponent } from './app--title-bar-links.component';

describe('AppTitleBarLinksComponent', () => {
  let component: AppTitleBarLinksComponent;
  let fixture: ComponentFixture<AppTitleBarLinksComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AppTitleBarLinksComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AppTitleBarLinksComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
