
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { AppTitleBarComponent } from './app-title-bar/app-title-bar.component';
import { AppTitleBarLinksComponent } from './app-title-bar-links/app-title-bar-links.component';
import { AppRouteNotFoundComponent } from './app-route-not-found/app-route-not-found.component';
import { MainFooterComponent } from './main-footer/main-footer.component';



@NgModule({
  imports: [
    CommonModule,
  ],
  declarations: [
    AppTitleBarComponent,
    AppTitleBarLinksComponent,
    AppRouteNotFoundComponent,
    MainFooterComponent,
  ],
  exports: [
    AppTitleBarComponent,
    AppTitleBarLinksComponent,
    AppRouteNotFoundComponent, 
    MainFooterComponent,
  ]
 })
export class SearchSharedModule { }
