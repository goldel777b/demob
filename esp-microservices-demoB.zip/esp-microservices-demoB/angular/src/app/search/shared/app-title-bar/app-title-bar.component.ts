import { Component, OnInit, OnDestroy } from '@angular/core';
import {Router, ActivatedRoute, Params, ParamMap, NavigationEnd} from '@angular/router';
import { Subscription } from 'rxjs/Subscription';
import { Location, LocationStrategy } from '@angular/common';

@Component({
  selector: 'app-title-bar',
  templateUrl: './app-title-bar.component.html',
  styleUrls: ['./app-title-bar.component.css']
})
export class AppTitleBarComponent implements OnInit, OnDestroy {
 
	 header = "";      // like 'Enterprise Solutions Platform'
	 subHeader = "";   // like 'Service Delivery'
	 contextName = ""; // like dni, ops
	 
	 private paramsSubscription : Subscription;
	 //private paramsMapSubscription : Subscription;
	 //private routerEventSubscription: Subscription;
	 
	 //tbd fixme move to property files or make static
	 private readonly OPS = "ops"; 
	 private readonly HEADER_DEFAULT = "Enterprise Solutions Platform";
	 private readonly NETWORK_OPERATIONS = "NETWORK OPERATIONS";
	 private readonly SERVICE_DELIVERY = "SERVICE DELIVERY";

     private headerParam: string;
     private subHeaderParam: string;
     
     constructor(private activatedRoute: ActivatedRoute, private router: Router, private locationStrategy: LocationStrategy) {}

     
	 ngOnInit() { 
	 
	    const header      =  this.activatedRoute.snapshot.queryParams["header"];
	    const subHeader   =  this.activatedRoute.snapshot.queryParams["subHeader"];
	    const contextName =  (this.locationStrategy.path().toLowerCase().indexOf(this.OPS) != -1 ? this.OPS : "");
	    
	    // save for later dyanmical comparison (vs defaults)
	    this.headerParam = header;
	    this.subHeaderParam = subHeader;
	
	    // https://blog.angular-university.io/angular-2-router-nested-routes-and-nested-auxiliary-routes-build-a-menu-navigation-system/
	    // issue - no params on top menu TBD FIXME
	    console.log("AppHeaderTitleBarComponent::ngOnInit enter", this.activatedRoute.snapshot.queryParams, "XXX", header, subHeader, contextName, 
	    		this.locationStrategy.path());
	   
		this.setValues( header, subHeader, contextName);

	    console.log("AppHeaderTitleBarComponent::ngOnInit after setValues", this.header, this.subHeader, this.contextName);
      
	    console.log("url", this.router.url); // array of states

	   
	    // subscribe to router event
	    this.paramsSubscription = this.activatedRoute.params.subscribe((params: Params) => {
	       this.headerParam = params['header'];
	       this.subHeaderParam = params['subHeader'];
	       
	       const contextName =  (this.locationStrategy.path().toLowerCase().indexOf(this.OPS) != -1 ? this.OPS : "");
	        
	  	   this.setValues( this.headerParam, this.subHeaderParam, contextName);
	       
	        console.log("AppHeaderTitleBarComponent::ngOnInit paramsSubscription", params, this.header, this.subHeader, this.contextName);
	      });   
	     
	     
	 }
  
	  // tbd may want to check if value changes before resetting
	  private setValues( header:string, subHeader:string, contextName:string) : void {
        this.header      = this.valueOrDefault(this.headerParam, this.HEADER_DEFAULT);  
   	    this.contextName = this.valueOrDefault(contextName, "");
    
        const subHeaderDefault = (this.contextName == this.OPS ? this.NETWORK_OPERATIONS : this.SERVICE_DELIVERY);
    
    	this.subHeader = this.valueOrDefault( this.subHeaderParam, subHeaderDefault);
  
	  }
	  
	  private valueOrDefault( param:string, defaultValue:string) : string {
	     console.log("valueOrDefault", param, defaultValue);
	     if (param != null && param != "") {
	        return param;
	     }
	     return defaultValue;   
	  }

	
	  ngOnDestroy() {
	     this.paramsSubscription.unsubscribe();
	     //this.paramsMapSubscription.unsubscribe();
	     //this.routerEventSubscription.unsubscribe();
	  }
}
