import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AppRouteNotFoundComponent } from './app-route-not-found.component';

describe('AppRouteNotFoundComponent', () => {
  let component: AppRouteNotFoundComponent;
  let fixture: ComponentFixture<AppRouteNotFoundComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AppRouteNotFoundComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AppRouteNotFoundComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
