import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-app-route-not-found',
  templateUrl: './app-route-not-found.component.html',
  styleUrls: ['./app-route-not-found.component.css']
})
export class AppRouteNotFoundComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
