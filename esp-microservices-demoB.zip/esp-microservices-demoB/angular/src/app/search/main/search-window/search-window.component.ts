import { Component, OnInit } from '@angular/core';


import { configuration, Source, App } from '../../../../environments/environment'


@Component({
  selector: 'app-search-window',
  templateUrl: './search-window.component.html',
  styleUrls: ['./search-window.component.css']
})
export class SearchWindowComponent implements OnInit {
  private isPreSalesOrderTool = configuration.app.toString() === App.PRE_SALES_ORDER;
  private isDocRepository     = configuration.app.toString() === App.DOC_REPOSITORY;
  private isNewUI             = configuration.source.toString() === Source.NEW_UI;
  
  constructor() { }

  ngOnInit() {
  }

}
