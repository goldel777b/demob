import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MainComponent } from './main.component';
//import { SearchWindowComponent } from './search-window/search-window.component';


// TBD FIXME make this conditional
import { SearchDniModule } from '../dni/search-dni.module';


@NgModule({
  imports: [
    CommonModule,
    SearchDniModule,
   ],
  declarations: [
   	MainComponent, 
  	//SearchWindowComponent, 
  ],
  exports: [
  	MainComponent,
  ]
})
export class MainModule { }
