import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-di-search-panel-view',
  templateUrl: './di-search-panel-view.component.html',
  styleUrls: ['./di-search-panel-view.component.css']
})
export class DiSearchPanelViewComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
