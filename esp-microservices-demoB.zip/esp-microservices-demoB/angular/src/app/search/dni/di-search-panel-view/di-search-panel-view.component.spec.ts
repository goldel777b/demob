import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AppDniSearchPanelViewComponent } from './app-dni-search-panel-view.component';

describe('AppDniSearchPanelViewComponent', () => {
  let component: AppDniSearchPanelViewComponent;
  let fixture: ComponentFixture<AppDniSearchPanelViewComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AppDniSearchPanelViewComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AppDniSearchPanelViewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
