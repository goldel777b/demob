import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AppHeaderDniComponent } from './app-header-dni.component';

describe('AppHeaderDniComponent', () => {
  let component: AppHeaderDniComponent;
  let fixture: ComponentFixture<AppHeaderDniComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AppHeaderDniComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AppHeaderDniComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
