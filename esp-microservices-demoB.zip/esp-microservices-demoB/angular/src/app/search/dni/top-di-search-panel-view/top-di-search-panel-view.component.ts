import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-top-di-search-panel-view',
  templateUrl: './top-di-search-panel-view.component.html',
  styleUrls: ['./top-di-search-panel-view.component.css']
})
export class TopDiSearchPanelViewComponent implements OnInit {

  constructor() { }

  ngOnInit() {
     console.log('top-di-search-panel-view ngOnInit');
  }

}
