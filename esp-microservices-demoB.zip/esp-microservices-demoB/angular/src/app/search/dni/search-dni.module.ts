import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';

//import { AppTitleBarComponent } from '../shared/app-title-bar/app-title-bar.component';
//import { AppTitleBarLinksComponent } from '../shared/app-title-bar-links/app-title-bar-links.component';
import { SearchSharedModule } from '../shared/search-shared.module';  // include in every micro-service


import { DiSearchDetailNewViewComponent    }  from './di-search-detail-new-view/di-search-detail-new-view.component';
import { TopDiSearchPanelViewComponent } from './top-di-search-panel-view/top-di-search-panel-view.component';
import { DiSearchPanelViewComponent } from './di-search-panel-view/di-search-panel-view.component';


//import { BreadcrumbModule } from '../../bread-crumb/bread-crumb.module';


@NgModule({
  imports: [
    CommonModule,
    RouterModule,
	SearchSharedModule,
	//BreadcrumbModule,
  ],
  declarations: [
     DiSearchDetailNewViewComponent,
  	 TopDiSearchPanelViewComponent,
     DiSearchPanelViewComponent,
  ],
  exports: [
     DiSearchDetailNewViewComponent,
  	 //TopDiSearchPanelViewComponent,
  	 //DiSearchPanelViewComponent,
  ]
})
export class SearchDniModule { }
