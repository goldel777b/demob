import { Component, OnInit } from '@angular/core';

import { configuration, App } from '../../../../environments/environment'


@Component({
  selector: 'app-di-search-detail-new-view',
  templateUrl: './di-search-detail-new-view.component.html',
  styleUrls: ['./di-search-detail-new-view.component.css']
})
export class DiSearchDetailNewViewComponent implements OnInit {

  private isDni = configuration.app.toString() === App.DNI;
  
  constructor() { }

  ngOnInit() {
  }

}
