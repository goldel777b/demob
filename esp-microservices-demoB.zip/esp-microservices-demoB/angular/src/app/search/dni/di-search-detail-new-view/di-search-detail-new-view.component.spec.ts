import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SearchDetailNewViewComponent } from './search-detail-new-view.component';

describe('SearchDetailNewViewComponent', () => {
  let component: SearchDetailNewViewComponent;
  let fixture: ComponentFixture<SearchDetailNewViewComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SearchDetailNewViewComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SearchDetailNewViewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
