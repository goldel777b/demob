import { NgModule, ModuleWithProviders } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ModalComponent } from './core/directives/modal.component';
//import { ModalDirective } from './core/directives/modal.directive';
import { ModalService } from './core/services/modal.service';
import { AccessErrorComponent } from './core/access-error/access-error.component';
import { SafeUrlPipe } from './core/pipes/safe-url.pipe';

@NgModule({
  imports: [
    CommonModule
  ],
  declarations: [
    ModalComponent,
    AccessErrorComponent,
    SafeUrlPipe
  ], 
  exports: [
    ModalComponent,
    AccessErrorComponent,
    SafeUrlPipe,
  ]
})
export class SharedModule {// keep services singleton access at this level
  // https://angular.io/guide/module-types
     static forRoot(): ModuleWithProviders {
     return {
        ngModule: SharedModule,
        // forces a singleton across the whole application
        providers: [
          ModalService,
        ]
     }
   }
  

}
