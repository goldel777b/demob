import { 
        Directive,  
        ElementRef, 
        Renderer2,
        Input,
        ViewChild,
        OnInit, 
        OnDestroy } from '@angular/core';
//import ( * ) as $ from 'jquery';
 
import { ModalService } from '../services/modal.service';

@Directive({
    //moduleId: module.id.toString(),
    selector: '[ modal ]',
    //template: '<ng-content></ng-content>'
})
//https://codecraft.tv/courses/angular/custom-directives/creating-a-custom-directive/
export class ModalDirective implements OnInit, OnDestroy {
    @Input() id: string;
    //private element: JQuery;

    //@ViewChild('abcd') 
    //private abcd: ElementRef;	

    // used to remove listener
    private listenRemoveFunc: Function;
    //private globalListenRemoveFunc: Function;

    constructor(private modalService: ModalService, 
        private elementRef: ElementRef,
        private renderer: Renderer2) {
        
        //this.element = elementRef.nativeElement;
        //this.renderer.addClass(this.elementRef.nativeElement, 'modalClass');
        //this.renderer.invokeElementMethod(this.elementRef.nativeElement, 'focus');
    }

    ngOnInit(): void {
        console.log('ModalDirective::ngOnInit');

        let modal = this;

        if (!this.id) {
            console.error('modal must have an id');
            return;
        }

        // move element to bottom of page (just before </body>) so it can be
        // displayed above everything else
        //this.element.appendTo('body');
        
        this.renderer.appendChild(this.elementRef, "body");
        // close modal on background click
        /*this.element.on('click', function (e: any) {
            var target = $(e.target);
            if (!target.closest('.modal-body').length) {
                modal.close();
            }
        });*/
        /*<script>alert('<%=accessError%>');window.close();</script>
        */
        let element = this.renderer.createElement("div");
        let text = "<script>alert('<%=accessError%>');window.close();</script>";

        element.add(text);

        // https://stackoverflow.com/questions/35080387/dynamically-add-event-listener-in-angular-2
        this.listenRemoveFunc = this.renderer.listen(this.elementRef.nativeElement, 'click', ( event: any) => {
            console.log('click event', event);
            var target = event.target;// do I need jquery

            if (!target.closest('.modal-body').length) {
                modal.close();
            }          
        });


        // add self (this modal instance) to the modal service so it's accessible from controllers
        this.modalService.add(this);
    }


    ngOnDestroy(): void {
        console.log('ModalDirective::ngOnDestroy');

        this.modalService.remove(this.id);

        //this.elementRef.remove();

        this.listenRemoveFunc();
    }

    // open modal
    open(): void {
        
        //this.elementRef.show();
        //$('body').addClass('modal-open');
        console.log('ModalDirective::open');
        this.renderer.addClass(this.elementRef, 'modal-open',);
    }

    // close modal
    close(): void {
        console.log('ModalDirective::close');
        //this.element.hide();
        //$('body').removeClass('modal-open');
        this.renderer.removeClass(this.elementRef, 'modal-open',);
    }
}
