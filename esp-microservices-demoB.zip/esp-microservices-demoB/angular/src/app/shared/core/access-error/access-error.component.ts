import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-access-error',
  templateUrl: './access-error.component.html',
  styleUrls: ['./access-error.component.css']
})
export class AccessErrorComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
