
import { find, findWhere, without } from 'underscore';

export class ModalService {
    private modals: any[] = [];


    open(id: string) {
        console.log("ModalService::open", id);
        let modal = findWhere(this.modals, { id: id });
        console.log("ModalService::open", modal);

        modal.open();
    }

    close(id: string) {
        console.log("ModalService::close", id);
        let modal = find(this.modals, { id: id });
        
        modal.close();
    }    
      
    add(modal: any) {
      console.log("ModalService::add", modal);
      this.modals.push(modal);
    }

    remove(id: string) {
      console.log("ModalService::remove", id);
      let modalToRemove = findWhere(this.modals, { id: id });

      this.modals = without(this.modals, modalToRemove);
    }
}
