import { Component, OnInit } from '@angular/core';
import { Location, LocationStrategy } from '@angular/common';


@Component({
  selector: 'app-app-route-not-found',
  templateUrl: './app-route-not-found.component.html',
  styleUrls: ['./app-route-not-found.component.css']
})
export class AppRouteNotFoundComponent implements OnInit {

  constructor(private locationStrategy: LocationStrategy) { }

  ngOnInit() {
    console.log("APP AppRouteNotFoundComponent", this.locationStrategy.path());
  }

}
