
// https://stackoverflow.com/questions/38879529/how-to-route-to-a-module-as-a-child-of-a-module-angular-2-rc-5
import { Routes, RouterModule } from '@angular/router';
import { ModuleWithProviders, NgModule } from '@angular/core';


import { AuthGuardService } from '../auth/services/auth-guard.service'

// this is already declared as a 'shared module'... TBD should it get routed
import { AppRouteNotFoundComponent } from '../search/shared/app-route-not-found/app-route-not-found.component';
 
 import { authRoutes } from '../auth/auth-routing.module';
 import { configNetTypeRoutes } from '../config-net-type/config-net-type-routing.module';
 

// LoriGo Notes:: turn off lazy load to test routes or restart every time you make a change
//                 Please make sure to add imports for all child routes here
//                see // https://stackoverflow.com/questions/38879529/how-to-route-to-a-module-as-a-child-of-a-module-angular-2-rc-5
//                 These alternatives that did not work for me:
//                     https://medium.com/@kouipheng.lee/lazy-loading-with-angular-4-29c23792b7f4 https://medium.com/@kouipheng.lee/lazy-loading-with-angular-4-29c23792b7f4
//                     Angular7 issue https://stackoverflow.com/questions/48991372/angular-error-uncaught-in-promise-at-webpackasynccontext-eval-at-src/49135044#49135044
// LoriGo Notes disclaimer:  this is my best answer at the time of writing, please keep the "Go Notes" up-to-date

// LoriGo Notes:  if you change the lazy child routes, you will need to restart
//                also you need to be at version 7.2 of the Cli or better for lazy loading to work
//                https://stackoverflow.com/questions/48947314/lazy-load-angular-5-error-lazy-route-resource-lazy-recursive/49165399#49165399


//import { AuthModule } from '../auth/auth.module';

import { AuthComponent } from '../auth/auth.component';
import { LoginComponent } from '../auth/login/login.component';
import { DiSearchDetailNewViewComponent } from '../search/dni/di-search-detail-new-view/di-search-detail-new-view.component';

import { ConfigNetTypeComponent } from '../config-net-type/config-net-type.component';
import { ConfigNetTypeCreateComponent } from '../config-net-type/config-net-type-create/config-net-type-create.component';
import { ConfigNetTypeEditComponent } from '../config-net-type/config-net-type-edit/config-net-type-edit.component';
import { ConfigNetTypeListComponent } from '../config-net-type/config-net-type-list/config-net-type-list.component';
import { ConfigNetTypeDeleteComponent } from '../config-net-type/config-net-type-delete/config-net-type-delete.component';

const appRoutes: Routes = [

	        {
	            path: 'auth',
				canActivate: [ AuthGuardService],//for testing needs better set-up
	            //loadChildren: 'app/auth/auth.module#AuthModule',
				children: [...authRoutes],
	        },
	        // TBD add Role Guards to /dni
	        {
	            // dni/xxx if xxx is not found, will show dni page with no content
	           	path: 'dni',
	            component: DiSearchDetailNewViewComponent,
				canActivate: [ AuthGuardService],//for testing
		        //loadChildren: 'app/config-net-type/config-net-type.module#ConfigNetTypeModule',
			    children: [...configNetTypeRoutes],
			},
			// this is assuming that the only service provided by this app is dni
	        {
	           
	            path: '',
				redirectTo: 'dni',
				pathMatch: 'full',
				canActivate: [ AuthGuardService],//for testing
	        },
	        // this picks up any non-'auth', non-'dni' urls
	        {
		    	path: '**',
		    	component: AppRouteNotFoundComponent
		     }
];
 
//export const appRoutes: ModuleWithProviders = RouterModule.forRoot(appRoutes);


@NgModule({  //https://angular.io/api/router/RouterModule errorHandler 
    imports: [
		    RouterModule.forRoot(appRoutes, 
		    	{ enableTracing: true,
		    	  useHash: true,
		    	  //paramsInheritanceStrategy: 'always'
		        })
    	  ],
    exports: [ RouterModule ]
})
export class AppRoutingModule { }
