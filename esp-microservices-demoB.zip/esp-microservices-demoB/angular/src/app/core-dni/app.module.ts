
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AppBootstrapModule } from '../app-bootstrap/app-bootstrap.module';
import { HttpClientModule  } from '@angular/common/http';
import { RouterModule } from '@angular/router';
//import { FormsModule } from '@angular/forms'; //ReactiveFormsModule

// this micro-service
import { AppComponent } from './app.component';
import { AppRoutingModule } from './app.routing';

import { MainModule } from '../search/main/main.module';

import { SharedModule } from '../shared/shared.module';

/* include modules related to the services you want to be available in the micro-service */
import { SearchSharedModule } from '../search/shared/search-shared.module';  // include in every micro-service
//import { SearchDniModule } from '../search/dni/search-dni.module';

/* include which sub modules services are needed globally */
import { AuthModule } from '../auth/auth.module';  // include in every micro-service
import { ConfigNetTypeModule } from '../config-net-type/config-net-type.module';


@NgModule({
  imports: [
    BrowserModule,
    CommonModule,
    HttpClientModule,
   
    //appRouting,
    AppRoutingModule, 

    SearchSharedModule,
    //SearchDniModule, // eager module - configure each module that belongs to this micro-service TBD isolate the selector in the generic code 
    MainModule,
    
    SharedModule,
    
    //for shared services    
    //SharedModule.forRoot(),
    AuthModule.forRoot(),
    ConfigNetTypeModule.forRoot()
  ],
  declarations: [
    AppComponent,    
  ],
  exports: [
	AppComponent,
 ],
  bootstrap: [AppComponent]
})
export class AppModule { }

/*platformBrowserDynamic().bootstrapModule(AppModule);*/