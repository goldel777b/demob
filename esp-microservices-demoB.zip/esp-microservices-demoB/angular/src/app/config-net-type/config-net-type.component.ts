import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-config-net-type',
  templateUrl: './config-net-type.component.html',
  styleUrls: ['./config-net-type.component.css']
})
export class ConfigNetTypeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
     console.log("ConfigNetTypeComponent::ngOnInit");
  }

}
