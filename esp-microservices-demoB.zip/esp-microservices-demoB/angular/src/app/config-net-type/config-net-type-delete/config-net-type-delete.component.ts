import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute, Params, Router } from '@angular/router';

import { Observable} from 'rxjs/Observable';
import { Subscription } from 'rxjs/Subscription';
import { FormsModule, NgForm } from '@angular/forms'; //ReactiveFormsModule


//import { FormArray, FormControl, FormGroup, Validators } from '@angular/forms';


import { ConfigNetTypeService } from '../services/config-net-type.service';
import { ConfigNetTypeDTO } from '../models/config-net-type-dto.model';

// for lodash
//npm install --save lodash
//npm install --save @types/lodash
import * as _ from "lodash";


@Component({
  selector: 'app-config-net-type-delete',
  templateUrl: './config-net-type-delete.component.html',
  styleUrls: ['./config-net-type-delete.component.css']
})
export class ConfigNetTypeDeleteComponent implements OnInit, OnDestroy {
  paramNetType: string;
  // tbd how to pass boolen t front end
  configNetType: ConfigNetTypeDTO;
  
//  getSubscription: Subscription = null;
  deleteSubscription: Subscription = null;
//  paramsSubscription: Subscription;
  
  constructor(private configNetTypeService: ConfigNetTypeService, private router:Router, private route: ActivatedRoute) {}

  ngOnInit() { 
  
     console.log("ngInit delete"); 
  
     //this.paramNetType = this.route.snapshot.params['netTypes'];
    
     console.log("config-net-type-delete ngOnInit", this.route.snapshot.params);
        
    /*this.route.queryParams
      .subscribe( (params : Params) => {
        console.log("subscibe queryParams", params); // {order: "popular"
       });*/
    
  }
 /*
 // TBD FIXME want to have spring check existence, need to pass who ConfigNetType class and/or unique id + etag
  //TBD FIXME review what params changing means -> did they navigate off the page or? is this one shared instance? 
//  private subscribeToGetSubscription() {
//    
////       if  (this.getSubscription != null) {
////         this.getSubscription.unsubscribe();
////       }
////       this.getSubscription = this.configNetTypeService.get(this.paramNetType).subscribe (
////          data => {
////            console.log("getting::".concat(this.paramNetType));
////            console.log(data);
////            this.configNetType = data;
////            this.subscribeToDeleteSubscription();
////          });
////      
//  }
  
    private subscribeToDeleteSubscription() {
    
       if  (this.deleteSubscription != null) {
         this.deleteSubscription.unsubscribe();
       }
       this.deleteSubscription = this.configNetTypeService.delete(this.configNetType.netType).subscribe (
          data => {
            console.log("deleting::".concat(this.paramNetType));
            console.log(data);
            this.router.navigate(['configNetType', 'list'], { queryParamsHandling: 'preserve'});
           });
      
  }
  */
   
   onSubmit(json) { // w/o #f only -> ElementRef) { //NgForm)  {  
      console.log("DELETE onSubmit json", json);
      
   	  var jsonObject = JSON.parse(JSON.stringify(json));
   	  var deleteEntryValues : { [key:string]: boolean; } = {};
   	
   	  console.log("onSubmit jsonObject", jsonObject);
   	  
	  // convert to object using lodash 
	  _.merge( deleteEntryValues, jsonObject );
   
      console.log("onSubmit deleteEntryValues", deleteEntryValues);
   	  
    
      for (var key in deleteEntryValues) {
         console.log('next::', key, deleteEntryValues[key]);
      };

   
     for (var netType in deleteEntryValues) {
         if (! deleteEntryValues[netType] ) {
           // shouldn't get here
           console.log('skipping', netType,  deleteEntryValues[netType] );
           return;
         }
         console.log("Will delete", netType,  deleteEntryValues[netType] );
       
         //Subscription deleteSubscription; use an array and store this so that can unsubscribe
          
          // may sure this is a new variable each time wih same name TBD...
         var deleteSubscription = this.configNetTypeService.delete(netType).subscribe (
            resp => {
              console.log("deleted::", netType);
              console.log(resp);
              deleteSubscription.unsubscribe();
              //this.router.navigate(['configNetType', 'list'], { queryParamsHandling: 'preserve'});
            });
     };
  }
  
  
  ngOnDestroy() {
    console.log('ngOnDestroy called');
    if (this.deleteSubscription != null) {
      this.deleteSubscription.unsubscribe();
    }
  }
}
