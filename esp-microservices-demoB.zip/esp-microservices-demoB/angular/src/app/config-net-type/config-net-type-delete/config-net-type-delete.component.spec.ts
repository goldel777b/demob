import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ConfigNetTypeDeleteComponent } from './config-net-type-delete.component';

describe('ConfigNetTypeDeleteComponent', () => {
  let component: ConfigNetTypeDeleteComponent;
  let fixture: ComponentFixture<ConfigNetTypeDeleteComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ConfigNetTypeDeleteComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ConfigNetTypeDeleteComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
