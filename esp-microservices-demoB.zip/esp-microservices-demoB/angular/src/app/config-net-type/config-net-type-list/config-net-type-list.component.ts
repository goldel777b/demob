import { Component, ViewChild, OnInit, OnDestroy, ElementRef, NgModule, VERSION } from '@angular/core';
import { RequestOptions } from '@angular/http';
import { NgForm  } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';

import { Observable } from 'rxjs/Observable';
import { Subscription } from 'rxjs/Subscription';

import { ConfigNetTypeService } from '../services/config-net-type.service';
import { ConfigNetTypeDTO } from '../models/config-net-type-dto.model';

import 'rxjs/add/operator/map';

// for lodash
//npm install --save lodash
//npm install --save @types/lodash
import * as _ from "lodash";

@Component({
  selector: 'app-config-net-type-list',
  templateUrl: './config-net-type-list.component.html',
  styleUrls: ['./config-net-type-list.component.css'], 
})
export class ConfigNetTypeListComponent implements OnInit, OnDestroy {
  configNetTypeList:  Array<ConfigNetTypeDTO>;
  //test: "TESTING";
  //configNetTypeDeleteList: Array<DeleteCheckBox>;
  private getAllSubscription: Subscription;
  private deleteSubscription: Subscription;
  
  //f: NgForm; // TBD 
   @ViewChild('f') listForm: NgForm;

  
  constructor(private configNetTypeService: ConfigNetTypeService, private router: Router, private route:ActivatedRoute) { }

  ngOnInit() {
    console.log("ConfigNetTypeListComponent::ngOnInit", `Angular! v${VERSION.full}`);
   
     this.getAllSubscription = this.configNetTypeService.getAll().subscribe( list => {
        
        console.log(list);
        this.configNetTypeList = list;
    });
    //console.log("ConfigNetTypeComponent::ngOnInit exit");
  }
  
  check(e) {
    console.log(e);
  }
  
 
   onSubmit(json) { // w/o #f only -> ElementRef) { //NgForm)  {  
      console.log("onSubmit json", json);
      
   	  var jsonObject = JSON.parse(JSON.stringify(json));
   	  var deleteEntryValues = new Map<string, boolean>(); //{ [key:string]: boolean; } = {};
   	
   	  console.log("onSubmit jsonObject", jsonObject);
   	  
	  // convert to object using lodash 
	  _.merge( deleteEntryValues, jsonObject );
   
      console.log("onSubmit deleteEntryValues", deleteEntryValues);
  
      this.deleteSubscription = this.configNetTypeService.deleteUsingKeys( deleteEntryValues ).subscribe( (resp) =>
        {
        	console.log("deletion resp", resp);
        },
        (error) =>
        {
        	console.log("deletion resp error", error);
        
        });

     
  }
  

  ngOnDestroy() {
    if (this.getAllSubscription != null) {
      this.getAllSubscription.unsubscribe();
    }
    if (this.deleteSubscription != null) {
    	this.deleteSubscription.unsubscribe();
    }
  }

}


