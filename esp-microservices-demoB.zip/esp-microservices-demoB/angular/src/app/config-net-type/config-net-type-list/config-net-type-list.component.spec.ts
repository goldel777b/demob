import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ConfigNetTypeListComponent } from './config-net-type-list.component';

describe('ConfigNetTypeListComponent', () => {
  let component: ConfigNetTypeListComponent;
  let fixture: ComponentFixture<ConfigNetTypeListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ConfigNetTypeListComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ConfigNetTypeListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
