
import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpXsrfTokenExtractor } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';

 // "//observable/Observable";
//import { IntervalObservable } from "rxjs/observable/IntervalObservable";
import { IntervalObservable } from "rxjs/observable/IntervalObservable";
import {TimerObservable} from "rxjs/observable/TimerObservable";

import { Subscription } from 'rxjs/Subscription';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';


import 'rxjs/add/observable/forkJoin';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/toPromise';
import "rxjs/add/observable/interval";
import 'rxjs/add/observable/of';
import 'rxjs/add/operator/delay';

import { urls } from '../../../environments/environment';

import { ConfigNetTypeDTO } from '../models/config-net-type-dto.model';


// for lodash
//npm install --save lodash
//npm install --save @types/lodash
import * as _ from "lodash";


//https://www.lucidchart.com/techblog/2016/11/08/angular-2-and-observables-data-sharing-in-a-multi-view-application/

// Only Components and Directives have lifecycle hooks
@Injectable()
export class ConfigNetTypeService  { //implements OnInit, OnDestroy {

  private configNetTypeSubject = new BehaviorSubject<ConfigNetTypeDTO[]>(undefined);
  private configNetTypeList : ConfigNetTypeDTO[] = [];
  // make sure this can be shared across components or need one for each call XXX TBD
  private configNetTypeObservable = this.configNetTypeSubject.asObservable();
  private listSubscription : Subscription;
  private refreshSubscription : Subscription;

  private refreshing  = false;

  
  // TBD put in a Behavior subject for each update or share the one... using flag if in progress??
  // get should use array XXX edit, delete,create could do a local update and next  XXX
  // TBD switch all to behavior subjects so that traffic etc can be recorded
  constructor(private httpClient: HttpClient, private tokenExtractor: HttpXsrfTokenExtractor) {
     console.log("ConfigNetTypeService:constructor");
	 

     this.refreshList();

     // TBD set from properties
    this.refreshSubscription = Observable.interval(3 * 1000 * 60).subscribe((x) => {
          console.log("ConfigNetTypeServcie::timer refresh")
          this.refreshList();
     });
  }

  /* subject related */
  // keep in mind there may be multiple instances of Angular running, each will have its own service
  private refreshList() : void {
     console.log("ConfigNetTypeService::refresh called");

     if (this.refreshing === true) {
      console.log("ConfigNetTypeService::refresh is progress already");
      return;
     }
     this.refreshing = true;

     this.listSubscription = this.list().subscribe( list => {

        console.log("ConfigNetTypeService::listSubscription", list);
        console.log("list xor",  _.difference(this.configNetTypeList, list) );
        // TBD this is not working - store latest etag... but also, use the etag to determine if a new list is needed - do on server side
        if ( _.xor( this.configNetTypeList, list).length == 0) {
          console.log("ConfigNetTypeService::listSubscription no updates");
        }
        else {
          this.configNetTypeList = list;
          //this.configNetTypeSubject.next( list );
          console.log("ConfigNetTypeService::listSubscription updates");
          this.configNetTypeSubject.next( list );
        }

        // let the front end know a refresh has happened
        this.refreshing = false;


        // TBD properties filed
       // TBD  if added next() in any other place - use a flag/lock to prevent it from runing on top of each other!

    });

  }


  private list() : Observable<ConfigNetTypeDTO[]> {
    // default behavior is responseType: 'json' (vs 'blob', 'arraybuf', 'text'), observe: 'body' (vs 'response')
    
   // return this.httpClient.get<ConfigNetTypeDTO[]>('http://166.50.223.191:8090/configNetType/list');
    return this.httpClient.get<ConfigNetTypeDTO[]>(urls.dniConfigNetTypeList);
  }

  /* end subject related */

 //TBD hash/etag on list, only update list when it changes...
  getAll() : Observable<ConfigNetTypeDTO[]> {
    // refresh is happening so quickly that edit is not yet in place..

    this.refreshList();
    // observer on Behavior subject => automatic updates on front end
    // user will see what is in database + any local 'dirty' creates, any create that fails will disappear when the refresh happens, alternative
    // have the local componet add the new class to the returned array... sorting issue as well TBD
    return this.configNetTypeObservable;
  }
  
  
   // if you are editing something, you really don't want updates overwriting your changes as you are making them
   // so from this point to the user, he is separated from the shared via a copy of the original object
   get(netType: string) : ConfigNetTypeDTO {
	      if (this.configNetTypeList.length != 0) { 
		    this.refreshList();
		    // for large lists, store list as map?? TBD
		    // make a copy for display, avoid dirty reads
		    // handle missign from list error
		    return Object.assign({}, this.configNetTypeList.find( c => c.netType === netType));
	      }

	    // okay there was a restart etc... lets see if list is coming now
	    // still need to handle eror
	    this.getAll().subscribe( () => {
	       console.log("waiting on get");
	       return Object.assign({}, this.configNetTypeList.find( c => c.netType === netType));
	    });
	    
	}

   //TBD error handling, concurrent issue, database as ultimate source? look at how distrib db is doing
  create(configNetType: ConfigNetTypeDTO) : Observable<any> { 
    // TBD properties
    //let headers = new HttpHeaders({ 'Content-Type': 'application/json' });
    //let options = new RequestOptions({ headers: cpHeaders });
    var url = "http://166.50.223.191:8090/configNetType/doCreate";
    console.log('config-net-type.services::doCreate', configNetType, url);

    return this.httpClient.put<ConfigNetTypeDTO>(urls.dniConfigNetTypeCreate, configNetType ).map( x => {
        this.refreshList();
        return x;
    });
  }

  //post(url: string, body: any, options?: RequestOptionsArgs) : Observable<Response>
  edit(configNetType: ConfigNetTypeDTO) : Observable<any> {
    // TBD properties
    //let headers = new HttpHeaders({ 'Content-Type': 'application/json' });
    //let options = new RequestOptions({ headers: cpHeaders });
    //var url = "http://166.50.223.191:8090/configNetType/doEdit";

    console.log('config-net-type.services::edit', configNetType, urls.dniConfigNetTypeEdit);
    
    return this.httpClient.post<ConfigNetTypeDTO>(urls.dniConfigNetTypeEdit, configNetType ).map( x => {
        this.refreshList();
        return x;
    });
  }

  deleteUsingKeys( deletionsMap: Map<string, boolean>) : Observable<any> {
        var observables = [];
       
        console.log("deleteUsingKeys", deletionsMap);
  		for (let key in deletionsMap) {
  		    //let key = value.key
  		    console.log('deleteUsingKeys', key);
  			observables.push(this.delete(key));
  	    }
  	   
  	    //https://stackoverflow.com/questions/46388455/sequential-subscription-to-an-array-of-observables
        return Observable.forkJoin(...observables).map(
               (res:Array<any>) => {
                    console.log('deleteUsingKeys subscribe', res);
	                return res;
               }, 
               (error: any) => {
                    console.log('deleteUsingKeys subscribe error', error);
	                return error;
               }, 
        );
  }
  
  
  //TBD error handling, concurrent issue, database as ultimate source? look at how distrib db is doing
  // https://github.com/angular/angular/issues/19438 delete does not have a body and maybe rightly so, so would pass the configNetTYpe in the url
  // and add the etag for concurrency .. for now though run it as a put
  delete(netType: string) : Observable<any> {
     var configNetType = this.get(netType);
     
     // tbd handle missing netType FIXME
     
    //var url = "http://166.50.223.191:8090/configNetType/doDelete";
    console.log('config-net-type.services::doDelete', configNetType, urls.dniConfigNetTypeEdit);

    return this.httpClient.put<ConfigNetTypeDTO>(urls.dniConfigNetTypeDelete, configNetType).map( x => {
        this.refreshList();
        return x;
    });;
    // use id + delete + etag TBD return this.httpClient.delete<ConfigNetTypeDTO>(urls.dniConfigNetTypeEdit.concat(configNetType.id));
  }

}
