import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ConfigNetTypeEditComponent } from './config-net-type-edit.component';

describe('ConfigNetTypeEditComponent', () => {
  let component: ConfigNetTypeEditComponent;
  let fixture: ComponentFixture<ConfigNetTypeEditComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ConfigNetTypeEditComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ConfigNetTypeEditComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
