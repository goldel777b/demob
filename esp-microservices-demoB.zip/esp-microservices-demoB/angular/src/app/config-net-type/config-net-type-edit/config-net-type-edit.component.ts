import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Params, Router } from '@angular/router';

import {FormGroup} from '@angular/forms';

import { Observable} from 'rxjs/Observable';
import { Subscription } from 'rxjs/Subscription';

import { ConfigNetTypeService } from '../services/config-net-type.service';
import { ConfigNetTypeDTO } from '../models/config-net-type-dto.model';



@Component({
  selector: 'app-config-net-type-edit',
  templateUrl: '../shared/config-net-type-create-edit.component.html',
  styleUrls: ['./config-net-type-edit.component.css']
})
export class ConfigNetTypeEditComponent implements OnInit {
 
  paramNetType: string;

  configNetType: ConfigNetTypeDTO;
  
  //paramsSubscription: Subscription;
  
  constructor(private configNetTypeService: ConfigNetTypeService, private router:Router, private route: ActivatedRoute) {}

  ngOnInit() {
    
     console.log('ConfigNetTypeEditComponent ngOnInit', this.router.url);
     this.paramNetType = this.route.snapshot.params['netType'];
    
     // handle non-existence in validation TBD
     this.configNetType = this.configNetTypeService.get(this.paramNetType);
     // TBD where to initialize isNew
     this.configNetType.isNew = 'false';
    
     console.log("ConfigNetTypeEditComponent", this.configNetType);
  }

// TBD uncomment if needed - protection again future use of same url on the same page as edit url page - angulars won't rel// params is Observable to monitor change in params
//     this.paramsSubscription = this.route.params.subscribe(
//       (params: Params) => {
//          this.paramNetType = params['netType'];
//         
//          getGetSubscription();
//       }
//     );
//  }
  
  
//  ngOnDestroy() {
//    console.log('ngOnDestroy called');
//    if (this.paramsSubscription != null) {
//      this.paramsSubscription.unsubscribe();
//    }
//  }

  
  onSubmit()  {  
    console.log('ConfigNetTypeEditComponent submit', this.configNetType);   

       this.configNetTypeService.edit(this.configNetType).subscribe (
          (resp) => {
            console.log("ConfigNetTypeEditComponent edit complete::", resp, this.configNetType);
            this.router.navigate(['../../list'], { relativeTo: this.route, queryParamsHandling: 'preserve'});
          },
          // TBD return error msg to user
          (error) => console.log(error)
        );     
  }
  
}
