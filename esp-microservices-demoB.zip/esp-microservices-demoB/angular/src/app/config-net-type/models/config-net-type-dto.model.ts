
export class ConfigNetTypeDTO {
  //TBD needed?
   deleteEntry = false;
  
  constructor(
    public netType: string,
    
    public backboneManufacturer: string,
  
    public backboneModel: string,
  
    public backboneRouterType: string,
  
    public template: string,
        
    public isNew: string
    
   // deleteEntry = false
   
    ) {}

  //optionalValue?: string 

}