
import { NgModule, ModuleWithProviders } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { ConfigNetTypeComponent } from './config-net-type.component';
import { ConfigNetTypeCreateComponent } from './config-net-type-create/config-net-type-create.component';
import { ConfigNetTypeEditComponent } from './config-net-type-edit/config-net-type-edit.component';
import { ConfigNetTypeListComponent } from './config-net-type-list/config-net-type-list.component';
import { ConfigNetTypeDeleteComponent } from './config-net-type-delete/config-net-type-delete.component';
import { ConfigNetTypeNotFoundComponent } from './config-net-type-not-found/config-net-type-not-found.component';

import { AuthGuardService } from '../auth/services/auth-guard.service';
import { AuthRoleGuardService } from '../auth/services/auth-role-guard.service';

// '/dni/cofigNetType' - mapped in parent routing module as lazy load
//		{ path: '', canActivate: [ AuthGuardService], component: ConfigNetTypeComponent,

export const configNetTypeRoutes: Routes = [
        { 
        	path: "", // Path is defined in parent
		    component: ConfigNetTypeComponent,    
		    canActivate: [ AuthGuardService],
	        children: [
				{ 
				  path: 'configNetType', //pathMatch: 'prefix', 
		          children: [ 
		              { path: '',                redirectTo: "list", pathMatch: 'prefix' },
		              { path: 'list',            component: ConfigNetTypeListComponent,   canActivate: [ AuthRoleGuardService ],  data: {   expectedRole: 'read:DNI.config.nettype' }  },
		              { path: 'create',          component: ConfigNetTypeCreateComponent, canActivate: [ AuthRoleGuardService ],  data: {   expectedRole: 'write:DNI.config.nettype' } },
		              { path: 'edit/:netType',   component: ConfigNetTypeEditComponent,   canActivate: [ AuthRoleGuardService ],  data: {   expectedRole: 'write:DNI.config.nettype' } },
		              { path: 'delete',          component: ConfigNetTypeDeleteComponent, canActivate: [ AuthRoleGuardService ],  data: {   expectedRole: 'write:DNI.config.nettype' } },
		        ]}
		     ],
	   },	        
	   {
	    	path: '**',
	    	component: ConfigNetTypeNotFoundComponent,
	   }
	   
];

//export const configNetTypeRouting: ModuleWithProviders = RouterModule.forChild(configNetTypeRoutes);    

@NgModule({
    //imports: [RouterModule.forChild(authRoutes)],
    //imports: [ RouterModule ],
    exports: [ 
    	RouterModule
    ]
})
export class ConfigNetTypeRoutingModule { }

