import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ConfigNetTypeCreateComponent } from './config-net-type-create.component';

describe('ConfigNetTypeCreateComponent', () => {
  let component: ConfigNetTypeCreateComponent;
  let fixture: ComponentFixture<ConfigNetTypeCreateComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ConfigNetTypeCreateComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ConfigNetTypeCreateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
