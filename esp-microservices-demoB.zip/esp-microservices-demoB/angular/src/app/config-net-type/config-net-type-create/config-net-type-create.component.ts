import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Params, Router } from '@angular/router';

import {FormGroup} from '@angular/forms';


import { ConfigNetTypeService } from '../services/config-net-type.service';
import { ConfigNetTypeDTO } from '../models/config-net-type-dto.model';



@Component({
  selector: 'app-config-net-type-create',
  templateUrl: '../shared/config-net-type-create-edit.component.html',
  styleUrls: ['./config-net-type-create.component.css']
})
  // split edit/delete, share same Html, css  TBD
export class ConfigNetTypeCreateComponent implements OnInit {
 
  paramNetType: string;
  
  configNetType: ConfigNetTypeDTO;
  

  constructor(private configNetTypeService: ConfigNetTypeService, private router:Router, private route: ActivatedRoute) {}

  ngOnInit() {
     // TBD change to boolean?
     const isNew = 'true';
     
     console.log('ConfigNetTypeCreateComponent::ngOnInit', this.router.url);
     
     this.paramNetType = this.route.snapshot.params['netType'];
     // include !existence check in validation TBD
     this.configNetType = new ConfigNetTypeDTO(  this.paramNetType, '', '', '' ,'', isNew );

     console.log("credit-net-type-create-edit", this.configNetType);
  }

  
  onSubmit()  {  
    console.log('ConfigNetTypeCreateComponent submit', this.configNetType)
    
    this.configNetTypeService.create(this.configNetType).subscribe (
          (resp) => {
               // use relative address
               console.log("ConfigNetTypeCreateComponent complete::", resp, this.configNetType);
               this.router.navigate(['../list'], { relativeTo: this.route, queryParamsHandling: 'preserve'});
          },
          // TBD return error msg to user
          (error) => console.log(error)
         );
  }
 
}




