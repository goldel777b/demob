import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ConfigNetTypeComponent } from './config-net-type.component';

describe('ConfigNetTypeComponent', () => {
  let component: ConfigNetTypeComponent;
  let fixture: ComponentFixture<ConfigNetTypeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ConfigNetTypeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ConfigNetTypeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
