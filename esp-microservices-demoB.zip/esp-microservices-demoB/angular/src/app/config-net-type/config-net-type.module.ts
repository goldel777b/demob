
//https://angular.io/guide/module-types
import { CommonModule } from '@angular/common';
import { NgModule, ModuleWithProviders } from '@angular/core';
//import { HttpClientModule } from '@angular/common/http';
import { RouterModule, Routes } from '@angular/router';
// TBD ReactiveFormsModule FIXME - using both tempalte and model
import { FormsModule, NgForm } from '@angular/forms'; //ReactiveFormsModule
import { HTTP_INTERCEPTORS } from '@angular/common/http';
//import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';


//import { AppBootstrapModule } from '../app-bootstrap/app-bootstrap.module';

//import { configNetTypeRouting } from './config-net-type-routing.module';
import { ConfigNetTypeRoutingModule } from './config-net-type-routing.module';


//import { AppComponent } from '../app/app.component';
import { ConfigNetTypeCreateComponent } from './config-net-type-create/config-net-type-create.component';
import { ConfigNetTypeEditComponent }   from './config-net-type-edit/config-net-type-edit.component';
import { ConfigNetTypeListComponent }   from './config-net-type-list/config-net-type-list.component';
import { ConfigNetTypeDeleteComponent } from './config-net-type-delete/config-net-type-delete.component';

import { ConfigNetTypeService } from './services/config-net-type.service';
import { ConfigNetTypeComponent } from './config-net-type.component';
import { ConfigNetTypeNotFoundComponent } from './config-net-type-not-found/config-net-type-not-found.component';





@NgModule({
  declarations: [
    ConfigNetTypeListComponent,
    ConfigNetTypeCreateComponent,
    ConfigNetTypeEditComponent,
    ConfigNetTypeDeleteComponent,
    ConfigNetTypeComponent,
    ConfigNetTypeNotFoundComponent  
  ],
  imports: [
    //configNetTypeRouting,
    ConfigNetTypeRoutingModule,
    CommonModule,
    FormsModule,
    //HttpClientModule
  ], 
  // don't add any providers for the service if want a singleton
   providers: [],
  //exports: [ RouterModule ], 
})
export class ConfigNetTypeModule { 
  
 // keep services singleton access at this level
 // https://angular.io/guide/module-types
    static forRoot(): ModuleWithProviders {
    return {
       ngModule: ConfigNetTypeModule,
       // forces a singleton across the whole application
       providers: [ 
          ConfigNetTypeService
       ],
    }
  }
  
}

/*platformBrowserDynamic().bootstrapModule(AppModule);*/