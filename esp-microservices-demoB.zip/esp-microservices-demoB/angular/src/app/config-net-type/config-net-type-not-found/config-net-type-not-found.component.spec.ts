import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ConfigNetTypeNotFoundComponent } from './config-net-type-not-found.component';

describe('ConfigNetTypeNotFoundComponent', () => {
  let component: ConfigNetTypeNotFoundComponent;
  let fixture: ComponentFixture<ConfigNetTypeNotFoundComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ConfigNetTypeNotFoundComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ConfigNetTypeNotFoundComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
