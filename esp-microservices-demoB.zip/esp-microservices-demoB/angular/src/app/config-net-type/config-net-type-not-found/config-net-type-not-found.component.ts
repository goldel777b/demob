import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-config-net-type-not-found',
  templateUrl: './config-net-type-not-found.component.html',
  styleUrls: ['./config-net-type-not-found.component.css']
})
export class ConfigNetTypeNotFoundComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
