var mainFrame = getMainFrame();

function getMainFrame() {
    var mFrame;
    if (top.window.mainframe2 != null) {
        mFrame = top.window.mainframe2;
    } else {
        mFrame = top.window;
    }
    return mFrame;
}

function openChildWindow(dependentFlag, URL, name, optionalParameters) {
    mainFrame.frame1.openWindow(dependentFlag, URL, name, optionalParameters);
}

function closeWindow() {   
    mainFrame.frame1.closeWindow();
}

function openWindow(URL,name, optionalParameter) {
   openChildWindow(false, URL,name,'status,resizable,scrollbars,widthV0,heightX0'+optionalParameter);
} 

function openWindow1(URL,name,optionalParameters) {
    child=window.open(URL,name,'status,resizable,scrollbars,widthV0,heightX0'+optionalParameters);
    top.window.addChildWindow(child);
} 

function getDisabled(event){
//disabling "F11" function key
	event = event || window.event;
	if (event.keyCode == 122){
		event.returnValue = false;
		event.keyCode=0;
	}
//disabling "Ctrl+N" function key
	if(event.keyCode == 78){
		//character "N"
		if(event.ctrlKey){
		//if press ctrl
			event.returnValue = false;
			event.keyCode = 0;
		}
	}
}
document.onkeydown=getDisabled;
document.onmousedown=getDisabled;
//document.oncontextmenu = new Function("return false");


