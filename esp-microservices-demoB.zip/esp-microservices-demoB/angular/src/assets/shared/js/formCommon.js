/* 
======================================================================================================
 formCommon.js     author: Brian Blank
======================================================================================================
 This include contains functions that are common to most forms. Currently, these methods are only 
 used by OrderDetailView.jsp. Study the code to see how these functions are used and then apply them 
 to the rest of the JSPs.  When that's done, you'll see that many functions that were specific to 
 their context are now generic and identical to dozens of others throughout the codebase. These are 
 the functions that should be consolidated into one copy within this file.  The end result is far 
 less code redundancy, easier maintenance and the ability to eventually get rid of the use of frames 
 (by first removing unnecessary references to them).
======================================================================================================
*/

function isField(fieldTag) {
	return document.getElementsByName(fieldTag)[0] != null;
}

function getField(fieldTag, index) {
	var i = index ? index : 0;
	
	return document.getElementsByName(fieldTag)[i];
}

function getFields(fieldTag) {
	return document.getElementsByName(fieldTag);	
}

function getFieldValue(fieldTag, index) {
	var i = index ? index : 0;
	
	return document.getElementsByName(fieldTag)[i].value;
}

function setFieldValue(fieldTag, val, index) {
	var i = index ? index : 0;
	
	document.getElementsByName(fieldTag)[i].value = val;
}
