


/*
@Author Narender R Soma
This javascript file consists the functions related to pagination component.
*/

function getFortifyCsrfValue(){
    var formLength = document.forms.length;
    if(formLength>0){
        var html = document.forms[0].csrf;
        if( html !== undefined && html !== null && html.value !== undefined && html.value!== null){
            if(html.value.trim() !== ''){
                return html.value;
            }
        }
    }
    return "-"+(Math.floor(Math.random()*9000000) + 1000000).toString();
}

/*
Handles Next/Previous Events.
*/
function gotoPage(action,panel,path) {
   var url;	
   if (path.indexOf("?")>0){
    url = path+'&paginationPanel='+panel+'&paginationaction_'+panel+'='+action;
    }else{
    url = path+'?paginationPanel='+panel+'&paginationaction_'+panel+'='+action;
    }
   ajaxcall(url,panel);
}

/*
Handles Sort event.
*/

function doSort(action,sCol,path,panel){ 
   var url;
   if (path.indexOf("?")>0){
   url = path+'&paginationPanel='+panel+'&paginationaction_'+panel+'='+action+'&sortColumn_'+panel+'='+sCol;
   }else{
    url = path+'?paginationPanel='+panel+'&paginationaction_'+panel+'='+action+'&sortColumn_'+panel+'='+sCol;
   }
   ajaxcall(url,panel); 
}

/*
Handles Navigating to specific page events
*/

function gotoSpecificPage(action,panel,pageNo,path){
   var url;
   if(path.indexOf("?")>0){
   	url = path+'&paginationPanel='+panel+'&paginationaction_'+panel+'='+action+'&specPage_'+panel+'='+pageNo;
   }else{
	url = path+'?paginationPanel='+panel+'&paginationaction_'+panel+'='+action+'&specPage_'+panel+'='+pageNo;
   }
   ajaxcall(url,panel);
}

/*
Handles resetting record count displayed per page.
*/
function setItemsPerPage(action,panel,noRec,path) {
    var url;  	
    if (path.indexOf("?")>0){
    	url = path+'&paginationPanel='+panel+'&paginationaction_'+panel+'='+action+'&itemsPerPage_'+panel+'='+noRec;
    }else{
    	url = path+'?paginationPanel='+panel+'&paginationaction_'+panel+'='+action+'&itemsPerPage_'+panel+'='+noRec;
    	
    }
    ajaxcall(url,panel);
} 

/*
Returns the XMLHttpRequest object. 
*/
 
function newXMLHttpRequest() {

  var xmlreq = false;

  if (window.XMLHttpRequest) {

    // Create XMLHttpRequest object in non-Microsoft browsers
    xmlreq = new XMLHttpRequest();

  } else if (window.ActiveXObject) {

    // Create XMLHttpRequest via MS ActiveX
    try { 

      xmlreq = new ActiveXObject("Msxml2.XMLHTTP");

    } catch (e1) { 

      try { 
        xmlreq = new ActiveXObject("Microsoft.XMLHTTP");

      } catch (e2) { 
      }
    }
  }

  return xmlreq;
}


/*
Creates  a new XMLHttpRequestRequest , makes call and gets the response with the help
of inline call back function.
*/

function ajaxcall(url,div) { 
        
    var body = document.getElementById(div);
       body.innerHTML = "<table border='0' cellpadding='4' cellspacing='1' width='650'><tr ><td class='labelr' align='center'><b>Refreshing Data</b>&nbsp;&nbsp;<img id='RefreshImg' src='images/processing.gif' border='0' /></td></tr></table>";
		
		 
    req = newXMLHttpRequest(); 
    req.onreadystatechange =  function()
    {
	   if (req.readyState == 4) {
           if (req.status == 200) {  
              
             eval('document.getElementById(\''+div+'\')').innerHTML=req.responseText;  
           } else {
             // alert ( "Not able to retrieve Server response" );
		   }
       } 
     }

    if(url.indexOf("?")>0){
        url = url + '&csrf=' + getFortifyCsrfValue();
    }else{
        url = url + '?csrf=' + getFortifyCsrfValue();
    }

    req.open("GET", url, true); 
    req.send(null); 
}


    
      
    