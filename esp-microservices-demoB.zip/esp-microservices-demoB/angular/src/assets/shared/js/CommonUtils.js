// Common Java Script Function

//special characters check
function checkForSpecialCharacter(fname){
    var value = trim(fname);
    if (isCharactersInList(value, "-!@#$%^&()_+{}[]|\=~`?/><.;:*'") == false)
    {
        return false;
    }
    return true;
}
function isCharactersInList(fval, bag){
    var i_count;
    for (i_count = 0; i_count < fval.length; i_count++){
        var charac = fval.charAt(i_count);
        if (bag.indexOf(charac) != -1) return false;
    }
    return true;
}
//end special characters check

function trim(s) {
  if (s == null) {s = ''; return s;}
  while (s.substring(0,1) == ' ') {
    s = s.substring(1,s.length);
  }
  while (s.substring(s.length-1,s.length) == ' ') {
    s = s.substring(0,s.length-1);
  }
  return s;
}
function checkForSpaceCharacters(fname){
    var value = trim(fname);
    if (value.indexOf(' ') != -1) {
        return true;
    }
}

function getUserDateAndTime(){
	var d = new Date(); 
	var s = new String(); 
	
	var dd = d.getDate().toString().length==1?"0"+d.getDate():d.getDate();
	var mm = (d.getMonth()+1).toString().length==1?"0"+(d.getMonth()+1):(d.getMonth()+1);
	var hh = d.getHours().toString().length==1?"0"+d.getHours():d.getHours();
	var mi = d.getMinutes().toString().length==1?"0"+d.getMinutes():d.getMinutes();
	var ss = d.getSeconds().toString().length==1?"0"+d.getSeconds():d.getSeconds();
	
	s = (d.getFullYear()+"-"+ mm +"-"+ dd +" "+ hh +":"+ mi +":"+ ss).toString();
	return s;
}
