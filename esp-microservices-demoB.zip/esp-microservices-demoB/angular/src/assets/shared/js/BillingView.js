function getFortifyCsrfValue(){
    var formLength = document.forms.length;
    if(formLength>0){
        var html = document.forms[0].csrf;
        if( html !== undefined && html !== null){
            if(html.value.trim() !== ''){
                return html.value;
            }
        }
    }
    return "-"+(Math.floor(Math.random()*9000000) + 1000000).toString();
}

function newXMLHttpRequest() {

  var xmlreq = false;
  if (window.XMLHttpRequest) {
    // Create XMLHttpRequest object in non-Microsoft browsers
    xmlreq = new XMLHttpRequest();
  } else if (window.ActiveXObject) {
    // Create XMLHttpRequest via MS ActiveX
    try { 
      xmlreq = new ActiveXObject("Msxml2.XMLHTTP");
    } catch (e1) { 
      try { 
        xmlreq = new ActiveXObject("Microsoft.XMLHTTP");
      } catch (e2) { 
      }
    }
  }

  return xmlreq;
}
/*
Creates  a new XMLHttpRequestRequest , makes call and gets the response with the help
of inline call back function.
*/

function sendAjaxCall(url,queryString,div) { 
	var divObject = eval('document.getElementById(\''+div+'\')');
	
	 if(div == "messageDiv"){
		 divObject = document.getElementById("msgDisp");
	 }	 
	
	disableDiv();
    req = newXMLHttpRequest(); 
    req.onreadystatechange =  function()
    {
	   if (req.readyState == 4) {
           if (req.status == 200 && divObject != null) { 
             var responseText = req.responseText;
             divObject.innerHTML=responseText;
             if(div != "messageDiv"){
          	   hideProgress();
          	   enableDiv();
             }	   
           }else if (req.status == 211) { 
        	 divObject.innerHTML=req.responseText;
             if(div != "messageDiv"){
                hideProgress();
                enableDiv();
             }	   
           }else {
              window.status ="";
              hideProgress();
              enableDiv();
              alert ( "Not able to retrieve Server response" );
		   }
       } 
     }  
    try{
	    req.open("POST", url, true);
		req.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
		req.setRequestHeader("Connection", "close");

        if(queryString === undefined || queryString === null || queryString.trim() === ''){
            queryString = "csrf="+getFortifyCsrfValue();
        }else{
            queryString = queryString + "&csrf="+getFortifyCsrfValue();
        }

        req.send(queryString);
    }catch(e){
		alert(e);
    }
}

/*
Creates  a new XMLHttpRequestRequest , makes call and gets the response with the help
of inline call back function for PopUp's.
*/

function sendAjaxCallForPopUp(url,queryString,divObject) { 
	
    var req = newXMLHttpRequest();

    req.onreadystatechange =  function()
    {
	   if (req.readyState == 4) {
           if (req.status == 200) { 
        	   if(divObject != null){
        	    	divObject.innerHTML=req.responseText;
        	    }	
        	    window.close();
           }else if (req.status == 211) { 
        	   //alert(req.responseText);
        	   divObject.innerHTML=req.responseText;
           }else {
              window.status ="";
              alert ( "Not able to retrieve Server response" );
		   }
       } 
     }  
    try{
    	req.open("POST",url,true);
    	req.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    	req.setRequestHeader("Connection", "close");

        if(queryString === undefined || queryString === null || queryString.trim() === ''){
            queryString = "csrf="+getFortifyCsrfValue();
		}else{
            queryString = queryString + "&csrf="+getFortifyCsrfValue();
		}

    	req.send(queryString);
	} catch(e) {
		alert(e);
	}
}

function enableDiv(){
	document.getElementById("targetBillingSystems").disabled=false;
	document.getElementById("billingAvailableSelect").disabled=false;
	document.getElementById("billingSelectedSelect").disabled=false;
	document.getElementById("customerAvailableSelect").disabled=false;
	document.getElementById("customerSelectedSelect").disabled=false;
	document.getElementById("BILLING_VIEW_GENERATE_PANEL").disabled=false;
	document.getElementById("EntityProductMatrixPaginationPanel").style.display="block";
	document.getElementById("saveBillingResponsibilities").onclick= function(){ openSaveBillingResponsibilities();}
	document.getElementById("saveCustomerLink").onclick=function(){openSaveBillingCustomer();}
	document.getElementById("includeExcludeCustomerLink").onclick=function(){openIncludeExcludeCustomer();}
	document.getElementsByName("SaveQuery")[0].disabled=false;
	document.getElementsByName("generate")[0].disabled=false;
	document.getElementsByName("cancelButton")[0].disabled=false;	
}
	

function disableDiv(){
	document.getElementById("targetBillingSystems").disabled=true;
	document.getElementById("billingAvailableSelect").disabled=true;
	document.getElementById("billingSelectedSelect").disabled=true;
	document.getElementById("customerAvailableSelect").disabled=true;
	document.getElementById("customerSelectedSelect").disabled=true;
	document.getElementById("BILLING_VIEW_GENERATE_PANEL").disabled=true;
	document.getElementById("EntityProductMatrixPaginationPanel").style.display="none";
	document.getElementById("saveBillingResponsibilities").onclick="";
	document.getElementById("saveCustomerLink").onclick="";
	document.getElementById("includeExcludeCustomerLink").onclick="";
	document.getElementsByName("SaveQuery")[0].disabled=true;
	document.getElementsByName("generate")[0].disabled=true;
	document.getElementsByName("cancelButton")[0].disabled=true;	
}

function showProgress(divName, displayMsg, contextPath){
	var messageString ="<table width=\"300\" cellpadding=\"6\" cellspacing=\"0\" border=\"0\"> <tr style=\";font-weight: bold;\"> <td align=\"justify\">"+displayMsg+" <br> </td> </tr> <tr> <td align=\"center\">";
		messageString += "<img src=\""+contextPath+"/images/loading.gif\"/> <br> </td> </tr> </table>";
	var divObj = document.getElementById(divName);
	var msgDispObj = document.getElementById("msgDisp");
	    msgDispObj.innerHTML = messageString;
	var obj = document.getElementById("messageDiv");
	    obj.style.visibility="visible";
	    obj.style.top = getPos(divObj);
}

function hideProgress(){
	var obj = document.getElementById("messageDiv");
		obj.style.visibility="hidden";
}

//This Method is used for closing DIV popup When success message is displayed.
function doClose(){
	if(document.getElementById("messageDiv") != null){
		hideProgress();
		enableDiv();
	}else{
		window.close();
		enableDiv();
	}	
}


function getSelectedQueryString(obj, param){
	selectedResponsibilities = ''; 
	for(index = 0; index <obj.length; index++){
		selectedResponsibilities += param+escape(obj.options[index].value);
	}
	return selectedResponsibilities;
} 

function getCheckedQueryString(obj, param){
	valueString = '';
 	for(index = 0; index < obj.length; index++){
 		if(obj[index].checked){
 			valueString += param+escape(obj[index].value);
 		}	
 	}
	return valueString;
}
