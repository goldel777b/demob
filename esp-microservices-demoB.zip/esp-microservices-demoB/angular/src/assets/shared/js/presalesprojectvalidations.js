
<script src="<%= request.getContextPath()%>/js/urlValidation.js"></script>

function valProjData()
{
document.getElementById('altNumber').value=trim(eval("document.getElementById('altNumber').value;"));
document.getElementById('approxNoOfEntities').value=trim(eval("document.getElementById('approxNoOfEntities').value;"));
document.getElementById('contractMinimumAmount').value=trim(eval("document.getElementById('contractMinimumAmount').value;"));
document.getElementById('annualRevenuePotential').value=trim(eval("document.getElementById('annualRevenuePotential').value;"));
document.getElementById('projectNote').value=trim(eval("document.getElementById('projectNote').value;"));
}

function validateProjectData(formvalue)
{

 var errStr="";
 var err=false;

                                        
 //var index = eval("document."+formvalue+".preSalesProjectStatus.selectedIndex;");
 /*
 if(document.getElementById("customerId").value== 0)
  {
  errStr = errStr +'Customer information should be validated. \n';
  err = true;
  }
 */
  if(document.getElementById("preSalesProjectStatus").selectedIndex == 0)
  {
  errStr = errStr +'Presales Project Status is a required field. \n';
  if(err==false){
  document.getElementById("preSalesProjectStatus").focus();
  }
  err = true;
  }

   if(document.getElementById("procurementType").selectedIndex == 0)
  {
  if(err==false){
  document.getElementById("procurementType").focus();
  }
  errStr = errStr +'Procurement Type is a required field. \n';
  err = true;
  }

   if(trim(eval("document.getElementById('noOfLocationsInAmerica').value;"))=='')
  {
  if(err==false){
  document.getElementById("noOfLocationsInAmerica").focus();
  }
    errStr = errStr +'Number of Locations in America is required field. \n';
    err = true;
  }else{
      document.getElementById("noOfLocationsInAmerica").value = trim(eval("document.getElementById('noOfLocationsInAmerica').value;"));
  }

  if(!isInteger(eval("document.getElementById('noOfLocationsInAmerica').value;"))){
    errStr = errStr +'Number of Locations in America is Not a Valid Number. \n';
    err = true;
  }

  if(trim(eval("document.getElementById('noOfLocationsInEmea').value;"))=='')
 {
    if(err==false){
     document.getElementById("noOfLocationsInEmea").focus();
      }
   errStr = errStr +'Number of Locations in EMEA is required field. \n';
   err = true;
 }else{
     document.getElementById("noOfLocationsInEmea").value = trim(eval("document.getElementById('noOfLocationsInEmea').value;"));
 }

 if(!isInteger(eval("document.getElementById('noOfLocationsInEmea').value;"))){
   errStr = errStr +'Number of Locations in EMEA is Not a Valid Number. \n';
   err = true;
 }

 if(trim(eval("document.getElementById('noOfLocationsInAsia').value;"))=='')
 {
    if(err==false){
     document.getElementById("noOfLocationsInAsia").focus();
      }
   errStr = errStr +'Number of Locations in Asia-Pacific is required field. \n';
   err = true;
 }else{
     document.getElementById("noOfLocationsInAsia").value = trim(eval("document.getElementById('noOfLocationsInAsia').value;"));
 }

 if(!isInteger(eval("document.getElementById('noOfLocationsInAsia').value;"))){
   errStr = errStr +'Number of Locations in Asia-Pacific is Not a Valid Number. \n';
   err = true;
 }

  if(document.getElementById("installVendor").selectedIndex == 0)
  {
  	if(err==false){
     document.getElementById("installVendor").focus();
      }
  errStr = errStr +'Install Vendor is a required field. \n';
  err = true;
  }

  if(document.getElementById("maintenanceVendor").selectedIndex == 0)
  {
    if(err==false){
     document.getElementById("maintenanceVendor").focus();
      }
  errStr = errStr +'Maintenance Vendor is a required field. \n';
  err = true;
  }

  if(document.getElementById("managementLevel").selectedIndex == 0)
  {
    if(err==false){
     document.getElementById("managementLevel").focus();
      }
  errStr = errStr +'Management Level is a required field. \n';
  err = true;
  }

  if(document.getElementById("projectManagementOrganization").selectedIndex == 0)
  {
     if(err==false){
     document.getElementById("projectManagementOrganization").focus();
      }
  errStr = errStr +'Project Management Organization is a required field. \n';
  err = true;
  }

  if(document.getElementById("projectManagementTeam").selectedIndex == 0)
  {
     if(err==false){
     document.getElementById("projectManagementTeam").focus();
      }
  errStr = errStr +'Project Management Team is a required field. \n';
  err = true;
  }

  if(document.getElementById("engineeringTeam").selectedIndex == 0)
  {
    if(err==false){
     document.getElementById("engineeringTeam").focus();
      }  
  errStr = errStr +'Engineering Team is a required field. \n';
  err = true;
  }

  if(document.getElementById("billingLocation").selectedIndex == 0)
  {
      if(err==false){
      document.getElementById("billingLocation").focus();
      }  
  errStr = errStr +'Billing Location is a required field. \n';
  err = true;
  }

  if(document.getElementById("orderLocation").selectedIndex == 0)
  {
     if(err==false){
      document.getElementById("orderLocation").focus();
      } 
  errStr = errStr +'Order Location is a required field. \n';
  err = true;
  }

  if(document.getElementById("salesChannelVP").selectedIndex == 0)
  {
    if(err==false){
      document.getElementById("salesChannelVP").focus();
      } 
  errStr = errStr +'Sales Channel and VP is a required field. \n';
  err = true;
  }
  

 if(trim(eval("document.getElementById('numberOfDesignOrders').value;"))=='')
 {
      if(err==false){
      document.getElementById("numberOfDesignOrders").focus();
      } 
   errStr = errStr +'Design Order Total is required field. \n';
   err = true;
   
 }else{
     document.getElementById("numberOfDesignOrders").value = trim(eval("document.getElementById('numberOfDesignOrders').value;"));
 }

 if(!isInteger(eval("document.getElementById('numberOfDesignOrders').value;"))){
   errStr = errStr +'Design Order Total is Not a Valid Number. \n';
   err = true;
  
 }

 if(trim(eval("document.getElementById('numberOfDesignlessOrders').value;"))=='')
 {
      if(err==false){
       document.getElementById("numberOfDesignlessOrders").focus();
       } 
   errStr = errStr +'Non Design Order Total is required field. \n';
   err = true;
  
 }else{
     document.getElementById("numberOfDesignlessOrders").value = trim(eval("document.getElementById('numberOfDesignlessOrders').value;"));
 }

 if(!isInteger(eval("document.getElementById('numberOfDesignlessOrders').value;"))){
   errStr = errStr +'Non Design Order Total  is Not a Valid Number. \n';
   err = true;
   
 }
 var str=false;
 if((trim(eval("document.getElementById('numberOfDesignlessOrders').value;"))=='')||(trim(eval("document.getElementById('numberOfDesignOrders').value;"))==''))

 {
     str=true;
}

var selectedInd = eval(document.getElementById('preSalesProjectStatus').selectedIndex);

if(!str){
 var totalOrders = (trim(eval("document.getElementById('numberOfDesignOrders').value;"))*1)+ (trim(eval("document.getElementById('numberOfDesignlessOrders').value;"))*1);
  
  if(totalOrders < 1 && eval("document.getElementById('preSalesProjectStatus').options[selectedInd].text;")!='Initial'){
 
    errStr = errStr +'Sum of Design Order Total/Non Design Orders Total should not be less than  1 .\n';
    err = true;
  }
}

 if (err) {
      alert(errStr);
      return false;
   }

	var contractValidateStatusObj=document.getElementById('contractValidateStatus');
	var contractNumberObj=document.getElementById('contractNumber');
	var presalesProjStat = document.getElementById('preSalesProjectStatus');
	if(contractValidateStatusObj.value!="Valid"){
	    
		if(eval("presalesProjStat.options[presalesProjStat.selectedIndex].text") == "Approved")
		{
			alert("Please validate Contract Number before saving project data.");
			return false;
		}
	}
		

	var corpValidateStatusObj=document.getElementById('corpIdValidateStatus');
    var corpIdObj=document.getElementById('corpId');
	var projectStatusObj=document.getElementById('preSalesProjectStatus');
    var validationRequiredObj=document.getElementById('ValidationRequired');
    var validationRequired = validationRequiredObj.value;
    var corpIdRequiredObj=document.getElementById('CorpIdRequired');
    var corpIdRequired = corpIdRequiredObj.value;

    if(eval("presalesProjStat.options[presalesProjStat.selectedIndex].text") == "Approved"){
//        if (trim(eval("corpIdObj.value"))=="" && validationRequired == "true"){
//            alert("Please provide a valid VNET Corp Id (WIN Corp Id is not allowed for Managed Services).\n");
//            return false;
//        }
        if (corpIdRequired=="true"  && trim(eval("corpIdObj.value"))==""){
            alert("CorpId is required to approve a project with security products. Please provide a valid CorpId.\n");
            return false;
        }
    }
    if(trim(eval("corpIdObj.value"))!=""){
		if(corpValidateStatusObj.value!="Valid"){
			if ((corpValidateStatusObj.value=="Validation Error") ||
				(trim(eval("corpValidateStatusObj.value"))=="") ){
				alert("Please validate Corp Id before saving project data.");
				return false;
			}else{
			    if(projectStatusObj.options[projectStatusObj.selectedIndex].text=="Approved")
			    {
					alert("Valid CorpId is required to approve a project.Please provide a valid CorpId.");
					return false;
				}
			}
          }
	}
	
   return true;

}

function trim(strText) {
    // this will get rid of leading spaces
    while (strText.substring(0,1) == ' ')
        strText = strText.substring(1, strText.length);

    // this will get rid of trailing spaces
    while (strText.substring(strText.length-1,strText.length) == ' ')
        strText = strText.substring(0, strText.length-1);

   return strText;
}

function isInteger(s)
{   var i;
    for (i = 0; i < s.length; i++)
    {   
        // Check that current character is number.
        var c = s.charAt(i);
        if (((c < "0") || (c > "9"))) return false;
    }

    return true;
}

function doSubmit()
{
if(document.PresalesProject.isdnRequired.checked){
	  document.PresalesProject.isdnRequired.value="1";
  }
  else{
	  document.PresalesProject.isdnRequired.value="0";
  }
    if(document.PresalesProject.nonStandardInstall.checked){
	  document.PresalesProject.nonStandardInstall.value="1";
  }
  else{
	  document.PresalesProject.nonStandardInstall.value="0";
  }
  document.PresalesProject.submit();
  return true;
}

function validateOrdersStatus(contextStr, submitStr) {

  var presalesProjectId = document.getElementById("preSalesProjectId").value;
  var url = contextStr+"/servlet/PreSalesVoipServlet;
  var result = false;
  var req = initHttpRequest();
  req.onreadystatechange = function() {
  	if (req.readyState == 4) {
  		if (req.status == 200) {
  			var orderStatus = req.responseXML.getElementsByTagName('status')[0].firstChild.data;
  			if (orderStatus=='ActiveStatus') {
  				if(window.confirm('All Orders for this project are not Approved or Cancelled. Do you want to Cancel the orders ?')) {
  					result = true;
  				} else {
  				    result = false;
  				}
  				if(result){
			       document.PresalesProject.action=contextStr+"/preSalesProjectSave.voip" ;
			       document.PresalesProject.ChangeOrderStatus.value="SystemUpdate";
			    } else {
			       document.PresalesProject.action=contextStr+"/preSalesProjectSave.voip" ;
			       document.PresalesProject.ChangeOrderStatus.value="MannualUpdate";
			    }
			     doSubmit();
			     if (submitStr == 'saveClose') {
			        parent.window.close();
			     } 
  			}
  			 document.PresalesProject.action=contextStr+"/preSalesProjectSave.voip" ;
			 document.PresalesProject.ChangeOrderStatus.value="MannualUpdate";
  			 doSubmit();
		     if (submitStr == 'saveClose') {
			   parent.window.close();
			 }
  		} else {
             alert ( "Not able to retrieve Server response" );
		}
  	}
  }
 
	if(validatedURL(url, 'PRESALES_VOIP_SERVLET')){ 
		var params = {
				presalesProjValidate : window.encodeURIComponent('OrdersStatus'),
				searchString : window.encodeURIComponent(presalesProjectId)
				}
		
		
		 var url = getValidatedURLs(url,'PRESALES_VOIP_SERVLET')+formatParams(params);
		
		req.open("GET",url, true);
		req.send(); 
	}

	
}

function initHttpRequest(){
	var xmlreq = false;
	if (window.XMLHttpRequest) { 
		// Create XMLHttpRequest object in non-Microsoft browsers
		xmlreq = new XMLHttpRequest(); 
	} 
	else if (window.ActiveXObject) { 
		// Create XMLHttpRequest via MS ActiveX
		try { 
			xmlreq = new ActiveXObject("Msxml2.XMLHTTP"); 
		} catch (e1) { 
			try { 
				xmlreq = new ActiveXObject("Microsoft.XMLHTTP"); 
			} catch (e2) { 
			}
		}
	}
	return xmlreq;
}





