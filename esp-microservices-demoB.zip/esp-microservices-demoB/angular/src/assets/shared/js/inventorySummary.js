function openInventorySummary(verb, siteId, userName, email, userId, contextName) {
  var target = 'InventorySummaryPopUpWindow' + new Date().getTime();
  var url = '/inventory-summary/';


  var params = [
    'width=1280',
    'height=680',
    'status',
    'resizable=yes',
    'scrollbars',
    'screenX=0',
    'screenY=0',
    'left=0',
    'top=0'
  ].join(',');

  var form = document.createElement("form");
  form.action = url;
  form.method = verb;
  form.target = target;


  var input = document.createElement("input");
  input.type = 'hidden';
  input.name = 'siteId';
  input.value = siteId;

  var input2 = document.createElement("input");
  input2.type = 'hidden';
  input2.name = 'userName';
  input2.value = userName;

  var input3 = document.createElement("input");
  input3.type = 'hidden';
  input3.name = 'email';
  input3.value = email;

  var input4 = document.createElement("input");
  input4.type = 'hidden';
  input4.name = 'userId';
  input4.value = userId;

  var input5 = document.createElement("input");
  input5.type = 'hidden';
  input5.name = 'contextName';
  input5.value = contextName;

  form.appendChild(input);
  form.appendChild(input2);
  form.appendChild(input3);
  form.appendChild(input4);
  form.appendChild(input5);

  document.getElementsByTagName('body')[0].appendChild(form);

  window.open('', target, params);
  form.submit();
}