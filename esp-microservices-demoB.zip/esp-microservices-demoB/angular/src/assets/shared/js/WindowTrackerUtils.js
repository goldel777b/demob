var childWindows = new Array();
//the logout window will be set by the opener
                                                            
var mainWindow;  //is the frame in index.html that has windowtracker and the content frame
var firstWindow; //has index.html. This is our logout window

function setMainWindow() {
	if (top.window.opener == null) {
		//this is a new browser window
		if (top.window.mainframe2 != null) {
			//we are looking at index.html
			mainWindow = top.window.mainframe2;
			firstWindow = top.window; 
			//alert("Looking at index.html");
		} else {
			//it looks like the user typed a different url to get here ???
			mainWindow = top.window;
			firstWindow = top.window;
			//alert("Looking at unknown url in new browser window");
		}

	}  else {
		//our window has an opener.
		//we are not sure if the opener is our firstwindow or the current window is our first window ?
		//if our current window has mainframe2 then this is our first window
		//or else we will go by our opener

		if (top.window.mainframe2 != null) {
			//we are looking at index.html
			mainWindow = top.window.mainframe2;
			firstWindow = top.window;
			//alert("Looking at index.html");
		} else {
			//we are looking at a child window
			if (top.window.opener.mainframe2 != null) {
				//opener is index.html
				mainWindow = top.window.opener.mainframe2.frame1.mainWindow;
				firstWindow = mainWindow;
				//alert("Looking at childwindow opened by index.html");
			} else {
				//opener is not index.html

				if (top.window.opener.frame1 != null) {
					//opener is another child window we spawned.					
					mainWindow = top.window.opener.frame1.mainWindow;
					firstWindow = mainWindow;
					//alert("Looking at child window opened by another child window");
				} else {
					//we do not recognize this window's parent
					mainWindow = top.window;
					firstWindow = top.window;
					//alert("We do not recognize this window's parent. It has no window tracker. "); 
				}
			}	
		}

	} 
      
}

function openWindow(dependentFlag, URL, name, optionalParameters) {   
   child=top.window.open(URL,name,'status,resizable,scrollbars,widthV0,heightX0'+optionalParameters);	

   if (dependentFlag == 1) {
      addChildWindow(child);
   }

   //add all windows to the logout page
	//alert("adding child to mainwindow name = " + mainWindow.name);
   mainWindow.frame1.addChildWindow(child);
}


function addChildWindow(child) {
   childWindows[childWindows.length] = child;
}

// Recursively remove a window and all of it's children.
function closeWindow() {
	//alert("Closing win: " + top.window.name);
   if (! top.window.closed) {
      if (childWindows != null) {
         closeChildren();
      }

		if (firstWindow != top.window) {
			if (!top.window.closed) {
				//alert("window is closing");
				top.window.close();
			}
		} else {
			//do not close the main window 
		}
   }
}


// Recursively remove all of the children of a window.
function closeChildren() {
	//alert("child count = " + childWindows.length);
	childCount = childWindows.length;
	
	for (i=0; i<childCount; i++) {
		//alert("child " + i);
		if (!childWindows[i].closed) {
            if (childWindows[i].frame1 != null) {
                childWindows[i].frame1.closeWindow();
            } else {
                // a popup may not conform to the standard frameset
                childWindows[i].close();
            }
		}
	}
}


