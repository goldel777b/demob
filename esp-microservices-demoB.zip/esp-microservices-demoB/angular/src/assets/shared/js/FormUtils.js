//compare two values, case insensitive
function isEquals(fieldTag, str) {
    var value = document.DataForm[fieldTag].value;

    if (value.toLowerCase() == str.toLowerCase()) {
        return true;
    } else{
        return false;
    }

}

function isSelectedEquals(fieldTag, str) {
    index = document.DataForm[fieldTag].selectedIndex;
    value = document.DataForm[fieldTag].options[index].text;

    if (value.toLowerCase() == str.toLowerCase()) {
        return true;
    } else{
        return false;
    }

}

function fieldExists(fieldTag) {
    val = document.DataForm[fieldTag];
    if (val == null || val == "") {
        return false;
    }
    return true;
}


//data validation functions
function isEmpty(s)
{   return ((s == null) || (s.length == 0))
}

function isLetter (c)
{   return ( ((c >= "a") && (c <= "z")) || ((c >= "A") && (c <= "Z")) )
}

// Returns true if character c is a digit 
// (0 .. 9).
function isDigit (c)
{   return ((c >= "0") && (c <= "9"))
}

// Returns true if character c is a letter or digit.
function isLetterOrDigit (c)
{   return (isLetter(c) || isDigit(c))
}

function isNumeric (fieldTag)

{   
    var i;

    var s = document.DataForm[fieldTag].value;

    if (isEmpty(s)) {
         return false;
     }
       
    // Search through string's characters one by one
    // until we find a non-numeric character.
    // When we do, return false; if we don't, return true.

    for (i = 0; i < s.length; i++)
    {   
        // Check that current character is number 
        var c = s.charAt(i);

        if (! isDigit(c) )
        return false;
    }

    // All characters are numbers
    return true;
}

function isAlphanumeric (s)

{   var i;

    if (isEmpty(s)) {
         return true;
     }
       
    // Search through string's characters one by one
    // until we find a non-alphanumeric character.
    // When we do, return false; if we don't, return true.

    for (i = 0; i < s.length; i++)
    {   
        // Check that current character is number or letter.
        var c = s.charAt(i);

        if (! (isLetter(c) || isDigit(c) ) )
        return false;
    }

    // All characters are numbers or letters.
    return true;
}


function getAlphanumeric (s)

{   var i;
     var newStr = "";

    if (isEmpty(s)) {
         return s;
     }
       
    // Search through string's characters one by one
    // ignore all non-alphanumeric character.

    for (i = 0; i < s.length; i++)
    {   
        // Check that current character is number or letter.
        var c = s.charAt(i);

        if ((isLetter(c) || isDigit(c) ) ) {
              newStr = newStr + c;
          }
        
    }

    // All new Str characters are numbers or letters.
    return newStr;
}


function isValidMonth(month) {
    if (isNaN(month) || (month < 1) || (month > 12)) {
       return false;
    }
    return true;
}

function isValidYear(year) {
    var today = new Date();
    if (isNaN(year) || (year < 1976) || (year > today.getFullYear() + 9)) {
       return false;
    }
    return true;
}

function getMaxDays(month, year) {
    var maxD = 31;
    
    if (month == 2) {
        if ((year - 1996) % 4 == 0) {
            maxD = 29;
        } else {
            maxD = 28;
        }
    }
    if (month == 4 || month == 6 || month == 9 || month == 11) {
        maxD = 30;
    }
    return maxD;
}

function isValidDay(day, month, year) {
    if (isNaN(day) || (day < 1)) {
        return false;
    }
     
    if (day > getMaxDays(month, year)) {
        return false;
    }

    return true;
}

function isValidHour(hour) {
    if (isNaN(hour) || (hour < 0) || (hour > 23)) {
       return false;
    }
    return true;
}

function isValidMin(min) {
// Strange behavior here.  I had to compare to "".  Should not have to.
    if ((min == "") || isNaN(min) || (min < 0) || (min > 59)) {
       return false;
    }
    return true;
}


function isValidDate(fieldTag) {
   var mm = document.DataForm[fieldTag + "_MM"].value;
   var dd = document.DataForm[fieldTag +"_DD"].value;
   var yy = document.DataForm[fieldTag +"_YYYY"].value;

// do not combine the two ifs.  (for easier debugging) 
   if ((mm == "") && (dd == "") && (yy == "")) {
       return true;
   }
    
   if (isValidMonth(mm) && isValidYear(yy) && isValidDay(dd, mm, yy)) {
       return true;
   }

   return false;
}


function isDateChanged(fieldTag) {
   var mm = document.DataForm[fieldTag+"_MM"].value;
   var dd = document.DataForm[fieldTag+"_DD"].value;
   var yy = document.DataForm[fieldTag+"_YYYY"].value;

   var curmm = document.DataForm["CURRENT_"+fieldTag+"_MM"].value;
   var curdd = document.DataForm["CURRENT_"+fieldTag+"_DD"].value;
   var curyy = document.DataForm["CURRENT_"+fieldTag+"_YYYY"].value;

   if ( (mm != curmm) || (dd != curdd) || (yy != curyy) ) {
      return true;
   }
   return false;
}


function isTimeChanged(fieldTag) {
   var hh = document.DataForm[fieldTag+"_HH"].value;
   var mm = document.DataForm[fieldTag+"_MM"].value;

   var curhh = document.DataForm["CURRENT_"+fieldTag+"_HH"].value;
   var curmm = document.DataForm["CURRENT_"+fieldTag+"_MM"].value;

   if ( (hh != curhh) || (mm != curmm)) {
      return true;
   }
   return false;
}



function isBeforeToday(fieldTag) {
   var mm = document.DataForm[fieldTag+"_MM"].value;
   var dd = document.DataForm[fieldTag+"_DD"].value;
   var yy = document.DataForm[fieldTag+"_YYYY"].value;

   if ((mm == "") || (dd == "") || (yy == "")) {
       return true;
   }
   
   aDate = new Date();
   aDate.setDate(dd);
   aDate.setMonth(mm - 1);
   aDate.setFullYear(yy);

   today = new Date();

   if (aDate.getFullYear() < today.getFullYear()) {
      return true;
   } else if (aDate.getFullYear() == today.getFullYear()) {
      if (aDate.getMonth() < today.getMonth()) {
         return true;
      } else if (aDate.getMonth() == today.getMonth()){
         if (aDate.getDate() < today.getDate()) {
            return true;
         }
      }
   }

   return false;
}



function isAfterToday(fieldTag) {
   var mm = document.DataForm[fieldTag+"_MM"].value;
   var dd = document.DataForm[fieldTag+"_DD"].value;
   var yy = document.DataForm[fieldTag+"_YYYY"].value;
   
   if ((mm == "") && (dd == "") && (yy == "")) {
       return false;
   }

   aDate = new Date();
   aDate.setDate(dd);
   aDate.setMonth(mm - 1);
   aDate.setFullYear(yy);   
   
   today = new Date();

   if (today.getFullYear() > aDate.getFullYear()) {
      return false;
   } else if (today.getFullYear() == aDate.getFullYear()) {
      if (today.getMonth() > aDate.getMonth()) {
         return false;
      } else if (today.getMonth() == aDate.getMonth()){
         if (today.getDate() >= aDate.getDate()) {
            return false;
         }
      }
   }

   return true;
}



function isAfterDateBySpecifiedHours(compareFieldTag, fieldTag, hours) {
   var mm = document.DataForm[fieldTag+"_DATE_MM"].value;
   var dd = document.DataForm[fieldTag+"_DATE_DD"].value;
   var yy = document.DataForm[fieldTag+"_DATE_YYYY"].value;
   var hh = document.DataForm[fieldTag+"_TIME_HH"].value;
   var min = document.DataForm[fieldTag+"_TIME_MM"].value;
   
   if ((mm == "") && (dd == "") && (yy == "")) {
       return false;
   }
   
   fieldDate = new Date(yy, mm-1, dd, hh, min);

   var comparemm = document.DataForm[compareFieldTag+"_DATE_MM"].value;
   var comparedd = document.DataForm[compareFieldTag+"_DATE_DD"].value;
   var compareyy = document.DataForm[compareFieldTag+"_DATE_YYYY"].value;
   var comparehh = document.DataForm[compareFieldTag+"_TIME_HH"].value;
   var comparemin = document.DataForm[compareFieldTag+"_TIME_MM"].value;

   if ((comparemm == "") && (comparedd == "") && (compareyy == "")) {
       compareDate = new Date(); //get current date and time
   } else {
       compareDate = new Date();
       compareDate.setDate(comparedd);
       compareDate.setMonth(comparemm - 1);
       compareDate.setFullYear(compareyy);   
       compareDate.setHours(comparehh);   
       compareDate.setMinutes(comparemin);   
   }
   
   //increase the compare date by specified days 
   compareDate.setTime(compareDate.getTime() + (1000*hours*60*60));
   
   //then compare
   if (fieldDate.getTime() > compareDate.getTime()) {
       return true;
   } else {
       return false;
   }

}

function isAfterDate(compareFieldTag, fieldTag) {
	   var mm = document.DataForm[fieldTag+"_DATE_MM"].value;
	   var dd = document.DataForm[fieldTag+"_DATE_DD"].value;
	   var yy = document.DataForm[fieldTag+"_DATE_YYYY"].value;
	   var hh = document.DataForm[fieldTag+"_TIME_HH"].value;
	   var min = document.DataForm[fieldTag+"_TIME_MM"].value;
	   
	   if ((mm == "") && (dd == "") && (yy == "")) {
	       return false;
	   }
	   
	   fieldDate = new Date(yy, mm-1, dd, hh, min);

	   var comparemm = document.DataForm[compareFieldTag+"_DATE_MM"].value;
	   var comparedd = document.DataForm[compareFieldTag+"_DATE_DD"].value;
	   var compareyy = document.DataForm[compareFieldTag+"_DATE_YYYY"].value;
	   var comparehh = document.DataForm[compareFieldTag+"_TIME_HH"].value;
	   var comparemin = document.DataForm[compareFieldTag+"_TIME_MM"].value;

	   if ((comparemm == "") && (comparedd == "") && (compareyy == "")) {
	       compareDate = new Date(); //get current date and time
	   } else {
		   compareDate = new Date(compareyy,comparemm - 1,comparedd,comparehh,comparemin);
	   }
	   
	   //then compare
	   if (fieldDate.getTime() < compareDate.getTime()) {
	       return false;
	   } else {
	       return true;
	   }

	}

function isValidTime(fieldTag) {
   var hh = document.DataForm[fieldTag+"_HH"].value;
   var min = document.DataForm[fieldTag+"_MM"].value;

// do not combine the two ifs.  (for easier debugging)
   if ((hh == "") && (min == "")) {
       return true;
   }
    
   if (isValidHour(hh) && isValidMin(min)) {
       return true;
   }

   return false;
}

function isValidNumber(fieldTag) {
    val = document.DataForm[fieldTag].value;
    if (isNaN(val)) {
       return false;
    } 
    return true;
}


function isNotNull(fieldTag) {
   val = document.DataForm[fieldTag].value;
   if (val == "") {
      return false;
   }
   return true;
}

function isNull(fieldTag) {
   val = document.DataForm[fieldTag].value;
   if (val == "") {
      return true;
   }
   return false;
}


function isType(type, fieldTag) {
   fieldType = document.DataForm[fieldTag].type;
   if (fieldType == type) {
      return true;
   }
   return false;
}

function isSelect(fieldTag) {
   try {
      index = document.DataForm[fieldTag].selectedIndex;
      val = document.DataForm[fieldTag].options[index].text;
      return true;
   } catch (t) {
      return false;
   }
}

function isSelected(fieldTag) {
// Used for SELECT lists that contain a blank first entry (index 0)  
// User must select a non-blank item. i.e., index must be > 0 

   index = document.DataForm[fieldTag].selectedIndex;
   val = document.DataForm[fieldTag].options[index].text;
   if (val == "") {
      return false;
   }
   return true;
}

function validateTextarea(fieldTag,maxlength){
   val = document.DataForm[fieldTag].value;
   if (val.length > maxlength) {
      return false;
   }
   return true;

}

function isHourWithinRange(day)
{
   value = document.DataForm[day+'_START1_HR'].value;
   if (!isValidHour(value)) {
      return false;
   }
   value = document.DataForm[day+'_START2_HR'].value;
   if (!isValidHour(value)) {
      return false;
   }
   value = document.DataForm[day+'_END1_HR'].value;
   if (!isValidHour(value)) {
      return false;
   }
   value = document.DataForm[day+'_END2_HR'].value;
   if (!isValidHour(value)) {
      return false;
   }
   return true;
}

function isMinuteWithinRange(day)
{
   value = document.DataForm[day+'_START1_MIN'].value;
   if (!isValidMin(value)) {
      return false;
   }
   value = document.DataForm[day+'_START2_MIN'].value;
   if (!isValidMin(value)) {
      return false;
   }
   value = document.DataForm[day+'_END1_MIN'].value;
   if (!isValidMin(value)) {
      return false;
   }
   value = document.DataForm[day+'_END2_MIN'].value;
   if (!isValidMin(value)) {
      return false;
   }
   return true;
}


//  need these variables for calendar functionality
var today;
var day;
var month;
var year;
var calFor;
var calWindow;

function y2k(number)    { return (number < 1000) ? number + 1900 : number; }

function padout(number) { return (number < 10) ? '0' + number : number; }

function restart() {
    document.DataForm[calFor + "_MM"].value = padout(month - 0 + 1);
    document.DataForm[calFor + "_DD"].value = padout(day);
    document.DataForm[calFor + "_YYYY"].value = year;
    
    //If this for the Requested Start date, auto populate the Scheduled Start and Scheduled End dates.
    if(calFor == 'REQSTART_DATE'){
    	
    	var recurrence = document.getElementById('RECURRING_EVENT_FLAG');
    	
    	if(recurrence != null && recurrence.checked){
    		autoPopulateScheduleDates();
    	}	
    	
    }	
    calWindow.close();
}

function calendarWindow(calendarFor, URL, name, optionalParameters) {
    today = new Date();
    day   = today.getDate();
    month = today.getMonth();
    year  = y2k(today.getYear());

    calFor = calendarFor;
    calWindow=open(URL,name,optionalParameters);
    
     if (calWindow.opener == null) calWindow.opener = self;
}
