//---------------------------------------------------
// Use this include to hide all status bar messages
//---------------------------------------------------
function hideStatusBarMessages(){
	window.status='';
	return true;
}

document.onmousemove=hideStatusBarMessages;
document.onmouseout=hideStatusBarMessages;