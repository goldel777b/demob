// This function returns the type of address ie IPv4 or IPv6
function addressFormat(address)
   {
      var IPaddress = address;
      var type;
      var index = IPaddress.indexOf('/');
      if(index == 0){
          type = 'IPv6';
          return type;
      }else{

        index = IPaddress.indexOf('::');
          if(index == -1)
           {
               index = IPaddress.indexOf(':');   
                 if(index == -1)
                 {
                     index = IPaddress.indexOf('.');
                       if(index == -1)
                         {
                             type = 'Invalid';
                         }else{
                                  type = 'IPv4';
                          }          
                 }else{
                            type = 'IPv6';
                      }
           }else{
                   type = 'IPv6';
                }

        return type;

      }
          
   }
/**
	 * This method performs the validation for IPv4 and IPv6 address. If given address is valid then 
	 * it returns IPv4 or translated IPv6 address format.
	 *  
	 * if specifier is "IP" then ipfield will be validated accordingly with IP Address rules
	 * if specifier is "SM" then ipfield will be validated accordingly with Subnet Mask rules
	 * 
	 * if format is "IPv4" then this method checks whether ipAddress is in IPv4 format.  
	 * if format is "IPv6" then this method checks whether ipAddress is in IPv6 format.
	 * if format is "NA" then this method checks whether ipAddress is valid or not.
	 * 
	 * @param ipfield  : IP Address format 
	 * @param specifier  : "IP or "SM". 
	 * @param format     : "IPv4" or "IPv6" or "NA"
*/

function validateIPAddress(ipfield,specifier,format){

      var address = ipfield;
      var ipFormat = format;
      var isValidAddress = false;
      var resultArray=new Array();
      if(ipFormat == 'NA'){
          // check the format of given ip address
             ipFormat = addressFormat(address);
      }
      if(ipFormat == 'IPv4'){
                        
            var isValidIP = validateIPv4Address(ipfield,specifier);
            if(isValidIP){
               isValidAddress = true;
               resultArray[1]=address; 
               resultArray[3]='IPv4'; 
            }else{
               isValidAddress = false;
               resultArray[1] = 'Invalid IPv4 address format for';
             /*  if(specifier == 'IP'){
                  resultArray[1] = 'Invalid IPv4.\nThe range should be [1.0.0.1 ? 223.255.255.254]';
               }else{
                  resultArray[1] = 'Invalid IPv4 subnet mask.\nThe range should be [1.0.0.1 ? 255.255.255.255]';
               } */
               resultArray[3]='Invalid'; 
            }
           resultArray[0]=isValidAddress;
           resultArray[2]=ipFormat;   
       }else if(ipFormat == 'IPv6'){
	         if(specifier == 'IP'){
                
                var isValidIP = validateIPv6Address(ipfield);
                
		         if(!isValidIP){
		            isValidAddress = false;
		            resultArray[1] = 'Invalid IPv6 address format for'; 
                    resultArray[3]='Invalid'; 
		         }else{
		            isValidAddress = true;
		            resultArray[1] =isValidIP; 
                    var formatType = ipV6Validations(ipfield);
                        if (formatType == 'AlternateForm') {
                             resultArray[3]='ALTERNATE'; 
                        }else if(formatType == 'ShortForm'){
                             resultArray[3]='SHORT';
        		         }else {
                             resultArray[3]='LONG';
                         }
                 }
	             resultArray[0]=isValidAddress;
                 resultArray[2]=ipFormat;  
             }else{
                 
                 resultArray[1] = 'Invalid IPv6 address format for'; 
                 //resultArray[1] = 'Invalid SubNet Mask value.\nSubnet Mask should be in range of /001 or /01 or /1 to 128.'; 
                 
                 resultArray[3] = 'Invalid'; 
                var index = ipfield.indexOf('/');
                if(index == 0){
                     ipfield = ipfield.substr(1,ipfield.length);
                     regex = /^[0-9]{1,3}$/;
                     match = regex.test(ipfield);
                     if(match){
                        if(ipfield > 0 && ipfield <= 128)
                          {
                            isValidAddress = true;
                            //resultArray[1] = ipfield; 
        		            resultArray[1] = '/'+ipfield; 
                            resultArray[3] = 'IPv6'; 
                          }else{    
                            isValidAddress = false;
		                    resultArray[1] = 'Invalid IPv6 address format for'; 
                            //resultArray[1] = 'Invalid SubNet Mask value.\nSubnet Mask should be in range of /001 or /01 or /1 to 128.'; 
                            resultArray[3] = 'Invalid'; 
                          }
                     }else{
                           isValidAddress = false;
		                   resultArray[1] = 'Invalid IPv6 address format for'; 
                           //resultArray[1] = 'Invalid SubNet Mask value.\nSubnet Mask should be in range of /001 or /01 or /1 to 128.'; 
                           resultArray[3] = 'Invalid'; 
                     }
                 } 
                    resultArray[0]=isValidAddress;
                    resultArray[2]=ipFormat; 
             } 
         }else {
           resultArray[0]=isValidAddress;
           resultArray[1] = 'Invalid'; 
           resultArray[2]='NA'; 
           resultArray[3]='Invalid';
       }
      return resultArray;
}
// IPv4 validation
function validateIPv4Address(ipfield,specifier){
      //var ip = (ipfield.value != null ? ipfield.value : "" );
     var ip = ipfield;
     var isip = false;
      //var ipv = null ;
 
      //ipv= ip.split(/[.]/);
      
      if(ip =="" || ip == null){
          isip = true;
      }else{
          isip = doIPv4(ip,specifier);
      }
      /*
      if(!(ipv == ip)){
        isip = doIPv4(ip);
      }*/
       return isip;
  }
  
// IPv4 validation
/*
  function doIPv4(ip){
         var match = ip.match(/^(\d+)\.(\d+)\.(\d+)\.(\d+)$/);
         var isip = false;
	 isip = (match != null &&
			 (match[1] > 0 && match[1] <= 255) &&
			 (match[2] >= 0 && match[2] <= 255) &&
			 (match[3] >= 0 && match[3] <= 255) &&
			 (match[4] >= 0 && match[4] <= 255));
     
     return isip;
  }*/

  function doIPv4(ip,specifier){
         var match = ip.match(/^(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})$/); //for defect number  VOZDIK.M1ESP - Defect # 1740
         var isip = false;
     if(specifier == 'IP'){
        isip = (match != null &&
			 (match[1] > 0 && match[1] <= 255) &&
			 (match[2] >= 0 && match[2] <= 255) &&
			 (match[3] >= 0 && match[3] <= 255) &&
			 (match[4] >= 0 && match[4] <= 255));
     }else{
         isip = (match != null &&
			 (match[1] > 0 && match[1] <= 255) &&
			 (match[2] >= 0 && match[2] <= 255) &&
			 (match[3] >= 0 && match[3] <= 255) &&
			 (match[4] >= 0 && match[4] <= 255));
     }
	 
     
     return isip;
  }
  
   function validateIPv6Address(ipv6format)
{
     
    formatType = ipV6Validations(ipv6format);
    
     if(formatType){
         if(formatType=="AlternateForm"){
		    var result = fullForm(ipv6format,3);
            
		    var splitResult = result.split(":");
		    var flag = ipv4Tohexa(splitResult[6]);
            

			if(flag !="false"){
			    result = result.replace(splitResult[6],flag);
  		    }else{
  		        result = false;
  		    }
         }
		 if(formatType=="ShortForm"){
		     var result = fullForm(ipv6format,2); 
		 }
		 if(formatType=="LongForm"){
		     var result = ipv6format;  
		 }
        return result;
     }
}


function ipV6Validations(ip){
 
   var regex = /^\s*([0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}\s*$/;
   var match = regex.test(ip);
   var ipType="LongForm";
        if(!match){
            
            regex =/^(([A-Fa-f0-9]{1,4}:){7}[A-Fa-f0-9]{1,4})$|^([A-Fa-f0-9]{1,4}::([A-Fa-f0-9]{1,4}:){0,5}[A-Fa-f0-9]{1,4})$|^$|^(([A-Fa-f0-9]{1,4}:){2}:([A-Fa-f0-9]{1,4}:){0,4}[A-Fa-f0-9]{1,4})$|^(([A-Fa-f0-9]{1,4}:){3}:([A-Fa-f0-9]{1,4}:){0,3}[A-Fa-f0-9]{1,4})$|^(([A-Fa-f0-9]{1,4}:){4}:([A-Fa-f0-9]{1,4}:){0,2}[A-Fa-f0-9]{1,4})$|^(([A-Fa-f0-9]{1,4}:){5}:([A-Fa-f0-9]{1,4}:){0,1}[A-Fa-f0-9]{1,4})$|^(([A-Fa-f0-9]{1,4}:){6}:[A-Fa-f0-9]{1,4})$|^(([A-Fa-f0-9]{1,4}:){1,7}:)$/;
            match = regex.test(ip);
            ipType="ShortForm";
        }

        if(!match){
            
            var index=ip.lastIndexOf(":",ip.length);
            
            var subStrIP=ip.substr(0,index+1);
            
            //regex = /^([A-Fa-f0-9]{1,4}::([A-Fa-f0-9]{1,4}:){0,4})$|^([A-Fa-f0-9]{1,4}:[A-Fa-f0-9]{1,4}::([A-Fa-f0-9]{1,4}:){0,3})$|^([A-Fa-f0-9]{1,4}:[A-Fa-f0-9]{1,4}:[A-Fa-f0-9]{1,4}::([A-Fa-f0-9]{1,4}:){0,2})$|^([A-Fa-f0-9]{1,4}:[A-Fa-f0-9]{1,4}:[A-Fa-f0-9]{1,4}:[A-Fa-f0-9]{1,4}::([A-Fa-f0-9]{1,4}:){0,1})$|^([A-Fa-f0-9]{1,4}:[A-Fa-f0-9]{1,4}:[A-Fa-f0-9]{1,4}:[A-Fa-f0-9]{1,4}:([A-Fa-f0-9]{1,4}::))$/;
            regex = /^([A-Fa-f0-9]{1,4}::([A-Fa-f0-9]{1,4}:){0,4})$|^([A-Fa-f0-9]{1,4}:[A-Fa-f0-9]{1,4}::([A-Fa-f0-9]{1,4}:){0,3})$|^([A-Fa-f0-9]{1,4}:[A-Fa-f0-9]{1,4}:[A-Fa-f0-9]{1,4}::([A-Fa-f0-9]{1,4}:){0,2})$|^([A-Fa-f0-9]{1,4}:[A-Fa-f0-9]{1,4}:[A-Fa-f0-9]{1,4}:[A-Fa-f0-9]{1,4}::([A-Fa-f0-9]{1,4}:){0,1})$|^([A-Fa-f0-9]{1,4}:[A-Fa-f0-9]{1,4}:[A-Fa-f0-9]{1,4}:[A-Fa-f0-9]{1,4}:([A-Fa-f0-9]{1,4}::))$|^([A-Fa-f0-9]{1,4}:){6}$/;
            match = regex.test(subStrIP);
            
            if(match){ 
            var sub=ip.substr(index+1,ip.length);
           // var match = sub.match(/^(\d+)\.(\d+)\.(\d+)\.(\d+)$/);
            var isip = false;
           // isip = (match != null && (match[1] > 0 && match[1] <= 255) && (match[2] >= 0 && match[2] <= 255) && (match[3] >= 0 && match[3] <= 255) && (match[4] >= 0 && match[4] <= 255)); 
            isip=doIPv4(sub,'IP');
            match=isip;
            ipType="AlternateForm";
            } 
            
        }
    if(match){
      return ipType;
    }else{
      return match;
    }
}  


function ipv4Tohexa(ipv4Str)
{
        var arr = ipv4Str.split(".");
        var isip = false;
    /*
	if((arr[0]<=223 )&& (arr[3]<=254)){
	   if((arr[1]<=255) && (arr[2]<=255)){
  	    return (decimalTohexa(arr[0])+""+decimalTohexa(arr[1]))+":"+(decimalTohexa(arr[2])+""+decimalTohexa(arr[3]));
	   }else{
            return "false";
	   }
	}else{
         return "false";
	}*/
      
      
      /*isip = ((arr[0] > 0 && arr[0] <= 223) &&
			 (arr[1] >= 0 && arr[1] <= 255) &&
			 (arr[2] >= 0 && arr[2] <= 255) &&
			 (arr[3] > 0 && arr[3] <= 254));*/
      
      isip=doIPv4(ipv4Str,'IP'); //for defect number  VOZDIK.M1ESP - Defect # 1740
      
      if(isip){
          return (decimalTohexa(arr[0])+""+decimalTohexa(arr[1]))+":"+(decimalTohexa(arr[2])+""+decimalTohexa(arr[3]));
      }else {
          return "false";
      }

}
function fullForm(rStr,f)
{
    var rStr1 = rStr;
    var times = 8;
    if((rStr.indexOf("::")==0) || ((rStr.length - rStr.indexOf("::")) == 2))
    {
       rStr1 = rStr1.replace("::","");
    }
    rStr1 = rStr1.replace("::",":");
    
    if(f == "3")
        times = 7;

    var arr = rStr1.split(":");
    var str = "";
    for(var i = 0;i<(times-arr.length);i++)
    {
        if(str!="")
        str+=":";
      str+="0000";
    }
   if(str!="" && rStr.indexOf("::")>=1)
      str = ":"+str;

   if((str!="" && rStr1!="") && !((rStr.length - rStr.indexOf("::")) == 2))
     str+=":"; 
 return rStr.replace("::",str);
}



function getHex(dec)
{ 

var hexArray = new Array( "0", "1", "2", "3", 
                          "4", "5", "6", "7",
                          "8", "9", "A", "B", 
                          "C", "D", "E", "F" ); 



var code1 = Math.floor(dec / 16);
var code2 = dec - code1 * 16; 


var decToHex = hexArray[code2]; 


return (decToHex); 

} 

function decimalTohexa(dec)
{ 

// array to store the hex code for each value passed 
// to the getHex function
var hexCode= new Array(); 





// variable to define the dynamic array index
// for hexCode array
var i=0; 





// while loop to run until dec variable
// is greater than 15
while(dec > 15)
{
     hexCode[i] = getHex(dec); 





// evaluate dec each time to
// pass the while loop condition
dec = Math.floor(dec / 16); 


     i+=1;
} 





// store the last value 
// skiped due to loop condition
// for dec < 15
hexCode[i] = getHex(dec); 




// variable to store the hex Codes
var decToHex = ""; 




// reverse loop on hexCode to
// generate the right order of hex codes
for(i=hexCode.length-1; i>=0; i--)
{
    decToHex += hexCode[i]; 
} 

if(decToHex.length<2)
 decToHex = "0"+decToHex;
return decToHex; 

} 
