
var map = {	
			'PSAP_SERVLET':'/servlet/PsapIdServlet',
			'CORPID_CONTRACT_VALIDATION':'/servlet/CorpIdAndContractValidationServlet',
			'EDIT_CONTRACT_NUMBER':'/servlet/CorpIdAndContractValidationServlet',
			'PRESALES_VOIP_SERVLET':'/servlet/PreSalesVoipServlet'
		  }

	function get(k){
		return map[k];
	}

	function validatedURL(dest, key){
		if(dest.indexOf(get(key)) > 0){
			return true;			
		}
		return false;
	}

	function getValidatedURLs(dest, key){
		alert(key);
		if(dest.indexOf(get(key)) > 0){
			return dest;			
		}
		return;
	}
	
	 function formatParams( params ){
		  return "?" + Object
		        .keys(params)
		        .map(function(key){
		          return key+"="+params[key]
		        })
		        .join("&")
		} 
