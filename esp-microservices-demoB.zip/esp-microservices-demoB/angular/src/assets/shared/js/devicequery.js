/* -----------------------
New DQ Toggle Scripts
*----------------------- */
function onDqToggleClick() {
    var dq_onOff_toggle = document.getElementById('dq_onOff_toggle'),
        dq_onOff_toggle_on = document.getElementById('dq_onOff_toggle_on'),
        dq_onOff_toggle_off = document.getElementById('dq_onOff_toggle_off'),
        selectTextCls = 'select_txt',
        displayNoneCls = 'displayNone';

    toggleCls(dq_onOff_toggle, selectTextCls);
    toggleCls(dq_onOff_toggle_on, displayNoneCls);
    toggleCls(dq_onOff_toggle_off, displayNoneCls);
    toggleCls(dq_onOff_toggle_on_hint, displayNoneCls);
    toggleCls(dq_onOff_toggle_off_hint, displayNoneCls);

}

function toggleCls(el, cls) {
    if (el) {
        var className = ' ' + el.className + ' ';
        el.className = ~className.indexOf(' ' + cls + ' ') ? className.replace(' ' + cls + ' ', ' ') : el.className + ' ' + cls;
    }
}

function isDQToggleSelected() {
    var dq_onOff_toggle = document.getElementById('dq_onOff_toggle');

    if (!dq_onOff_toggle) {
        //If the toggle is not rendered, then run Old DQ
        return false;
    }

    var className = ' ' + dq_onOff_toggle.className + ' ',
        selectTextCls = 'select_txt';

    if (~className.indexOf(' ' + selectTextCls + ' ')) {
        return true;
    } else {
        return false;
    }
}
/* -----------------------
New DQ Toggle Scripts
*----------------------- */