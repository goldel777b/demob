// contextPath ex. /DNI or /OPS 
var contextPath = '/' + window.location.pathname.split('/')[1];

function noSpecialCharacters(str)
{
     str.value = str.value.replace(/[^A-Za-z0-9]/g, '') ;
}

function valueOf(fieldTag) {
    if(document.getElementById(fieldTag))
    {
       return document.getElementById(fieldTag).value;
    } else
    {
       return null;
    }
}


function editEgress(egressIngress) {
     dataServiceType = null;
     dataServiceType = document.getElementById('CircuitDataServiceType').value;
     egressIngressEval = null;
     
     if(egressIngress == 'Egress')
     {
     	egressIngressEval = 'EGRESS';
     
     } else
     {
        egressIngressEval = 'INGRESS';
     }
     
	 egressField = document.getElementById(egressIngressEval).value;
     circuitId = trim(document.getElementById('CIRCUIT_ID').value);
       
     if(circuitId == '')
     {
     	alert('No Circuit ID Entered.');
     	return;
     } 
 
     
     var url = contextPath + '/EditEgressIngressWindow.jsp?ScreenName=ORDER&DataServiceType=' + 
     dataServiceType + '&EgressIngress=' + egressIngress + '&circuitId=' + circuitId;
     var pageName = 'EgressIngress';
     var param = ',width=550, height=200';    
     
     openWindow(url, pageName, param);
     
}

function trim(strText) {
    //replace all spaces,tabs...etc with one space
    return strText.replace(/^\s+|\s+$/g, '') ;
}

function getValueIfNotNull(elementName)
{
    elementVal = 'null';
	if(document.getElementById(elementName) != null)
	{
		elementVal = document.getElementById(elementName).value;
	}
	
	return elementVal;
}

function isValidTime(fieldTag) {
    var hh  = valueOf(fieldTag+"_HH");
    var min = valueOf(fieldTag+"_MM");

    // do not combine the two ifs.  (for easier debugging)
    if ((hh == "") && (min == "")) {
        return true;
    }

    if (isValidHour(hh) && isValidMin(min)) {
        return true;
    }
    return false;
}


