//define variables
var validateMainFunctions = new Array();
var validateListDetailFunctions = new Array();

function addValidateFunction(validateType, functionName) {
	if (validateType == 'Main') {
		validateMainFunctions[validateMainFunctions.length] = functionName;
	} else if (validateType == 'ListDetail') {
		validateListDetailFunctions[validateListDetailFunctions.length] = functionName;
	} else {
		alert("Invalid validateType for validateFunction: " + validateType + "," + functionName);
	}
}


//This method calls all the validation functions for this form
function validate() {
	var action = document.DataForm.action.value;
	var infoVistaRegEx = /INFOVISTA/;
	
	if(infoVistaRegEx.exec(window.location.pathname)) {
		document.DataForm.submit();
		return true;
	}
	
	var telchemyRegEx = /TELCHEMY/;	
	if(telchemyRegEx.exec(window.location.pathname)) {
		return true;
	}
	
    if (action != 'listDetail') {
		//this is a not list detail action
		//make sure the user does not have an accept/cancel dialog on this page
		if (checkAcceptCancel() == false) {
			return false;
		}
	}


	//validate the main screen
	if (!validateMain())
		return false;

	if (action == 'listDetail') {
		//if this is a list detail action
		//validate the list detail only on accept
		//do not validate on cancel
		var listDetailAction = document.DataForm.listDetailAction.value;
		if (listDetailAction != 'cancel' && listDetailAction != 'cancelProfile') {
			if (!validateListDetail())
				return false;
		}
	}

	return true;
}



function validateMain() {
	//gather all the main validate functions on the current page
   for (var i=0; i<validateMainFunctions.length; i++) {
		val = eval(validateMainFunctions[i]);
		if (val == false) {
			return false;
		}
	}

	return true;
}


function validateListDetail() {
	//gather all the listdetail validate functions on the current page
   for (var i=0; i<validateListDetailFunctions.length; i++) {
		val = eval(validateListDetailFunctions[i]);
		if (val == false) {
			return false;
		}
	}

	return true;
}




//This method is used by submit the form
//
function submitForm(action) {
	document.DataForm.action.value=action;

	if (action == 'close') {
		document.DataForm.submit();
		return true;
	} else {
		if (validate()) {
			if (action == 'save') {
				val = document.getElementById('saveLink');
				if (val != null || !val == "")
					document.getElementById('saveLink').disabled = true;
			}
			document.DataForm.submit();
			return true;
		}
	}

	return false;
}



//This method is used by submit the form	from a href
//
function submitFormFromHref(action) {
   submitForm(action);
}


function checkAcceptCancel() {
   if (document.DataForm.listDetailType.value !=  '') { //This page has accept , cancel buttons
      alert("Please click on accept or cancel first");
      return false;
   }
   return true;
}

//This method is used for changing tabs using a href
//
function changeTabFromHref(requestedNewTab) {
   document.DataForm.requestedNewTab.value=requestedNewTab;
	submitFormFromHref('changeTab');
}

//This method is used for setting the menu parameters
//
function preChangeTab(requestedNewTab,h_mainMenu, h_mainMenuTab, h_subMenuTab, h_subMenu) {

    if (document.DataForm.listDetailType.value ==  '') {
    document.DataForm.h_mainMenu.value=h_mainMenu;
    document.DataForm.h_mainMenuTab.value=h_mainMenuTab;
    document.DataForm.h_subMenuTab.value=h_subMenuTab;
    document.DataForm.h_subMenu.value=h_subMenu;
    }
	return changeTab(requestedNewTab);
}

//This method is used for changing tabs using a href
//
function changeTab(requestedNewTab) {
   document.DataForm.requestedNewTab.value=requestedNewTab;
	return submitForm('changeTab');
}

function cancelChangeRequestFromHref() {
	if (confirm("Are you sure you want to cancel this request?")) {
		submitForm('cancelRequest');
	} 
}

function submitChangeRequestFromHref() {
	if(document.DataForm.confRequestType != null){
		if(document.DataForm.userConfirmedFlag.value == "0"){
			alert("Please agree to contact(s) confirmation in the status page before submitting this request");
		} else {
			submitForm('submitRequest');
		}
	} else 
		submitForm('submitRequest');
}

function isEndDateAfterStartDate(fieldTag)
{
   mm = document.DataForm[fieldTag+'_START_DATE_MM'].value;
   dd = document.DataForm[fieldTag+'_START_DATE_DD'].value;
   yyyy = document.DataForm[fieldTag+'_START_DATE_YYYY'].value;
   hr = document.DataForm[fieldTag+'_START_TIME_HH'].value;
   min = document.DataForm[fieldTag+'_START_TIME_MM'].value;
   startDate = new Date();
   startDate.setDate(dd);
   startDate.setMonth(mm - 1);
   startDate.setFullYear(yyyy);
   startDate.setHours(hr);
   startDate.setMinutes(min);

   mm = document.DataForm[fieldTag+'_END_DATE_MM'].value;
   dd = document.DataForm[fieldTag+'_END_DATE_DD'].value;
   yyyy = document.DataForm[fieldTag+'_END_DATE_YYYY'].value;
   hr = document.DataForm[fieldTag+'_END_TIME_HH'].value;
   min = document.DataForm[fieldTag+'_END_TIME_MM'].value;
   endDate = new Date();
   endDate.setDate(dd);
   endDate.setMonth(mm - 1);
   endDate.setFullYear(yyyy);
   endDate.setHours(hr);
   endDate.setMinutes(min);

   if (endDate < startDate) {
      return false;
   }
   return true;

}

/*
The action of this form will be changed dynamically depending on what the user's action is
On change tab: call changeTab("requestedNewTab"); -- action=changeTab
On Save: call submitForm("save"); -- action=save
On Save Close: call submitForm("saveclose"); -- action=saveclose
On Close: call submitForm("close"); -- action=close
On list details: call submitForm("list"); -- action=list
On list delete: call submitForm("list"); -- action=list
On list add: call submitForm("list"); -- action=list
On details Add: call submitForm("listDetail"); -- action=listDetail
On details Accept: call submitForm("listDetail"); -- action=listDetail
On details Cancel: call submitForm("listDetail"); -- action=listDetail
On Other: call submitForm("other"); -- action=other
*/






