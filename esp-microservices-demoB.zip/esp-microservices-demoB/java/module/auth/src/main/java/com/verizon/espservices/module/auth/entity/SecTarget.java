package com.verizon.espservices.module.auth.entity;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the SEC_TARGET database table.
 * 
 */
@Entity
@Table(name="SEC_TARGET")
@NamedQuery(name="SecTarget.findAll", query="SELECT s FROM SecTarget s")
public class SecTarget implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private SecTargetPK id;

	@Temporal(TemporalType.DATE)
	@Column(name="DB_DATE_ADDED", nullable=false)
	private Date dbDateAdded;

	@Temporal(TemporalType.DATE)
	@Column(name="DB_DATE_MODIFIED", nullable=false)
	private Date dbDateModified;

	@Column(name="DB_USER_ADDED", nullable=false, precision=16)
	private BigDecimal dbUserAdded;

	@Column(name="DB_USER_MODIFIED", nullable=false, precision=16)
	private BigDecimal dbUserModified;

	@Column(name="DB_VERSION", nullable=false, precision=5)
	private BigDecimal dbVersion;

	public SecTarget() {
	}

	public SecTargetPK getId() {
		return this.id;
	}

	public void setId(SecTargetPK id) {
		this.id = id;
	}

	public Date getDbDateAdded() {
		return this.dbDateAdded;
	}

	public void setDbDateAdded(Date dbDateAdded) {
		this.dbDateAdded = dbDateAdded;
	}

	public Date getDbDateModified() {
		return this.dbDateModified;
	}

	public void setDbDateModified(Date dbDateModified) {
		this.dbDateModified = dbDateModified;
	}

	public BigDecimal getDbUserAdded() {
		return this.dbUserAdded;
	}

	public void setDbUserAdded(BigDecimal dbUserAdded) {
		this.dbUserAdded = dbUserAdded;
	}

	public BigDecimal getDbUserModified() {
		return this.dbUserModified;
	}

	public void setDbUserModified(BigDecimal dbUserModified) {
		this.dbUserModified = dbUserModified;
	}

	public BigDecimal getDbVersion() {
		return this.dbVersion;
	}

	public void setDbVersion(BigDecimal dbVersion) {
		this.dbVersion = dbVersion;
	}

}