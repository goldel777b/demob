package com.verizon.espservices.module.auth.entity;
import java.io.Serializable;
import javax.persistence.*;

import lombok.Data;

import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the LOGIN_FAILED_USER database table.
 * 
 */
@Entity
@Data
@Table(name="LOGIN_FAILED_USER")
@NamedQuery(name="LoginFailedUser.findAll", query="SELECT l FROM LoginFailedUser l")
public class LoginFailedUser implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="USER_ID", unique=true, nullable=false, precision=16)
	private long userId;

	@Column(name="LOGIN_FAILED_ATTEMPTS", precision=1)
	private BigDecimal loginFailedAttempts;

	@Temporal(TemporalType.DATE)
	@Column(name="LOGIN_FAILED_TIME")
	private Date loginFailedTime;

	@Column(nullable=false, length=50)
	private String username;

	//bi-directional one-to-one association to SecUser
	@OneToOne
	@JoinColumn(name="USER_ID", nullable=false, insertable=false, updatable=false)
	private SecUser secUser;

	public LoginFailedUser() {
	}


}