package com.verizon.espservices.module.auth.controller;

import java.security.Principal;
import java.util.Optional;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.modelmapper.ModelMapper;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.verizon.espservices.module.auth.entity.SecUser;
import com.verizon.espservices.module.auth.service.AuthService;

@RestController
@RequestMapping("${rest.spring.module.admin}")
@CrossOrigin(origins ="${spring.angular.cors.url}", maxAge=3600)
public class AuthController {

	private static Log LOG = LogFactory.getLog(AuthController.class);
	private final AuthService authService;
	private final ModelMapper modelMapper;

	public AuthController(AuthService authService, ModelMapper modelMapper) {
		this.authService = authService;
		this.modelMapper = modelMapper;
	}

	@RequestMapping("/user")
	public Optional<UserDetails> user(Principal principal) {
		LOG.debug("user logged "+principal);

		//LOG.debug("currentUser::" + this.authService.currentUser());
		return this.authService.currentUser();
	}
	
	@RequestMapping("/doLogout")
	// tbd fixme need SecUserDTO type
	public Optional<UserDetails> doLogout(SecUser secUser) {
		LOG.debug("user logged out"+secUser);

		//LOG.debug("currentUser::" + this.authService.currentUser());
		return this.authService.currentUser();
	}
}
