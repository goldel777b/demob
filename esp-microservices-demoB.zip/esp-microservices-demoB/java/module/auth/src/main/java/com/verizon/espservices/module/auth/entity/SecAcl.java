package com.verizon.espservices.module.auth.entity;

import java.io.Serializable;
import javax.persistence.*;

import lombok.Data;

import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the SEC_ACL database table.
 * 
 */
@Entity
@Data
@Table(name="SEC_ACL")
@NamedQuery(name="SecAcl.findAll", query="SELECT s FROM SecAcl s")
public class SecAcl implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private SecAclPK id;

//	@Temporal(TemporalType.DATE)
//	@Column(name="DB_DATE_ADDED", nullable=false)
//	private Date dbDateAdded;
//
//	@Temporal(TemporalType.DATE)
//	@Column(name="DB_DATE_MODIFIED", nullable=false)
//	private Date dbDateModified;
//
//	@Column(name="DB_USER_ADDED", nullable=false, precision=16)
//	private BigDecimal dbUserAdded;
//
//	@Column(name="DB_USER_MODIFIED", nullable=false, precision=16)
//	private BigDecimal dbUserModified;
//
//	@Column(name="DB_VERSION", nullable=false, precision=5)
//	private BigDecimal dbVersion;

	@Column(name="IS_READ", precision=1)
	private BigDecimal isRead;

	@Column(name="IS_WRITE", precision=1)
	private BigDecimal isWrite;

	//bi-directional many-to-one association to SecRole
	@ManyToOne
	@JoinColumn(name="ROLE_ID", nullable=false, insertable=false, updatable=false)
	private SecRole secRole;

	public SecAcl() {
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		SecAcl other = (SecAcl) obj;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		return true;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		return result;
	}

	@Override
	public String toString() {
		return "SecAcl [id=" + id + ", isRead=" + isRead + ", isWrite=" + isWrite + "]";
	}

	

}