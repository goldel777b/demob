package com.verizon.espservices.module.auth.entity;

import java.io.Serializable;
import javax.persistence.*;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;
import java.util.Date;
import java.util.Set;

/**
 * The persistent class for the SEC_ROLE database table.
 * 
 */
@Entity
@Data
@Table(name="SEC_ROLE")
@NamedQuery(name="SecRole.findAll", query="SELECT s FROM SecRole s")
public class SecRole implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="ROLE_ID", unique=true, nullable=false, precision=16)
	private long roleId;

	@Column(name="APPLICATION_CONTEXT", nullable=false, length=50)
	private String applicationContext;

//	@Temporal(TemporalType.DATE)
//	@Column(name="DB_DATE_ADDED", nullable=false)
//	private Date dbDateAdded;
//
//	@Temporal(TemporalType.DATE)
//	@Column(name="DB_DATE_MODIFIED", nullable=false)
//	private Date dbDateModified;
//
//	@Column(name="DB_USER_ADDED", nullable=false, precision=16)
//	private BigDecimal dbUserAdded;
//
//	@Column(name="DB_USER_MODIFIED", nullable=false, precision=16)
//	private BigDecimal dbUserModified;
//
//	@Column(name="DB_VERSION", nullable=false, precision=5)
//	private BigDecimal dbVersion;
//
	@Column(length=255)
	private String description;

	@Column(name="DISPLAY_FLAG", precision=1)
	private BigDecimal displayFlag;

	@Column(name="ROLE_NAME", nullable=false, length=50)
	private String roleName;

	//bi-directional many-to-one association to SecAcl
	@OneToMany(mappedBy="secRole", fetch=FetchType.LAZY)
	private Set<SecAcl> secAcls;

	//bi-directional many-to-one association to SecUserRole
//	@OneToMany(mappedBy="secRole")
//	private Set<SecUserRole> secUserRoles;

	public SecRole() {
	}


//	public SecAcl addSecAcl(SecAcl secAcl) {
//		getSecAcls().add(secAcl);
//		secAcl.setSecRole(this);
//
//		return secAcl;
//	}
//
//	public SecAcl removeSecAcl(SecAcl secAcl) {
//		getSecAcls().remove(secAcl);
//		secAcl.setSecRole(null);
//
//		return secAcl;
//	}


	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		SecRole other = (SecRole) obj;
		if (roleId != other.roleId)
			return false;
		return true;
	}


	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + (int) (roleId ^ (roleId >>> 32));
		return result;
	}


}