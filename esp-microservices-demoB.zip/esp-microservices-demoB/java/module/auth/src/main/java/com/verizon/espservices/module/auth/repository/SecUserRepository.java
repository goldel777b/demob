package com.verizon.espservices.module.auth.repository;


import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.CrossOrigin;

import com.verizon.espservices.module.auth.entity.SecUser;



@Repository
@CrossOrigin(origins ="${spring.angular.cors.url}", maxAge=3600)
public interface SecUserRepository extends CrudRepository<SecUser, Long> {
//    @Override
//    @Transactional(timeout = 8)// TBD
//    Iterable<ConfigNetType> findAll();
    
    @Transactional(timeout = 8)// TBD
    SecUser findByUsername(String userName);
}
