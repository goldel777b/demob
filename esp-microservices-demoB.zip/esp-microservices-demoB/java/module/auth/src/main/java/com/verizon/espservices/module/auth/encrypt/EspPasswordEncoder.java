package com.verizon.espservices.module.auth.encrypt;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import org.springframework.security.crypto.password.PasswordEncoder;


public class EspPasswordEncoder implements PasswordEncoder {
	private static Log LOG = LogFactory.getLog(EspPasswordEncoder.class);

	@Override
	public boolean matches(CharSequence password, String encryptedPassword) {
		LOG.debug(String.format("PasswordEncryptor::matches %s=%s?", password, encryptedPassword));
		
		if (password == null || encryptedPassword == null) {
			return false;
		}
		return encryptedPassword.equals( encode(password));
	}
	
	@Override
	public String encode(CharSequence password) {
		LOG.debug(String.format("PasswordEncryptor::encode %s", password));

	        MessageDigest md = null;
	        
	        try {
	        	byte[] hashedPwd;
	        	BigInteger number;
	        	
	            md = MessageDigest.getInstance("SHA");
	            md.reset();
	            md.update(password.toString().getBytes());
	            
	            hashedPwd = md.digest();
	            number = new BigInteger(1,hashedPwd);
	            
	    		LOG.info(String.format("PasswordEncryptor::encode exit %s", number));

	            return number.toString();

	        } catch (NoSuchAlgorithmException e) {
	            e.printStackTrace();
	            //TBD throw new GeneralFailureException("Encryption Error");
	            throw new IllegalStateException("Encryption Error");
	        }
	    }
}
