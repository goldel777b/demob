package com.verizon.espservices.module.auth.config;



import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.csrf;

import java.util.Arrays;
import java.util.regex.Pattern;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.annotation.Order;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.ProviderManager;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.csrf.CookieCsrfTokenRepository;
import org.springframework.security.web.csrf.CsrfTokenRepository;
import org.springframework.security.web.util.matcher.AntPathRequestMatcher;
import org.springframework.security.web.util.matcher.RequestMatcher;

import com.verizon.espservices.module.auth.encrypt.EspPasswordEncoder;
import com.verizon.espservices.module.auth.service.AuthService;

// spring-security https://docs.spring.io/spring-security/site/docs/current/reference/html/jc.html
@EnableWebSecurity()
@Order(1)
public class ModuleAuthSecurityConfig extends WebSecurityConfigurerAdapter {
	private static Log LOG = LogFactory.getLog(ModuleAuthSecurityConfig.class);
	
	private final AuthService authService;
	
	public ModuleAuthSecurityConfig(AuthService authService) {
		this.authService = authService;
	}
	
    /* Authorization -- both manager and provider are required
     * TBD - MD5 is outdated and not very safe
     */
	
    @Bean
    public PasswordEncoder passwordEncoder() {
    	LOG.debug("passwordEncoder");
        return new EspPasswordEncoder();
    }

    @Bean
    public DaoAuthenticationProvider authenticationProvider() {
        DaoAuthenticationProvider authProvider = new DaoAuthenticationProvider();

    	LOG.debug("authenticationProvider::"+authProvider);

        authProvider.setUserDetailsService(authService);
        authProvider.setPasswordEncoder(passwordEncoder());
        return authProvider;
    }
    
    @Bean
    public AuthenticationManager authenticationManager(AuthenticationProvider provider) {
    	LOG.debug("authenticationManager::"+provider);
        return new ProviderManager(Arrays.asList(provider));
    }

    /* end authorization */
    
    /* csrf */
    /*
    private RequestMatcher getCsrfRequestMatcher() {
	    RequestMatcher csrfRequestMatcher = new RequestMatcher() {
	
	    	  private Pattern allowedMethods = 
	    	    Pattern.compile("^(GET|HEAD|TRACE|OPTIONS)$");
	
	    	  @Override
	    	  public boolean matches(HttpServletRequest request) {
	    	    // CSRF disabled on allowedMethod
	    	    return !(allowedMethods.matcher(request.getMethod()).matches());
	    	  }
	
	   };
	   return csrfRequestMatcher;
    }
	
    private CsrfTokenRepository getCsrfTokenRepository() {
        CookieCsrfTokenRepository tokenRepository = CookieCsrfTokenRepository.withHttpOnlyFalse();
        tokenRepository.setCookiePath("/");
        return tokenRepository;
    }*/
    /* end csrf */
    
	@Override
	protected void configure(HttpSecurity http) throws Exception {
		http.httpBasic().and()
		.cors().and()
		//https://docs.spring.io/spring-security/site/docs/current/reference/html/csrf.html
		//.csrf().disable()// csrf ist still blocking edi
		.csrf().csrfTokenRepository(CookieCsrfTokenRepository.withHttpOnlyFalse()).and()
		.sessionManagement().sessionCreationPolicy(SessionCreationPolicy.IF_REQUIRED).and()
		//getting a seesion everytime..
		//.sessionManagement().sessionCreationPolicy(SessionCreationPolicy.STATELESS).and()
		.headers().cacheControl().disable().and() // neeeded for etag support https://stackoverflow.com/questions/26742207/add-shallowetagheaderfilter-in-spring-boot-mvc
		// starts authorizing configurations
		.authorizeRequests()
		// ignoring the guest's urls "
			.antMatchers("/esp/auth/doLogin","/esp/auth/doLogout").permitAll()
			// authenticate all remaining URLS
			.anyRequest().fullyAuthenticated().and()
	      /* "/logout" will log the user out by invalidating the HTTP Session,
	       * cleaning up any {link rememberMe()} authentication that was configured, */
		.logout()
			.permitAll()
			.logoutRequestMatcher(new AntPathRequestMatcher("/esp/auth/doLogout", "POST"));
			//.and()
			//.logoutSuccessHandler(logoutSuccess)
			//.deleteCookies("JSESSIONID").invalidateHttpSession(false);
	}
	
	/* https://docs.spring.io/spring-boot/docs/current/reference/html/howto-security.html
	 * @Configuration
public class SslWebSecurityConfigurerAdapter extends WebSecurityConfigurerAdapter {

	@Override
	protected void configure(HttpSecurity http) throws Exception {
		// Customize the application security
		http.requiresChannel().anyRequest().requiresSecure();
	}

}
	 */
	
}
