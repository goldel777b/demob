package com.verizon.espservices.module.auth.entity;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the SEC_TARGET database table.
 * 
 */
@Embeddable
public class SecTargetPK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(name="APPLICATION_CONTEXT", unique=true, nullable=false, length=50)
	private String applicationContext;

	@Column(unique=true, nullable=false, length=80)
	private String target;

	public SecTargetPK() {
	}
	public String getApplicationContext() {
		return this.applicationContext;
	}
	public void setApplicationContext(String applicationContext) {
		this.applicationContext = applicationContext;
	}
	public String getTarget() {
		return this.target;
	}
	public void setTarget(String target) {
		this.target = target;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof SecTargetPK)) {
			return false;
		}
		SecTargetPK castOther = (SecTargetPK)other;
		return 
			this.applicationContext.equals(castOther.applicationContext)
			&& this.target.equals(castOther.target);
	}

	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + this.applicationContext.hashCode();
		hash = hash * prime + this.target.hashCode();
		
		return hash;
	}
}