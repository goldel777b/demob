package com.verizon.espservices.module.auth.service;

import java.math.BigDecimal;
import java.util.HashSet;
import java.util.Optional;
import java.util.Set;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.verizon.espservices.lib.core.utils.DatabaseUtilities;
import com.verizon.espservices.module.auth.entity.SecUser;
import com.verizon.espservices.module.auth.entity.SecUserRole;



// https://docs.spring.io/spring-security/site/apidocs/org/springframework/security/web/servletapi/
//@PreAuthorize("hasRole('ROLE_USER')")
//@PreAuthorize("hasAuthority('read:contacts')")
//https://hellokoding.com/registration-and-login-example-with-spring-security-spring-boot-spring-data-jpa-hsql-jsp/
// TBD testing - has good info https://docs.spring.io/spring-security/site/docs/current/reference/html/x509.html

@Service
public class AuthService implements UserDetailsService {// implements SecurityService {
	private static Log LOG = LogFactory.getLog(SecUserService.class);

	private static final String AUTH_READ = "read";

	private static final String AUTH_WRITE = "write";

    private SecUserService secUserService;
    
    public AuthService( SecUserService secUserService) {
		this.secUserService = secUserService;
	}

	@Override
	// Please take care if you plan to change Transactional as it might cause the JPA Entity to detach and 
	// the result is lazy initialization will fail
	@Transactional( readOnly=true)
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		SecUser secUser = secUserService.findByUsername(username);
		Set<SimpleGrantedAuthority> grantedAuthorities = new HashSet<>();
	    Set<SecUserRole> roles = secUser.getSecUserRoles();
		
	    LOG.debug(String.format("AuthService::loadUserByUsername call entered for %s", username));
	    LOG.debug(String.format("roles %d %s", roles.size(), roles));   
		
	    roles
 	    		.parallelStream()
 	    		.filter( s -> DatabaseUtilities.isEnabled(s.getRoleEnabled()))
 	    		.forEach( s -> {
 	    			String roleContext = s.getRoleContext();
 	    			
	    			s.getSecRole().getSecAcls().stream().forEach( secAcl -> {
	 	    			String roleContextTarget = String.format("%s.%s", roleContext, secAcl.getId().getTarget()) ;

		 	    	addEnabledReadWrite(secAcl.getIsRead(), AUTH_READ, roleContextTarget, grantedAuthorities);
	 	    		addEnabledReadWrite(secAcl.getIsWrite(), AUTH_WRITE, roleContextTarget, grantedAuthorities);
	
	    			});
 	    		});

	    // TBD XXX FIXME cheat for testing config net type
	    if (username.equals("goldlo5")) {
	    	grantedAuthorities.add(new SimpleGrantedAuthority("read:DNI.config.nettype"));
	    	grantedAuthorities.add(new SimpleGrantedAuthority("write:DNI.config.nettype"));
	    }
        LOG.debug(String.format("SecUserService::loadUserByUsername call exited for %s", username));
        return new User( secUser.getUsername(), secUser.getPassword(), 	grantedAuthorities);
    }
    
    private void addEnabledReadWrite(BigDecimal databaseEnabledField, String readOrWrite, String roleContextTarget, Set<SimpleGrantedAuthority> grantedAuthorities) {
		   if (DatabaseUtilities.isEnabled(databaseEnabledField)) {
   			   String authorityName = String.format("%s:%s",  readOrWrite, roleContextTarget);
   	         		   
   			   //grantedAuthorities.add(new SimpleGrantedAuthority(authorityName));
   			   grantedAuthorities.add(new SimpleGrantedAuthority(authorityName));
   			   LOG.debug(String.format("SecUserService::addEnabledReadWrite authority added %s", authorityName));
    	   }
    }

    public Optional<UserDetails> currentUser() {
        
    	LOG.debug("AuthService::currentUser");
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
         
        if (auth != null) {
             
            Object principal = auth.getPrincipal();
             
            LOG.debug("principal::"+principal);
            if (principal instanceof UserDetails) // User is your user type that implements UserDetails
                return Optional.of((UserDetails) principal);
            
           // https://docs.spring.io/spring-security/site/docs/current/reference/html/preauth.html
           // for pre-enthentication
           // https://docs.spring.io/spring-security/site/docs/current/reference/html/x509.html
           // TBD https
           // TBD
           // otherwise try getUserPrincipal in HttpRequest
        }
         
        return Optional.empty();
    }

 

//    //@Override
//    // not called automaticaly...
//    public void autologin(String username, String password) {
//        LOG.debug(String.format("AuthService.autologin %s %s", username, password));
//        UserDetails userDetails = secUserService.loadUserByUsername(username);
//        UsernamePasswordAuthenticationToken usernamePasswordAuthenticationToken = 
//        		new UsernamePasswordAuthenticationToken(userDetails, password, userDetails.getAuthorities());
//
//        authenticationManager.authenticate(usernamePasswordAuthenticationToken);
//
//        if (usernamePasswordAuthenticationToken.isAuthenticated()) {
//            SecurityContextHolder.getContext().setAuthentication(usernamePasswordAuthenticationToken);
//            LOG.debug(String.format("Auto login %s successfully!", username));
//        }
//        LOG.debug("AuthService::autologin exit");
//    }

	
//	public boolean login(SecUser secUser) {
//		SecUser user;
//		boolean validUser;
//		
//		LOG.debug(String.format("SecUserService::login %s%n", secUser));
//		
//		// check current user as well TBD
//		user = secUserRepository.findByUsername(secUser.getVzid());
//		
//		LOG.debug(String.format("%s%n","SecUserService::login:", secUser));
//		
//		validUser = EspPasswordEncoder.encrypt(secUser.getPassword()).equals(user.getPassword());
//		
//		if (!validUser) {
//			return false;
//		}
//		
//		/* okay save this for now in the threadlocal Authentication object */
//		
////		UsernamePasswordAuthenticationToken authReq = new UsernamePasswordAuthenticationToken(secUser.getUsername(), secUser.getPassword());
////		Authentication auth = authManager.authenticate(authReq);
////		SecurityContext securityContext = SecurityContextHolder.getContext();
////		
////		securityContext.setAuthentication(auth);
//		return true;
//		
//	}
//	
//	public boolean isAuthenticated() {
//		return SecurityContextHolder.getContext().getAuthentication().isAuthenticated();
//	} 
//        return Optional.empty();
//    }


}
