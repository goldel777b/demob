package com.verizon.espservices.module.auth.entity;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the SEC_ACL database table.
 * 
 */
@Embeddable
public class SecAclPK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(name="ROLE_ID", insertable=false, updatable=false, unique=true, nullable=false, precision=16)
	private long roleId;

	@Column(unique=true, nullable=false, length=80)
	private String target;

	public SecAclPK() {
	}
	public long getRoleId() {
		return this.roleId;
	}
	public void setRoleId(long roleId) {
		this.roleId = roleId;
	}
	public String getTarget() {
		return this.target;
	}
	public void setTarget(String target) {
		this.target = target;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof SecAclPK)) {
			return false;
		}
		SecAclPK castOther = (SecAclPK)other;
		return 
			(this.roleId == castOther.roleId)
			&& this.target.equals(castOther.target);
	}

	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + ((int) (this.roleId ^ (this.roleId >>> 32)));
		hash = hash * prime + this.target.hashCode();
		
		return hash;
	}
}