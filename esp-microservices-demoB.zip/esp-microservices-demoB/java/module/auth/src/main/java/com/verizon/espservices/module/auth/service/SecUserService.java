package com.verizon.espservices.module.auth.service;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.verizon.espservices.module.auth.entity.SecUser;
import com.verizon.espservices.module.auth.repository.SecUserRepository;



@Service 
@Transactional(propagation=Propagation.SUPPORTS, readOnly=true, rollbackFor = Exception.class)
//TBD need to update last login, failed logins etc?? or will main code handle for now?
public class SecUserService  {
 

	private static Log LOG = LogFactory.getLog(SecUserService.class);

	private SecUserRepository secUserRepository;

	public SecUserService(SecUserRepository secUserRepository) {
		this.secUserRepository = secUserRepository;
	}

	public SecUser findByUsername(String username) {
		LOG.debug("findByUsername");
		SecUser secUser = secUserRepository.findByUsername(username);
		return secUser;
	}
    
}