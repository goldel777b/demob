package com.verizon.espservices.module.auth.entity;



import java.io.Serializable;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.Collection;
import java.util.Date;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.FetchType;


import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.verizon.espservices.lib.core.utils.DatabaseUtilities;

import lombok.Data;


/**
 * The persistent class for the SEC_USER database table.
 * 
 */
@Entity
@Data
@Table(name="SEC_USER")
@NamedQuery(name="SecUser.findAll", query="SELECT s FROM SecUser s")
@JsonIgnoreProperties(ignoreUnknown = true)
public class SecUser implements UserDetails, Serializable {
	private static final long serialVersionUID = 1L;

	private static final String LOGIN_FAILED = "Login Failed";

	@Id
	@Column(name="USER_ID", unique=true, nullable=false, precision=16)
	private long userId;

//	@Column(name="CONTACT_ID", nullable=false, precision=16)
//	private BigDecimal contactId;
//
//	@Temporal(TemporalType.DATE)
//	@Column(name="DB_DATE_ADDED", nullable=false)
//	private Date dbDateAdded;
//
//	@Temporal(TemporalType.DATE)
//	@Column(name="DB_DATE_MODIFIED", nullable=false)
//	private Date dbDateModified;
//
//	@Column(name="DB_USER_ADDED", nullable=false, precision=16)
//	private BigDecimal dbUserAdded;
//
//	@Column(name="DB_USER_MODIFIED", nullable=false, precision=16)
//	private BigDecimal dbUserModified;
//
//	@Column(name="DB_VERSION", nullable=false, precision=5)
//	private BigDecimal dbVersion;
//
//	@Column(name="GARM_APPROVAL_LEVEL", length=50)
//	private String garmApprovalLevel;
//
//	@Column(name="GSAM_SENSITIVITY_LEVEL", length=2000)
//	private String gsamSensitivityLevel;
//
//	@Temporal(TemporalType.DATE)
//	@Column(name="LAST_LOGIN_DATE")
//	private Date lastLoginDate;
//
//	@Column(name="MCC_EMAIL_ID", length=255)
//	private String mccEmailId;
//
//	@Column(length=50)
//	private String mccuid;
//
//	@Column(length=1)
//	private String migration;

	@Column(length=50)
	private String password;

	@Temporal(TemporalType.DATE)
	@Column(name="PASSWORD_EXP_DATE")
	private Date passwordExpDate;

	@Column(name="PREV_PASSWD_COUNT", precision=5)
	private BigDecimal prevPasswdCount;

	@Column(name="PREVIOUS_PASSWORDS", length=1024)
	private String previousPasswords;

//	@Column(name="RESET_URL_VALUE", length=50)
//	private String resetUrlValue;
//
//	@Temporal(TemporalType.DATE)
//	@Column(name="RESET_URL_VALUE_START_DATE")
//	private Date resetUrlValueStartDate;

	@Column(name="SESSION_ID", length=120)
	private String sessionId;

	@Column(name="SESSION_LOG_ID", precision=16)
	private BigDecimal sessionLogId;

	@Column(name="TEAMNET_ID", length=50)
	private String teamnetId;

	@Column(name="USER_ADMIN_FLAG", precision=1)
	private BigDecimal userAdminFlag;

	@Column(name="USER_ADMIN_ID", precision=16)
	private BigDecimal userAdminId;

	@Column(name="USER_DISABLED_REASON", length=50)
	private String userDisabledReason;

	@Column(name="USER_ENABLED", nullable=false, precision=16)
	private BigDecimal userEnabled;

	@Column(name="USER_REGION", length=50)
	private String userRegion;

	@Column(name="USER_TYPE", nullable=false, length=50)
	private String userType;

	@Column(nullable=false, length=50)
	private String username;

	@Column(length=30)
	private String vzid;

	//bi-directional one-to-one association to LoginFailedUser
	@OneToOne(mappedBy="secUser")
	private LoginFailedUser loginFailedUser;
//
	//bi-directional many-to-one association to SecGroup
//	@ManyToOne
//	@JoinColumn(name="USER_PRIMARY_GROUP_ID", nullable=false)
//	private SecGroup secGroup;
//
//	//bi-directional many-to-one association to SecUserGroup
//	@OneToMany(mappedBy="secUser")
//	private Set<SecUserGroup> secUserGroups;
//
	//bi-directional many-to-one association to SecUserRole
	@OneToMany(mappedBy="secUser", fetch=FetchType.LAZY)
	private Set<SecUserRole> secUserRoles;
//
//	//bi-directional many-to-one association to UserSecProfileMapping
//	@OneToMany(mappedBy="secUser")
//	private Set<UserSecProfileMapping> userSecProfileMappings;

	public SecUser() {
	}

	@Override
	public Collection<? extends GrantedAuthority> getAuthorities() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean isAccountNonExpired() {
		// this is a guess TBD
		return true;
	}

	@Override
	public boolean isAccountNonLocked() {
		//TBD this is a guess
		
		return LOGIN_FAILED.equals(userDisabledReason);
	}

	@Override
	public boolean isCredentialsNonExpired() {
		// TBD this is a guess
		return true;
	}

	@Override
	public boolean isEnabled() {
		
		return DatabaseUtilities.isEnabled(userEnabled);
	}

	@Override
	public String toString() {
		return "SecUser [userId=" + userId + ", username=" + username + ", vzid=" + vzid + "]";
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		SecUser other = (SecUser) obj;
		if (userId != other.userId)
			return false;
		return true;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + (int) (userId ^ (userId >>> 32));
		return result;
	}


    
}