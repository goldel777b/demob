package com.verizon.espservices.module.auth.config;

import static org.junit.Assert.*;

import io.restassured.RestAssured;
import io.restassured.RestAssured.*;
import io.restassured.matcher.RestAssuredMatchers.*;
import org.hamcrest.Matchers.*;
import io.restassured.module.jsv.JsonSchemaValidator.*;
import io.restassured.response.Response;

import org.junit.Test;

public class ModuleAuthSecurityConfigTest {

//	@Test
//	public void givenResourceExists_whenRetrievingResource_thenEtagIsAlsoReturned() {
//		// Given
//		String uriOfResource = "http://localhost:8090";// = createAsUri();
//	
//		// When
//		Response findOneResponse = RestAssured.given().header("Accept", "application/json").get(uriOfResource);
//	
//		// Then
//		assertNotNull(findOneResponse.getHeader("ETag"));
//	}

}
