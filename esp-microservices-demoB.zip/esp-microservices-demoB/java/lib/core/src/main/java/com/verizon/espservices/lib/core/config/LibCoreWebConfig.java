package com.verizon.espservices.lib.core.config;

import java.util.Collections;

import javax.persistence.EntityManager;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.ApplicationContext;
import org.springframework.context.MessageSource;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.support.ResourceBundleMessageSource;
import org.springframework.core.Ordered;
import org.springframework.validation.Validator;
import org.springframework.validation.beanvalidation.LocalValidatorFactoryBean;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;
import org.springframework.web.filter.CorsFilter;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ViewResolver;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.ViewControllerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;
//import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;
//import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;
import org.springframework.web.servlet.view.InternalResourceViewResolver;
import org.springframework.web.servlet.view.JstlView;
import org.springframework.web.filter.ShallowEtagHeaderFilter;

@Configuration
//@EnableWebMvc spring boot automatically takes care of
// Only change when moving to Java8
/*  https://docs.spring.io/spring-boot/docs/current/reference/html/boot-features-developing-web-applications.html
 *  
 *  If you want to keep Spring Boot MVC features and you want to add additional 
 *  you can add your own @Configuration class of type WebMvcConfigurer but without @EnableWebMvc. 
 *  If you wish to provide custom instances of RequestMappingHandlerMapping, RequestMappingHandlerAdapter,
 *  or ExceptionHandlerExceptionResolver, 
 *  you can declare a WebMvcRegistrationsAdapter instance to provide such components.
 */
public class LibCoreWebConfig implements WebMvcConfigurer {   
	
	private static Log LOG = LogFactory.getLog(LibCoreWebConfig.class);

    private final ApplicationContext applicationContext;
    private final EntityManager entityManager;

    public LibCoreWebConfig(ApplicationContext applicationContext, EntityManager entityManager) {
        this.applicationContext = applicationContext;
        this.entityManager = entityManager;
    }
    
    @Value("${spring.angular.cors.url}")
    private String corsOrigins;

    @Bean
    @SuppressWarnings("unchecked")
    public FilterRegistrationBean simpleCorsFilter() {
    	LOG.debug("simpleCorsFilter::"+corsOrigins);
    	
        UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
        CorsConfiguration config = new CorsConfiguration();
        config.setAllowCredentials(true);
        config.setAllowedOrigins(Collections.singletonList(corsOrigins));
        config.setAllowedMethods(Collections.singletonList("*"));
        config.setAllowedHeaders(Collections.singletonList("*"));
        source.registerCorsConfiguration("/**", config);
        FilterRegistrationBean bean = new FilterRegistrationBean(new CorsFilter(source));
        bean.setOrder(Ordered.HIGHEST_PRECEDENCE);
        return bean;
    }
	
//	@Override
//    public void addViewControllers(ViewControllerRegistry registry) {
//	    //registry.addViewController("/").setViewName("NetType");
//	    //registry.addViewController("/NetTypeEditView").setViewName("NetTypeEditView");
//	}
	
    public void addResourceHandlers(ResourceHandlerRegistry registry) {
        registry
          .addResourceHandler("/webjars/**")
          .addResourceLocations("/webjars/");
        
        registry
        .addResourceHandler("/resources/**")
        .addResourceLocations("/resources/"); 
    }

    @Bean
    public ViewResolver getViewResolver(){
        InternalResourceViewResolver resolver = new InternalResourceViewResolver();
        resolver.setPrefix("/WEB-INF/jsp/");
        resolver.setSuffix(".jsp");
        resolver.setViewClass(JstlView.class);
        return resolver;
    }
    
	@Bean
	public MessageSource messageSource() {
		ResourceBundleMessageSource messageSource = new ResourceBundleMessageSource();
		messageSource.setBasename("messages");
		messageSource.setDefaultEncoding("UTF-8");
		return messageSource;
	}   
	
	@Override
    public Validator getValidator() {
		LocalValidatorFactoryBean validator = new LocalValidatorFactoryBean();
		validator.setValidationMessageSource(messageSource());
		 return validator;
   }
	
	
		
	@Bean
	public ModelMapper modelMapper() {
	    return new ModelMapper();
	}   
	
	@Bean
    public ShallowEtagHeaderFilter shallowEtagHeaderFilter() {
        return new ShallowEtagHeaderFilter();
    }

	/*
    @Bean
    public UndertowEmbeddedServletContainerFactory embeddedServletContainerFactory() {
        UndertowEmbeddedServletContainerFactory factory = new UndertowEmbeddedServletContainerFactory();
        factory.addBuilderCustomizers(new UndertowBuilderCustomizer() {
            @Override
            public void customize(Builder builder) {
            	logger.info("customize");
            	/**
            	builder.addHttpListener(9090, "localhost").setHandler(new HttpHandler() {
            		  
                      public void handleRequest(final HttpServerExchange exchange)
                              throws Exception {
                    	  logger.info("handler");
                          exchange.getResponseHeaders().put(Headers.ETAG,
                                  "1234");                
                      }
                  }).build();
            }
        });
        return factory;
    }
  */
	
	
//	@Bean
//	public HttpAllowOriginAdapter httpAllowOriginAdapter() {
//	    return new HttpAllowOriginAdapter();
//	}
//	
//  
//	  
//
//	  @Override
//	  public void addInterceptors(InterceptorRegistry registry) {
//		  LOG.debug("addInterceptors called");
//		  registry.addInterceptor(httpAllowOriginAdapter()); 
//
//	  }
	

//    @Override
//    public void addInterceptors(final InterceptorRegistry registry) {
//        registry.addInterceptor(new LoggerInterceptor());
//        registry.addInterceptor(new UserInterceptor());
//        registry.addInterceptor(new SessionTimerInterceptor());
//    }

//   handled locally in module that defines the model mapper class
//    @Override // for ModelMapper @ConfigNetTypeDTOAnnotation
//    public void addArgumentResolvers(List<HandlerMethodArgumentResolver> argumentResolvers) {
//        //super.addArgumentResolvers(argumentResolvers); 
//        LOG.info("LibCoreWebConfig::addArgumentResolvers");
//        
//        ObjectMapper objectMapper = Jackson2ObjectMapperBuilder.json().applicationContext(this.applicationContext).build();
//        argumentResolvers.add(new ConfigNetTypeDTOModelMapper(objectMapper, entityManager));
//    }
}
