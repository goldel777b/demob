package com.verizon.espservices.lib.core.debug;

import java.util.Arrays;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;

public class PrintBeans {
	private static Log LOG = LogFactory.getLog(PrintBeans.class);
 
	@Autowired
    private ApplicationContext applicationContext;

	public void printBeans() {
		LOG.info("printBeans::"+applicationContext);
		LOG.info(Arrays.asList(applicationContext.getBeanDefinitionNames()));
        //System.out.println(Arrays.asList(applicationContext.getBeanDefinitionNames()));
    }
}