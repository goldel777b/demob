package com.verizon.espservices.lib.core;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;


@SpringBootApplication
@ComponentScan({"com.verizon.espservices","com.verizon.espservices.auth"})
//@EnableAutoConfiguration
public class LibCoreApplication {

	public static void main(String[] args) {
		SpringApplication.run(LibCoreApplication.class, args);
	}
	
	

}