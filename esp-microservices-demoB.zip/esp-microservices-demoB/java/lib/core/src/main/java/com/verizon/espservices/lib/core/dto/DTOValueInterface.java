package com.verizon.espservices.lib.core.dto;

public interface DTOValueInterface {
	Class<DTOValueInterface> value();
}
