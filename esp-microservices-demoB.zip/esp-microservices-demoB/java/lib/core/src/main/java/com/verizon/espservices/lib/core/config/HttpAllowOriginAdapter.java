//package com.verizon.espservices.lib.core.config;
//
//import javax.servlet.http.HttpServletRequest;
//import javax.servlet.http.HttpServletResponse;
//
//import org.apache.commons.logging.Log;
//import org.apache.commons.logging.LogFactory;
//import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;
//
//
//public class HttpAllowOriginAdapter extends HandlerInterceptorAdapter {
//	  private static Log LOG = LogFactory.getLog(HttpAllowOriginAdapter.class);
//	
//
//	  @Override
//	  public boolean preHandle(HttpServletRequest request,
//	                           HttpServletResponse response, Object handler) throws Exception {
//		 
//		LOG.info("HttpAllowOriginAdapter.preHandle before::" + response.getHeader("Access-Control-Allow-Origin") + "::" + response.getHeader("Access-Control-Allow-Methods"));
//	    response.setHeader("Access-Control-Allow-Origin", "*");
//	    response.setHeader("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS");
//	    return true;
//	  }
//	}
