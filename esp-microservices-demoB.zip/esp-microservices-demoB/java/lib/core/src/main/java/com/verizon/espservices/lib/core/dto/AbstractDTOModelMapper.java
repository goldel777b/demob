package com.verizon.espservices.lib.core.dto;

import java.io.IOException;
import java.lang.annotation.Annotation;
import java.lang.reflect.Field;
import java.lang.reflect.Type;
import java.util.Collections;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Id;
import javax.validation.constraints.NotNull;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.modelmapper.ModelMapper;
import org.springframework.core.MethodParameter;
import org.springframework.core.annotation.AnnotationUtils;
import org.springframework.http.HttpInputMessage;
import org.springframework.http.converter.HttpMessageConverter;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.web.HttpMediaTypeNotSupportedException;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.support.WebDataBinderFactory;
import org.springframework.web.context.request.NativeWebRequest;
import org.springframework.web.method.support.ModelAndViewContainer;
import org.springframework.web.servlet.mvc.method.annotation.RequestResponseBodyMethodProcessor;

import com.fasterxml.jackson.databind.ObjectMapper;


// this can't be abstract as spring complains.. but it really is..
// please implement getDTOClass in subclass 
public class AbstractDTOModelMapper<A extends Annotation> extends RequestResponseBodyMethodProcessor  {
	
	    private static Log LOG = LogFactory.getLog(AbstractDTOModelMapper.class);
	   
	    private ModelMapper modelMapper;
	   
	    private EntityManager entityManager;

	    public AbstractDTOModelMapper(ObjectMapper objectMapper, EntityManager entityManager) {
	    	// List<HttpMessageConverter<?>> converters
	    	// HttpMessageConverter<T>
	        super(Collections.singletonList(new MappingJackson2HttpMessageConverter(objectMapper)));
	        
	        LOG.debug(String.format("AbstractDTOModelMapper::AbstractDTOModelMapper %s %s%n", objectMapper, entityManager));

	        this.entityManager = entityManager;
	    }
	    
	    protected Class<A> getDTOClass() {
	    	throw new IllegalStateException("Implement me in subclass");
	    }

	    @Override
	    public boolean supportsParameter(MethodParameter parameter) {
	    	
	        
	        LOG.debug(String.format("AbstractDTOModelMapper::supportsParameter %s%n", parameter));

	        return parameter.hasParameterAnnotation(getDTOClass());
	    }

	    @Override
	    protected void validateIfApplicable(WebDataBinder binder, MethodParameter parameter) {
	        LOG.debug(String.format("AbstractDTOModelMapper::validateIfApplicable %s %s%n", binder, parameter));
	    	
	        binder.validate();
	    }

	    @Override
	    // THis is not getting called TBD
	    public Object resolveArgument(MethodParameter parameter, ModelAndViewContainer mavContainer, NativeWebRequest webRequest, WebDataBinderFactory binderFactory) throws Exception {
	        Object dto = super.resolveArgument(parameter, mavContainer, webRequest, binderFactory);
	        Object id = getEntityId(dto);
	        
	        LOG.debug(String.format("AbstractDTOModelMapper::resolveArgument %s %s %s%n", parameter, dto, id));
	        
	        if (id == null) {
	            return modelMapper.map(dto, parameter.getParameterType());
	        } else { // if @Id defined, search database for matching
	            Object persistedObject = entityManager.find(parameter.getParameterType(), id);
	            
	            modelMapper.map(dto, persistedObject);
	            return persistedObject;
	        }
	    }

	    
	    @Override
	    protected Object readWithMessageConverters(HttpInputMessage inputMessage, MethodParameter parameter, Type targetType) throws IOException, HttpMediaTypeNotSupportedException, HttpMessageNotReadableException {
	        LOG.debug(String.format("AbstractDTOModelMapper::readWithMessageConverters %s %s %s%n", inputMessage, parameter, targetType));
	    	
	    	for (Annotation ann : parameter.getParameterAnnotations()) {
	    		//public static <A extends Annotation> A getAnnotation(Annotation ann, Class<A> annotationType) {
	    		DTOValueInterface dtoType = (DTOValueInterface )AnnotationUtils.getAnnotation(ann, ann.annotationType());//ConfigNetTypeDTOAnnotation.class);
	        	//DTOValueInterface dtoType = (DTOValueInterface) getAnnotationClass(ann);
	        
	            if (dtoType != null) {
	                return readWithMessageConverters(inputMessage, parameter, dtoType.value());
	            }
	        }
	        throw new RuntimeException();
	    }

	    private Object getEntityId(@NotNull Object dto) {
	        for (Field field : dto.getClass().getDeclaredFields()) {
	            if (field.getAnnotation(Id.class) != null) {
	                try {
	                    field.setAccessible(true);
	                    return field.get(dto);
	                } catch (IllegalAccessException e) {
	                    throw new RuntimeException(e);
	                }
	            }
	        }
	        return null;
	    }
}
