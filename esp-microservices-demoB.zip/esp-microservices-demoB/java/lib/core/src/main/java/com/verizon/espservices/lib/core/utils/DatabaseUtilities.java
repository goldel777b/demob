package com.verizon.espservices.lib.core.utils;

import java.math.BigDecimal;

public class DatabaseUtilities {
	// tbd - sometimes it is 0, 1 and blank. FIXME
	public static boolean isEnabled(BigDecimal indicator) {
		return BigDecimal.valueOf(1).equals(indicator);
	}
}
