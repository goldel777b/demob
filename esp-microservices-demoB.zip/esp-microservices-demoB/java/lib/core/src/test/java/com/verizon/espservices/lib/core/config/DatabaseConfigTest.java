package com.verizon.espservices.lib.core.config;

import static org.junit.Assert.assertTrue;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.sql.DataSource;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.verizon.espservices.lib.core.config.DatabaseConfig;



//@RunWith(SpringRunner.class)
//@SpringBootTest
//@RunWith(SpringRunner.class)
//@SpringBootTest(classes = {
//  SpringAngularApplication.class, 
//  DatabaseConfig.class})
////@ActiveProfiles("test")
//http://www.javarticles.com/2016/02/spring-value-annotation-example.html  @Value issue
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = {DatabaseConfig.class})
@TestPropertySource("/application.properties")
public class DatabaseConfigTest {
	
	@Autowired
	DataSource dataSource;

	@Test
	public void testDatasource() throws SQLException {
		
//		DriverManager.registerDriver (new oracle.jdbc.driver.OracleDriver());
//		Connection conn2 = 
//				   DriverManager.getConnection ("jdbc:oracle:thin:@esppdtd1scan:1800/COMMDEV",
//				       "ESPADMIN", "AdmX616#");
//		
//		assertTrue("Conn2 was not set", conn2 != null);
		assertTrue("Datasource was not set", dataSource != null);
		
		try (Connection conn = dataSource.getConnection();
				PreparedStatement statement = conn.prepareStatement("select orders_id, order_number, site_id from esp.orders where orders_id =?")) {
			statement.setInt(1, 4301945);
			
			ResultSet results = statement.executeQuery();
			
			while (results.next()) {
				String res = String.format("order_id=%d, order_number=%s, site_id=%d",
						results.getInt(1), results.getString(2), results.getInt(1));
				
				System.out.println(res);
			
			}
			
		}
	}

}
