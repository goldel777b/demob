https://spring.io/guides/tutorials/spring-security-and-angular-js/#using-spring-tool-suite

https://github.com/dsyer/spring-boot-angular

https://www.concretepage.com/spring-boot/spring-boot-rest-angular-2-jpa-hibernate-mysql-crud-example

mvn eclipse:clean
mvn eclipse:eclipse
mvn clean install

You will need to run lombok jar and install into eclipse folders - need Admin permission. 
As an alternative, copy eclipse to  our user account and run lombok jar.  You may need
to re-install Spring Tools Suite




