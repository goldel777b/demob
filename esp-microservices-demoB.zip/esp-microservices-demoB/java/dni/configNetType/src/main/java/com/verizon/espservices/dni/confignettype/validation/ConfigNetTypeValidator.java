package com.verizon.espservices.dni.confignettype.validation;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Indexed;

import com.verizon.espservices.dni.confignettype.entity.ConfigNetType;
import com.verizon.espservices.dni.confignettype.service.ConfigNetTypeService;

@Component
public class ConfigNetTypeValidator implements ConstraintValidator<ConfigNetTypeAnnotation, ConfigNetType> {
	private static Log LOG = LogFactory.getLog(ConfigNetTypeValidator.class);

	@Autowired
	private ConfigNetTypeService configNetTypeService;

	public ConfigNetTypeValidator() {
		LOG.info("ConfigNetTypeValidator() called");
		//this.configNetTypeService = null;  // this is a problem TBD this validator iscalled by save on repo 
	}
	
//	public ConfigNetTypeValidator(ConfigNetTypeService configNetTypeService) {
//		LOG.info("ConfigNetTypeValidator(ConfigNetTypeService) called");
//
//		this.configNetTypeService = configNetTypeService;
//	}
 
//    public void initialize(UniqueNetType constraintAnnotation) {
//     }
 
	// TBD fix all this XXX checkign for existence in controller vs here
	// service is not gettng autowired...
	 public boolean isValid(ConfigNetType configNetType, ConstraintValidatorContext context) {
        String netType = configNetType.getNetType();
        boolean isNew = configNetType.isNew();
//        boolean configNetTypeExists;
//        
//        configNetTypeExists =  configNetTypeService.get(netType.toString()).isPresent();
//        
//        LOG.info(String.format("UniqueNetTpeValidator::isValid netType=%s isNew=%s%n", netType, isNew));
//        
//        if (isNew && configNetTypeExists) {
//        	return false;
//        }
//        if (!isNew && !configNetTypeExists) {
//        	return false;
//        }
        return true;
    }


}
