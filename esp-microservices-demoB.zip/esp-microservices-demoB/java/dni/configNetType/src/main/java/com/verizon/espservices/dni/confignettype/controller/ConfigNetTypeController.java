package com.verizon.espservices.dni.confignettype.controller;

import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.modelmapper.ModelMapper;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.verizon.espservices.dni.confignettype.dto.ConfigNetTypeDTO;
import com.verizon.espservices.dni.confignettype.dto.ConfigNetTypeDTOAnnotation;
import com.verizon.espservices.dni.confignettype.entity.ConfigNetType;
import com.verizon.espservices.dni.confignettype.service.ConfigNetTypeService;

@RestController
@RequestMapping("${rest.spring.dni.config.net.type}")
@CrossOrigin(origins ="${spring.angular.cors.url}", maxAge=3600)
public class ConfigNetTypeController {	
	
	private static Log LOG = LogFactory.getLog(ConfigNetTypeController.class);

	private final ConfigNetTypeService configNetTypeService;
	private final ModelMapper modelMapper;
	
	public ConfigNetTypeController(ConfigNetTypeService configNetTypeService, ModelMapper modelMapper) {
		this.configNetTypeService = configNetTypeService;
		this.modelMapper = modelMapper;
	}
	
	
	@GetMapping("/list")
	public List<ConfigNetTypeDTO> list() {//Model model) {
		LOG.debug("ConfigNetTypeController.list called");
		
		List<ConfigNetTypeDTO> configNetTypeList = StreamSupport.stream(configNetTypeService.list().spliterator(), false)
				                                .parallel()
												.map(c -> modelMapper.map(c, ConfigNetTypeDTO.class))
												.collect(Collectors.toList());
		
		
		LOG.debug(String.format("ConfigNetTypeController.list configNetTypeListItems added - %s%n", configNetTypeList));
		return configNetTypeList;
	}
	
	
	@PutMapping("/doCreate")  // put is idempotent
	//FIXME validation + error handling
	// https://auth0.com/blog/automatically-mapping-dto-to-entity-on-spring-boot-apis/
	public String doCreate(@Validated @RequestBody @ConfigNetTypeDTOAnnotation(ConfigNetTypeDTO.class) ConfigNetType configNetType,
						   BindingResult result,
						   RedirectAttributes redirectAttributes) {
		
		String msg = String.format("ConfigNetTypeController doCreate=%s%n", configNetType);
		
		LOG.debug(msg);
		
		if (result.hasErrors()) {
			LOG.error(result.getAllErrors());

			if ("UniqueNetType".equals(result.getFieldError().getCode())) {
				ModelAndView  mview = new ModelAndView("configNetTypeCreateEdit");

				mview.addObject("configNetType", configNetType);
				mview.addObject("postUrl", "doEdit");
			}
			return  "{ \"create\": \"okay\" }";//"FIXME Automate";
		}
		
//      handled in Validation
//		if (configNetTypeService.get(configNetType.getNetType()).isPresent()) {
//			throw new IllegalStateException(String.format("ConfigNetTypeController::doCreate - trying to create an existing netType %s%n", configNetType));
//		}
//		
		configNetTypeService.create(configNetType);

		return "{ \"create\": \"okay\" }";
	}
	

	@PostMapping("/doEdit")
	//FIXME validation + error handling
	// TBD verify that the versions match - structure this
	public String doEdit(@Validated @RequestBody @ConfigNetTypeDTOAnnotation(ConfigNetTypeDTO.class)  ConfigNetType configNetType) {
		String msg = String.format("ConfigNetTypeController doEdit=%s%n", configNetType);
		
		
		LOG.debug(msg);
		
		if (!configNetTypeService.get(configNetType.getNetType()).isPresent()) {
			throw new IllegalStateException(String.format("ConfigNetTypeController::doEdit - trying to create a non-existent netType %s%n", configNetType));
		}
		configNetTypeService.update(configNetType);	
		return "{ \"edit\": \"okay\" }";
	}
	
	//@DeleteMapping("/doDelete")  FIXME - change angular side and this side to do /doDelete/{netType} and add etag in header, 
	//as angular won't send header with delete
	// for now use PutMapping
	@PutMapping("/doDelete")
	//FIXME validation + error handling
	public String doDelete(@Validated @RequestBody @ConfigNetTypeDTOAnnotation(ConfigNetTypeDTO.class) ConfigNetType configNetType) {
		String msg = String.format("ConfigNetTypeController doEdit=%s%n", configNetType);
		
		
		LOG.debug(msg);
		
		if (!configNetTypeService.get(configNetType.getNetType()).isPresent()) {
			throw new IllegalStateException(String.format("ConfigNetTypeController::doEdit - trying to create a non-existent netType %s%n", configNetType));
		}
		configNetTypeService.delete(configNetType);	
		return  "{ \"delete\": \"okay\" }";
	}
	
}


