package com.verizon.espservices.dni.confignettype.config;


import java.util.Collections;
import java.util.List;

import javax.persistence.EntityManager;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.Ordered;
import org.springframework.http.converter.json.Jackson2ObjectMapperBuilder;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;
import org.springframework.web.filter.CorsFilter;
import org.springframework.web.method.support.HandlerMethodArgumentResolver;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.verizon.espservices.dni.confignettype.dto.ConfigNetTypeDTOModelMapper;

@Configuration
//@ComponentScan
//@EnableWebMvc spring boot automatically takes care of
// Only change when moving to Java8

// See lib/core LibCoreWebConfig for shared configuration
public class DniConfigNetTypeWebConfig implements WebMvcConfigurer {   
	
	private static Log LOG = LogFactory.getLog(DniConfigNetTypeWebConfig.class);

	
    private final ApplicationContext applicationContext;
    private final EntityManager entityManager;

    //@Autowired
    public DniConfigNetTypeWebConfig(ApplicationContext applicationContext, EntityManager entityManager) {
        this.applicationContext = applicationContext;
        this.entityManager = entityManager;
    }

    @Override // for ModelMapper @ConfigNetTypeDTOAnnotation
    public void addArgumentResolvers(List<HandlerMethodArgumentResolver> argumentResolvers) {
        //super.addArgumentResolvers(argumentResolvers); 
        LOG.info("LibCoreWebConfig::addArgumentResolvers");
        
        ObjectMapper objectMapper = Jackson2ObjectMapperBuilder.json().applicationContext(this.applicationContext).build();
        argumentResolvers.add(new ConfigNetTypeDTOModelMapper(objectMapper, entityManager));
    }
}
