package com.verizon.espservices.dni.confignettype.validation;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;


@NotBlank(message="{netTypeIsEmpty}")
@Size(min=1, max=50, message="{netTypeSizeError}")
@Target(ElementType.FIELD)
@Retention(RetentionPolicy.RUNTIME)
@Documented
public @interface NetTypeAnnotation {
	   //String message() default "{netTypeDuplicated}";
	   String[] groups() default {};
}
