package com.verizon.espservices.dni.confignettype.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.verizon.espservices.dni.confignettype.validation.ConfigNetTypeAnnotation;
import com.verizon.espservices.dni.confignettype.validation.NetTypeAnnotation;

import lombok.Data;


/**
 * The persistent class for the CONFIG_NET_TYPE database table.
 * 
 */
@Entity
@Table(name="CONFIG_NET_TYPE")
@NamedQuery(name="ConfigNetType.findAll", query="SELECT c FROM ConfigNetType c")
@Data
@ConfigNetTypeAnnotation
@JsonIgnoreProperties(ignoreUnknown = true)
public class ConfigNetType implements Serializable {
	//TBD set serialVersionUID
	private static final long serialVersionUID = 1L;

	@Id
	@NetTypeAnnotation
	@Column(name="NET_TYPE", unique=true, nullable=false, length=50)
	private String netType;

	@NotNull
	@Column(name="BACKBONE_MANUFACTURER", nullable=false, length=50)
	private String backboneManufacturer;

	@NotNull
	@Column(name="BACKBONE_MODEL", nullable=false, length=50)
	private String backboneModel;

	@NotNull
	@Column(name="BACKBONE_ROUTER_TYPE", nullable=false, length=50)
	private String backboneRouterType;

//	@Temporal(TemporalType.DATE)
//	@Column(name="DB_DATE_ADDED", nullable=false)
//	private Date dbDateAdded;
//
//	@Temporal(TemporalType.DATE)
//	@Column(name="DB_DATE_MODIFIED", nullable=false)
//	private Date dbDateModified;
//
//	@Column(name="DB_USER_ADDED", nullable=false, precision=16)
//	private BigDecimal dbUserAdded;
//
//	@Column(name="DB_USER_MODIFIED", nullable=false, precision=16)
//	private BigDecimal dbUserModified;
//
//	@Column(name="DB_VERSION", precision=5)
//	private BigDecimal dbVersion;
	
	@NotNull
	@Column(nullable=false, length=50)
	private String template;
	
	@Transient
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private boolean isNew;

	public ConfigNetType() {
	}

	
}