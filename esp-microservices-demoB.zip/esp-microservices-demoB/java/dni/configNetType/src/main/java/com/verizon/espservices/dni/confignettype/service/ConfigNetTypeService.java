package com.verizon.espservices.dni.confignettype.service;

import java.util.Optional;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.verizon.espservices.dni.confignettype.entity.ConfigNetType;
import com.verizon.espservices.dni.confignettype.repository.ConfigNetTypeRepository;

@Service // singleton by default, do not put any local non-final variables in this class 
         // think carefully in session or request level data is needed, this is not the best place to 'store it'!
@Transactional(propagation=Propagation.SUPPORTS, readOnly=false, rollbackFor = Exception.class)
public class ConfigNetTypeService {
	
	private static Log LOG = LogFactory.getLog(ConfigNetTypeService.class);
	
	
	@Autowired
	private ConfigNetTypeRepository configNetTypeRepository;
	
	
	public Iterable<ConfigNetType> list() {
		
//	    PageRequest pageReq
//	     = new PageRequest(page, size, Sort.Direction.fromString(sortDir), sort);
//	    Page<ConfigNetType> configNetTypeList = configNetTypeRepository.findAll(pageReq);
//	    return configNetTypeList.getContent();
	    
		Iterable<ConfigNetType> configNetTypeList = configNetTypeRepository.findAllByOrderByNetTypeAsc();
		
		
		LOG.info(String.format("ConfigNetTypeService::list %s%n", configNetTypeList));
		return configNetTypeList;
	}
	
	
	
//	public Optional<Iterable<ConfigNetType>> findAll() {
//		Iterable<ConfigNetType> allConfigNetTypes = configNetTypeRepository.findAll();
//		
//		// TBD how to hide - really hide the data directly from database w/o transferring it?
//		// do we need to hid it?
//		return Optional.of(allConfigNetTypes);
//	}
	
	public Optional<ConfigNetType> get(String netType) {
		LOG.info(String.format("ConfigNetTypeService::get %s%n", netType));
		
		return configNetTypeRepository.findById(netType);
	}
	
	@Transactional(propagation=Propagation.SUPPORTS, readOnly=false) // TBD
	public boolean create(ConfigNetType configNetType) {
		configNetTypeRepository.save(configNetType);
		
		// put in post commit handler
		return true;
	}
	
	@Transactional(propagation=Propagation.SUPPORTS, readOnly=false) // TBD
	public boolean update(ConfigNetType updatedConfigNetType) {
		Optional<ConfigNetType> databaseConfigNetType = configNetTypeRepository.findById(updatedConfigNetType.getNetType());
		
		if (!databaseConfigNetType.isPresent()) {
			// handle error message
			return false;
		}
		
		LOG.info(String.format("ConfigNetTypeService update=%s%n", updatedConfigNetType));
		configNetTypeRepository.save(updatedConfigNetType);
		// flash message? TBD type of messaging inuse in the system
		
		return true;
	}
	
	@Transactional(propagation=Propagation.SUPPORTS, readOnly=false) // TBD
	public boolean delete(ConfigNetType deleteConfigNetType) {
		Optional<ConfigNetType> databaseConfigNetType = configNetTypeRepository.findById(deleteConfigNetType.getNetType());
		
		if (!databaseConfigNetType.isPresent()) {
			// handle error message
			return false;
		}
		
		configNetTypeRepository.delete(deleteConfigNetType);
		// flash message? TBD type of messaging inuse in the system
		
		return true;
	}
	


}
