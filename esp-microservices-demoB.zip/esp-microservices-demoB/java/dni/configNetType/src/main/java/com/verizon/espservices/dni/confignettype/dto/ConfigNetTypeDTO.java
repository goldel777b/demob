package com.verizon.espservices.dni.confignettype.dto;

import javax.persistence.Id;

import lombok.Data;

@Data
public class ConfigNetTypeDTO {
	
	@Id
	private String netType;

	private String backboneManufacturer;
	
	private String backboneModel;

	private String backboneRouterType;
	
	private String template;
	
	private String isNew;
	
//	@JsonIgnore
//	private String ignoreMe;
	
}
