package com.verizon.espservices.dni.confignettype;


import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan({"com.verizon.espservices","com.verizon.espservices.auth"})
//@EnableAutoConfiguration
public class DniConifgNetTypeApplication {

	public static void main(String[] args) {
		SpringApplication.run(DniConifgNetTypeApplication.class, args);
	}
	
	

}