package com.verizon.espservices.dni.confignettype.controller;

import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.verizon.espservices.dni.confignettype.dto.ConfigNetTypeDTO;
import com.verizon.espservices.dni.confignettype.dto.ConfigNetTypeDTOAnnotation;
import com.verizon.espservices.dni.confignettype.entity.ConfigNetType;
import com.verizon.espservices.dni.confignettype.service.ConfigNetTypeService;

@Controller
@RequestMapping("/configNetTypeJsp")
public class ConfigNetTypeJspController {	
	
	private static Log LOG = LogFactory.getLog(ConfigNetTypeJspController.class);

	private final ConfigNetTypeService configNetTypeService;
	private final ModelMapper modelMapper;
	
	public ConfigNetTypeJspController(ConfigNetTypeService configNetTypeService, ModelMapper modelMapper) {
		this.configNetTypeService = configNetTypeService;
		this.modelMapper = modelMapper;
	}
	
	@GetMapping(value = "/listJson", produces="application/json")
	public ModelAndView listJson() {//Model model) {
		LOG.debug("ConfigNetTypeController.list called");
		
		ModelAndView mview = new ModelAndView("configNetTypeList");
		//convert to ConfigNetTypeDTOAnnotation
		List<ConfigNetTypeDTO> configNetTypeList = StreamSupport.stream(configNetTypeService.list().spliterator(), false)
				                                .parallel()
												.map(c -> modelMapper.map(c, ConfigNetTypeDTO.class))
												.collect(Collectors.toList());
		
		
		mview.addObject("configNetTypeList", configNetTypeList);		//mview.addObject("configNetTypeListItems", configNetTypeListItems.iterator().);
		
		LOG.debug(String.format("ConfigNetTypeController.list configNetTypeListItems added - %s%n", configNetTypeList));
		return mview;
	}
	
	@GetMapping("/list")
	public ModelAndView list() {
		LOG.debug("ConfigNetTypeController.list called");
		
		ModelAndView mview = new ModelAndView("configNetTypeList");
		//convert to ConfigNetTypeDTOAnnotation
		List<ConfigNetTypeDTO> configNetTypeList = StreamSupport.stream(configNetTypeService.list().spliterator(), false)
				                                .parallel()
												.map(c -> modelMapper.map(c, ConfigNetTypeDTO.class))
												.collect(Collectors.toList());
		
		
		mview.addObject("configNetTypeList", configNetTypeList);
		
		LOG.debug(String.format("ConfigNetTypeController.list configNetTypeListItems added - %s%n", configNetTypeList));
		return mview;
	}
	
	@GetMapping("/create")
	//TODO remap ConfigNetType to ConfigNetTypeDTOAnnotation
	public ModelAndView create() {
		
		LOG.debug("ConfigNetTypeController.create get");
		
		//TBD share screen by sending post url
		ModelAndView  mview = new ModelAndView("configNetTypeCreateEdit");
		
		// if not isPresent TBD handle error
		mview.addObject("configNetType", modelMapper.map(new ConfigNetType(), ConfigNetTypeDTO.class));
		mview.addObject("postUrl", "doCreate");
		
		LOG.debug("ConfigNetTypeController.create get exit");
		return mview;
	}
	
	@PostMapping("/doCreate")
	//FIXME validation + error handling
	public String doCreate(@Validated @ModelAttribute("configNetType") @ConfigNetTypeDTOAnnotation(ConfigNetTypeDTO.class) ConfigNetType configNetType,
						   BindingResult result,
						   RedirectAttributes redirectAttributes) {
		
		String msg = String.format("ConfigNetTypeController doCreate=%s%n", configNetType);
		
		LOG.debug(msg);
		/*
		 *  [Field error in object 'configNetType' on field 'netType': rejected value [LORI_TEST]; 
		 *  codes [UniqueNetType.configNetType.netType,UniqueNetType.netType,
		 *  UniqueNetType.java.lang.String,UniqueNetType]; 
		 *  arguments [org.springframework.context.support.DefaultMessageSourceResolvable: 
		 *  codes [configNetType.netType,netType]; arguments []; 
		 *  default message [netType]]; default message [NetTypeAnnotation already exists]]

		 */
		if (result.hasErrors()) {
			LOG.error(result.getAllErrors());

			if ("UniqueNetType".equals(result.getFieldError().getCode())) {
				ModelAndView  mview = new ModelAndView("configNetTypeCreateEdit");

				mview.addObject("configNetType", configNetType);
				mview.addObject("postUrl", "doEdit");
			}
			return "configNetTypeCreateEdit";
		}
	
		configNetTypeService.create(configNetType);

		//FIXME goes to configNetType/edit on url but it looks like it reall goes to home.jsp
		return "configNetType";
	}
	
	
	
	
	@GetMapping("/{netType}/edit")
	public ModelAndView edit(@PathVariable(value = "netType") String netType) {
		
		LOG.debug(String.format("ConfigNetTypeController.edit %s%n", netType));
		
		ModelAndView  mview = new ModelAndView("configNetTypeCreateEdit");
		ConfigNetTypeDTO configNetType =  modelMapper.map(configNetTypeService.get(netType).get(), ConfigNetTypeDTO.class);
		
		mview.addObject("configNetType", configNetType);
		mview.addObject("postUrl", "doEdit");
		
		LOG.debug(String.format("ConfigNetTypeController.edit exit %s%n", configNetType));
		return mview;
	}

	@PostMapping("/doEdit")
	//FIXME validation + error handling
	public String doEdit(@ModelAttribute("configNetType") @ConfigNetTypeDTOAnnotation(ConfigNetTypeDTO.class) ConfigNetType configNetType) {
		String msg = String.format("ConfigNetTypeController doEdit=%s%n", configNetType);
		
		
		LOG.debug(msg);
		
		if (!configNetTypeService.get(configNetType.getNetType()).isPresent()) {
			throw new IllegalStateException(String.format("ConfigNetTypeController::doEdit - trying to create a non-existent netType %s%n", configNetType));
		}
		configNetTypeService.update(configNetType);	
		return "configNetType";
	}


	
	@PostMapping("/doDelete")
	public String doDelete(@ModelAttribute("configNetType") @ConfigNetTypeDTOAnnotation(ConfigNetTypeDTO.class) ConfigNetType configNetType) {
		String msg = String.format("ConfigNetTypeController doEdit=%s%n", configNetType);
		
		
		LOG.debug(msg);
		
		if (!configNetTypeService.get(configNetType.getNetType()).isPresent()) {
			throw new IllegalStateException(String.format("ConfigNetTypeController::doEdit - trying to create a non-existent netType %s%n", configNetType));
		}
		configNetTypeService.delete(configNetType);	
		return "configNetType";
	}
	
}
