package com.verizon.espservices.dni.confignettype.validation;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import javax.validation.Constraint;

import com.verizon.espservices.dni.confignettype.entity.ConfigNetType;


@Constraint(validatedBy=ConfigNetTypeValidator.class)
@Target(ElementType.TYPE)
@Retention(RetentionPolicy.RUNTIME)
@Documented
public @interface ConfigNetTypeAnnotation {
	   String message() default "{netTypeDuplicated}";
	   Class<ConfigNetType>[] groups() default {};
	   Class<ConfigNetType>[] payload() default {};
}