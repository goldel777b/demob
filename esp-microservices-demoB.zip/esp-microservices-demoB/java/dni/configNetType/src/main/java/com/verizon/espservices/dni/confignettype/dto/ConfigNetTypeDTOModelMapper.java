package com.verizon.espservices.dni.confignettype.dto;

import javax.persistence.EntityManager;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.verizon.espservices.lib.core.dto.AbstractDTOModelMapper;

//https://auth0.com/blog/automatically-mapping-dto-to-entity-on-spring-boot-apis/
public class ConfigNetTypeDTOModelMapper extends AbstractDTOModelMapper<ConfigNetTypeDTOAnnotation> {

	public ConfigNetTypeDTOModelMapper(ObjectMapper objectMapper, EntityManager entityManager) {
		super(objectMapper, entityManager);
	}

	@Override
	protected Class<ConfigNetTypeDTOAnnotation> getDTOClass() {
		return ConfigNetTypeDTOAnnotation.class;
	}

}
