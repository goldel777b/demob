package com.verizon.espservices.dni.confignettype.repository;


import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.CrossOrigin;

import com.verizon.espservices.dni.confignettype.entity.ConfigNetType;

@Repository
@CrossOrigin(origins = "http://localhost:4200")
//@PreAuthorize("hasRole('ROLE_USER')")
public interface ConfigNetTypeRepository extends CrudRepository<ConfigNetType, String> {
//    @Override
//    @Transactional(timeout = 8)// TBD
//    Iterable<ConfigNetType> findAll();
    
    @Transactional(timeout = 8)// TBD
    Iterable<ConfigNetType> findAllByOrderByNetTypeAsc();
}

/*
@Override
@PreAuthorize("hasRole('ROLE_ADMIN')")
<S extends Item> S save(S s);
*/