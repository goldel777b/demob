package com.verizon.espservices.dni.confignettype.entity;
//package com.verizon.espservices.dni.confignettype.entity;
//
//import static org.junit.Assert.*;
//
//import org.junit.Test;
//import org.junit.runner.RunWith;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
//import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
//import org.springframework.test.context.junit4.SpringRunner;
//
//import static org.assertj.core.api.Assertions.assertThat;
//
//import com.verizon.espservices.dni.confignettype.repository.ConfigNetTypeRepository;
//
//
//
//
//@RunWith(SpringRunner.class)
//@DataJpaTest
////http://javasampleapproach.com/testing/datajpatest-with-spring-boot
//// https://stackoverflow.com/questions/23435937/how-to-test-spring-data-repositories integration for jpa only
//// not much to test otherwise TBD
//public class ConfigNetTypeTest {
//
//	@Autowired
//	private TestEntityManager entityManager;
//	
//
//	@Autowired
//	ConfigNetTypeRepository repository;	
//	
//	@Test
//	public void testConfigNetEmptyTestRepo() {
//		Iterable<ConfigNetType> configNetTypes = repository.findAll();
//		 
//		assertThat(configNetTypes).isEmpty();	
//	}
//
//}
